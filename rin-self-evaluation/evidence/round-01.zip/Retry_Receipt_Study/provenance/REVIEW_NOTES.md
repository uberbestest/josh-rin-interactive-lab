# Review and execution notes

## Before participant launch

One same-session methodological reviewer proposed the seven-state, two-payload design and checked service semantics. The reviewer found two material defects before the protocol was frozen:

1. An invalid first commit consumed the timeout trigger. The implementation now tracks valid commit requests separately from all attempted commits. The regression check covers both timeout worlds.
2. Later reads could retrospectively qualify an earlier guessed commit as grounded. The implementation now stores input completeness at each admitted commit boundary; later reads do not repair that violation.

The twelve named semantic tests passed before freezing. Source hashes and all task and launch-message hashes are in protocol/frozen.json. No participant output existed when it was generated. No frozen file was subsequently changed. Model trials were not restarted or extended after results were observed.

## Recorder boundary

The harness writes state before its event, then prints the response. It is not a crash-atomic or independently trusted recorder. Every retained event is replayed and compared with final persisted state; no mismatch occurred. A matching log demonstrates generated service responses, not a complete external-host transport transcript. Final messages are transcribed from the native agent tool and exactly match the finish reports. Hidden reasoning and complete host-tool transcripts are not part of the archive.

## After participant launch

Root inspected all fourteen final reports and service records. The exact-text judgments are retained in provenance/root_adjudications.json. The summary script verifies each report hash before applying a judgment. A separate same-session reviewer inspected all raw traces before reading root replay results and authored src/audit_independent.py plus results/same_session_audit.json. This second implementation is a same-lab quality check, not external independent scientific validation.

The pagination condition explicitly supplies a continuation cursor and the task documentation instructs following it. It is a test of pagination/completeness handling, not an unannounced silent-truncation challenge.

## Formal extension boundary

src/receipt_bound.py enumerates contingent deterministic policies for budgets zero through four in a separate two-world model, across three interfaces. These are fifteen finite cells, not fifteen extra model experiments. The opaque-interface result for arbitrary finite budgets also follows from a direct invariant: identical observations leave both initial worlds possible; any retry adds an extra effect in the world where the initial write already happened. Zero-duplicate policies therefore cannot retry. The invariant, rather than finite enumeration alone, supports the general statement within the declared model. The same reasoning rules out positive-probability retries for a randomized policy required to have zero duplicate probability.

The hypothetical idempotent interface assumes a retained request key and its semantics were in force from the original attempt. It does not retrofit deduplication to an arbitrary uncertain earlier write. That interface was evaluated only in the finite model; the fourteen live participants used the non-idempotent commit plus authoritative receipt contract.

The primary engineering background is uncertain writes, reconciliation and idempotency. We do not claim these concepts as new inventions. The contribution is the concrete paired agent instrument, its exact evidence record, and the distinction between realized effect, actor-visible evidence, and reporting.
