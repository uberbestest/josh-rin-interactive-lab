"""Check the bytes distributed with this research record."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    inventory=json.loads((ROOT/'INVENTORY.json').read_text())
    failures=[]
    for name,item in inventory['files'].items():
        path=ROOT/name
        if not path.is_file():
            failures.append({'file':name,'error':'missing'});continue
        data=path.read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            failures.append({'file':name,'error':'byte mismatch'})
    result={'status':'FAIL' if failures else 'PASS','checked_files':len(inventory['files']),
            'failures':failures,'scope':'Byte identity; not external validation of conclusions'}
    print(json.dumps(result,indent=2))
    if failures:raise SystemExit(1)


if __name__=='__main__':main()
