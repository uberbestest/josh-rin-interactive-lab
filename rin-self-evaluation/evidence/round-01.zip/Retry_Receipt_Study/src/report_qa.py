"""Presentation QA only; requires Playwright and an installed Chromium."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import functools
import http.server
import json
import shutil
import threading

ROOT=Path(__file__).resolve().parents[1]


class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*args):
        pass


def main():
    server=http.server.ThreadingHTTPServer(('127.0.0.1',0),functools.partial(Quiet,directory=str(ROOT)))
    threading.Thread(target=server.serve_forever,daemon=True).start()
    checks=[];errors=[]
    binary=shutil.which('chromium')
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,**({'executable_path':binary} if binary else {}))
        page=browser.new_page(viewport={'width':1440,'height':1000},device_scale_factor=1)
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.goto(f'http://127.0.0.1:{server.server_port}/The_Retry_That_Needed_a_Receipt.html',wait_until='networkidle')
        assert page.locator('details.run').count()==14
        checks.append('all_14_trace_panels')
        assert page.locator('#findings tbody tr').count()==7
        checks.append('seven_result_rows')
        page.screenshot(path='retry_report_desktop.png')
        page.select_option('#case-filter','timeout_after_commit')
        assert page.locator('details.run').count()==2
        checks.append('scenario_filter')
        page.click('#expand')
        assert page.locator('details.run[open]').count()==2
        checks.append('expand_visible_traces')
        page.locator('#traces').scroll_into_view_if_needed()
        page.screenshot(path='retry_report_traces.png')
        page.select_option('#case-filter','all')
        assert page.locator('details.run').count()==14
        page.click('#theme')
        assert page.locator('html').get_attribute('data-theme')=='light'
        checks.append('light_theme')
        page.evaluate('scrollTo(0,0)')
        page.screenshot(path='retry_report_light.png')
        page.set_viewport_size({'width':375,'height':812})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth'), 'Mobile document overflow'
        checks.append('mobile_no_document_overflow')
        page.screenshot(path='retry_report_mobile.png')
        assert not errors
        checks.append('no_uncaught_browser_errors')
        browser.close()
    server.shutdown()
    result={'status':'PASS','checks':checks,'count':len(checks),'browser_errors':errors,
            'scope':'self-contained local report; no site publication',
            'browser':binary or 'Playwright bundled Chromium',
            'setup_note':'The first QA launch found no bundled Playwright browser. The installed system Chromium was used successfully instead.'}
    (ROOT/'results/report_qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
