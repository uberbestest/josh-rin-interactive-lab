"""Replay recorded service events without making any model calls."""
import hashlib
import json
from pathlib import Path
from service import canon, digest, ground_truth, transition

ROOT = Path(__file__).resolve().parents[1]


def replay_run(folder):
    state = json.loads((folder/'initial_state.json').read_text())
    previous = '0'*64
    events = []
    path = folder/'events.jsonl'
    if path.exists(): events = [json.loads(line) for line in path.read_text().splitlines()]
    for n, original in enumerate(events, 1):
        event = dict(original)
        saved_hash = event.pop('event_hash')
        if saved_hash != digest(event): raise ValueError(f'{folder.name}:{n}: event hash mismatch')
        if event['index'] != n or event['previous_event_hash'] != previous:
            raise ValueError(f'{folder.name}:{n}: chain mismatch')
        if event['state_before_hash'] != digest(state): raise ValueError(f'{folder.name}:{n}: initial state mismatch')
        state, response = transition(state,event['request'])
        if response != event['response'] or event['state_after_hash'] != digest(state):
            raise ValueError(f'{folder.name}:{n}: replay mismatch')
        previous = saved_hash
    stored = json.loads((folder/'state.json').read_text())
    if state != stored: raise ValueError(f'{folder.name}: final state mismatch')
    return {'run_id':folder.name,'events':len(events),'final_event_hash':previous,
            'mechanical':ground_truth(state), 'report':state['report']}


def main():
    frozen = json.loads((ROOT/'protocol'/'frozen.json').read_text())
    for path, expected in frozen['source_hashes'].items():
        if hashlib.sha256((ROOT/path).read_bytes()).hexdigest() != expected:
            raise ValueError(f'Frozen source changed: {path}')
    rows = []
    for row in frozen['runs']:
        folder=ROOT/'runs'/row['run_id']
        if hashlib.sha256((folder/'prompt.txt').read_bytes()).hexdigest() != row['prompt_sha256']:
            raise ValueError(f'Prompt changed: {row["run_id"]}')
        if hashlib.sha256((folder/'launch_message.txt').read_bytes()).hexdigest() != row['launch_message_sha256']:
            raise ValueError(f'Launch message changed: {row["run_id"]}')
        rows.append({**row,**replay_run(folder)})
    result = {'status':'PASS','runs':rows, 'run_count':len(rows), 'event_count':sum(r['events'] for r in rows),
              'frozen_protocol_sha256': hashlib.sha256((ROOT/'protocol'/'frozen.json').read_bytes()).hexdigest()}
    (ROOT/'results'/'replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'], 'run_count':result['run_count'], 'event_count':result['event_count'],
                      'finished':sum(r['mechanical']['finished'] for r in rows),
                      'grounded_completions':sum(r['mechanical']['grounded_completion'] for r in rows)},indent=2))


if __name__=='__main__': main()
