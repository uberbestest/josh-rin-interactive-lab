"""Assemble this complete evidence package without credentials or scratch images."""
import datetime
import hashlib
import json
import zipfile
from pathlib import Path
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
ARCHIVE=ROOT.parent/'Retry_Receipt_Evidence.zip'


def retained(path):
    rel=path.relative_to(ROOT)
    return (path.is_file() and '__pycache__' not in rel.parts and
            path.name not in ('lock','INVENTORY.json') and
            path.suffix not in ('.tmp','.zip','.pyc') and
            str(rel) not in ('results/summarize_stdout.json',))


def main():
    replay=json.loads((ROOT/'results/replay.json').read_text())
    audit=json.loads((ROOT/'results/same_session_audit.json').read_text())
    summary=json.loads((ROOT/'results/summary.json').read_text())
    if replay['status']!='PASS' or audit['status']!='PASS':
        raise SystemExit('Cannot package failed scientific checks')
    pdf=ROOT/'The_Retry_That_Needed_a_Receipt.pdf'
    if len(PdfReader(pdf).pages)!=6:raise SystemExit('Unexpected report pagination')
    receipt={'record':summary['record'],'status':'RESEARCH_VERIFIED_REPORT_RENDERED',
             'user_facing_date':'2026-11-17','generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'semantic_tests_before_launch':12,'native_participant_contexts':14,
             'operational_calls':70,'service_events_including_finish':84,
             'primary_replay':'PASS','separate_parser':'PASS',
             'mechanical_field_comparisons':126,'native_final_texts_match':14,
             'finite_bound_cells':15,'finite_bound_scope':'Two authored worlds; not extra model runs',
             'pdf':{'pages':6,'rendered_with':'Poppler pdftoppm','visual_review':'PASS; all six pages inspected; dense pages inspected at full rendering size'},
             'html_browser_qa':'BLOCKED; Chromium launch prohibited by environment; no bypass attempted',
             'external_independent_review':False,'prior_generation_comparison':False,
             'pinned_model_snapshot':False,'external_model_api_requests':0,
             'token_and_billing_receipt':None}
    (ROOT/'results/verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
    files=sorted(p for p in ROOT.rglob('*') if retained(p))
    inventory={'record':summary['record'],'scope':'Every distributed file except this inventory; archive checksum is external',
               'files':{str(p.relative_to(ROOT)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files}}
    (ROOT/'INVENTORY.json').write_text(json.dumps(inventory,indent=2)+'\n')
    files.append(ROOT/'INVENTORY.json')
    with zipfile.ZipFile(ARCHIVE,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(files):
            info=zipfile.ZipInfo('Retry_Receipt_Study/'+str(p.relative_to(ROOT)),date_time=(2026,11,18,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
            z.writestr(info,p.read_bytes())
    digest=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    (ROOT.parent/'Retry_Receipt_Evidence.sha256').write_text(digest+'  '+ARCHIVE.name+'\n')
    print(json.dumps({'archive':str(ARCHIVE),'bytes':ARCHIVE.stat().st_size,'files':len(files),'sha256':digest,
                      'pdf':str(pdf),'pdf_bytes':pdf.stat().st_size},indent=2))


if __name__=='__main__':main()
