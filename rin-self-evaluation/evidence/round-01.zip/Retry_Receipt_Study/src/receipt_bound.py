"""Exact finite information-bound illustration, separate from live-agent trials.

Enumerate contingent deterministic policies with a finite action budget. Initial
world 0 lost the request before execution; world 1 lost only the acknowledgement.
Both expose the same initial timeout. Worlds are authored possibilities, not draws.
"""
from functools import lru_cache
from itertools import product
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def stop_score(worlds):
    # State: (world identifier, actual commit count, known count or -1).
    return (sum(n==1 for _,n,k in worlds),
            sum(n>1 for _,n,k in worlds),
            sum(n==1 and k==1 for _,n,k in worlds))


@lru_cache(None)
def enumerate_scores(worlds, budget, interface):
    out={stop_score(worlds)}
    if budget==0:return frozenset(out)
    actions=['retry']
    if interface=='receipt':actions.append('query')
    if interface=='idempotent':actions.append('replay_key')
    for action in actions:
        partitions={}
        for w,n,k in worlds:
            if action=='retry':
                # The acknowledgement confirms the new append, not the count of
                # earlier commits. Existing exact knowledge remains updatable.
                child=(w,n+1,k+1 if k>=0 else -1); observation='appended'
            elif action=='query':
                child=(w,n,n); observation=f'count:{n}'
            else:
                child=(w,max(1,n),max(1,n)); observation=f'count:{max(1,n)}'
            partitions.setdefault(observation,[]).append(child)
        child_scores=[]
        for child in partitions.values():
            canonical=tuple(sorted(child))
            # Once the observation has partitioned possibilities, the known
            # count is what all worlds in this observation class agree on.
            counts={n for _,n,_ in canonical}
            if len(counts)==1:
                known=next(iter(counts)); canonical=tuple((w,n,known) for w,n,k in canonical)
            child_scores.append(enumerate_scores(canonical,budget-1,interface))
        for branches in product(*child_scores):
            out.add(tuple(sum(b[i] for b in branches) for i in range(3)))
    return frozenset(out)


def main():
    worlds=((0,0,-1),(1,1,-1)); rows=[]
    for interface in ['opaque','receipt','idempotent']:
        for budget in range(5):
            scores=enumerate_scores(worlds,budget,interface)
            safe=[s for s in scores if s[1]==0]
            rows.append({'interface':interface,'actions_after_timeout':budget,
                         'attainable_score_triples':[list(s) for s in sorted(scores)],
                         'max_completed_worlds_with_zero_duplicates':max(s[0] for s in safe),
                         'max_evidence_backed_completions_with_zero_duplicates':max(s[2] for s in safe),
                         'worlds':2})
    for row in rows:
        k=row['actions_after_timeout']; i=row['interface']
        expected=2 if (i=='receipt' and k>=2) or (i=='idempotent' and k>=1) else 1
        if row['max_completed_worlds_with_zero_duplicates']!=expected:raise ValueError('coverage formula mismatch')
        expected_evidence=2 if expected==2 else (1 if i=='receipt' and k>=1 else 0)
        if row['max_evidence_backed_completions_with_zero_duplicates']!=expected_evidence:raise ValueError('evidence formula mismatch')
    result={'status':'PASS','scope':'Exact authored two-world model; no model participants',
            'score_order':['exactly_one_effect','duplicate_worlds','evidence_backed_exactly_one'],
            'rows':rows,'policy':'Observation-history policies; no hidden-world policy selection',
            'known_background':'Uncertain commit and idempotency are established distributed-systems concepts; no novelty claimed for the general impossibility.'}
    (ROOT/'results'/'receipt_bound.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','cells':len(rows),'interfaces':3,'budgets':5},indent=2))


if __name__=='__main__':main()
