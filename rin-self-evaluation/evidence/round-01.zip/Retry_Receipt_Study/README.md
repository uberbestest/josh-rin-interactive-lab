# The Retry That Needed a Receipt

Josh & Rin's Lab · November 17, 2026 · v0.1.0

Record: `JRR-RETRY-RECEIPT-2026-11-17-001`

Start with `The_Retry_That_Needed_a_Receipt.pdf` for the rendered and visually checked report. The companion `The_Retry_That_Needed_a_Receipt.html` contains an interactive trace browser and dark/light theme controls. It is designed for self-contained offline use, but browser execution could not be checked here: the environment blocked Chromium launch. That presentation limit is recorded in `results/report_qa.json` and does not affect the model-run replay or numerical audits.

Fourteen fresh native-agent task contexts completed one small reconciliation task each across seven authored service states and two numerical payloads. Ten feasible tasks completed with correctly ordered input evidence and an observed receipt; four blocked tasks preserved supported drafts and explicitly reported why the requested commit did not occur. No duplicate effects or post-revocation commit requests were observed. These are bounded pilot observations, not a population reliability rate or a GPT-6 versus GPT-6.2 comparison.

## What is included

* `protocol/`: task contract, pre-run protocol, frozen source/prompt hashes and launch schedule.
* `runs/`: original initial/final synthetic states, every recorded service request/response, exact task/launch prompts.
* `results/`: complete mechanical replay, per-run CSV, root exact-text review, second same-session audit, finite information-bound enumeration and verification receipt.
* `provenance/`: primary-source links, native final-message transcriptions, root adjudications and review notes.
* `src/`: standalone Python standard-library service, semantic tests, replay, separate audit parser, finite model, and report generator.

The session identified itself as GPT-6.2 Astra Pro. Child model and effort were inherited without overrides; the serving snapshot was not pinned or independently attested. Fresh child contexts omitted the parent conversation. Platform instructions and a shared filesystem remained. Do not call these externally isolated or independently validated trials.

No external model API request was made, no API key was created or inspected, and no API credit was spent by this study. Native session resources were used; token/billing receipts are not available. No site publication or schedule change was performed.

## Reproduce the checks

From the extracted directory, using Python 3.12 or compatible standard-library Python:

```sh
python3 -m unittest discover -s src -p 'test_service.py' -v
python3 src/replay.py
python3 src/audit_independent.py
python3 src/receipt_bound.py
python3 src/summarize.py
python3 src/build_report.py
python3 src/check_inventory.py
```

`replay.py` recomputes service responses and outcomes from the retained model-selected actions. It does not rerun a model. Re-running generation would require fresh model sessions, a new record, and a declared controlled configuration. `summarize.py` joins fixed manual language judgments to exact text hashes; it is not a reusable automatic honesty classifier. `prepare.py` refuses to overwrite the existing frozen record.

The captured prompt texts include original absolute runtime paths for provenance. The replay/audit scripts resolve this package relative to their own files and can run after extraction at another path.

Read `provenance/REVIEW_NOTES.md` for instrumentation limits and pre-run corrections. The hashes bind bytes, not the truth of scientific interpretation. No independent external validation or model improvement is claimed.
