# The Second Door Still Needs the Key

**What we tested:** Whether two authorized jobs sharing a limited-use key and
logical clock would both be preserved, with different cases requiring different
opening actions and honest reporting when only one completion was guaranteed.

**What happened:** Both requested selectors safely finalized both jobs in all
16 initially joint-guaranteed runs per selector. Each attained the guaranteed
priority completion in all six hard-ceiling controls and both unbounded-receipt
controls. All 48 structured reports had exact mechanical fields.

**Outliers:** No unsafe action, lost guarantee, destructive query or omitted
job appeared on the measured endpoints. The newer selector made two additional
receipt queries and two additional acknowledged deliveries that it could not
finalize. These choices consumed four more key uses and five more logical ticks
overall, with the same finalized-job outcomes. The older selector varied its
optional delivery behavior between repeated budget-control runs.

Record: **JRR-SECOND-DOOR-2026-11-18-005**. Round 05 of Josh & Rin's
self-evaluation series, conducted November 18, 2026 (America/New_York).

This archive contains the prospective instrument and the complete retained
record of 48 assigned native contexts: 12 authored scenario families, two fresh
repeats of the same case per requested selector, and two selectors
(`gpt-6-astra` and `gpt-6.2-astra`). The selectors do not independently attest
immutable serving snapshots, equal token budgets, or service-tier equivalence.

## Read the study

- `report/report.pdf`: the methods, findings, interpretation and limitations.
- `results/observed.json`: frozen scoring applied to every assigned run.
- `results/review.json` and `results/review.md`: separate same-lab review of
  participant explanations against their public observations.
- `protocol/PROTOCOL.md` and `protocol/CONTRACT.md`: prospective design and
  participant-facing action/report rules.
- `protocol/cases.json` and `protocol/assignments.json`: authored cases and
  all model/family/replicate assignments.
- `protocol/frozen.json`: pre-run hashes for the instrument, initial states,
  prompts and dispatch messages.
- `provenance/prerun_commit.json`: the GitHub commit recorded before dispatch.
- `provenance/dispatches.jsonl` and `provenance/seal_acknowledgements.jsonl`:
  coordinator records of launches and received native seal lines.
- `runs/`: initial and final states, hash-chained requests/observations,
  participant-authored reports, and separately retained native seal receipts.
- `INVENTORY.json`: post-run SHA-256 and byte counts for every archive member
  except the inventory itself.

The public ZIP and the canonical ZIP have identical bytes. The published
checksum and publication-verification receipt are beside the ZIP on the study
page. The archive inventory is a post-run integrity record, not a second
prospective freeze.

## Reproduce the recorded mechanics

Use Python 3.11 or later. After extracting the trusted archive, run this from
its parent directory:

```sh
python3 -B second-door-study/reproduce.py --output second-door-reproduction.json
```

This executes the archived code, semantic tests and separately derived oracle
audit; replays all saved requests and observations; checks frozen hashes and
the three report/seal representations; and recomputes the recorded scores.
It does not start new participant models, call an external delivery service,
or consume a real credential. The replay output must be outside the evidence
directory. PDF rebuilding is optional and has separate dependencies documented
by `report/build_report.py`; it is not needed for event replay.

The repository's `rin-self-evaluation/tools/verify_second_door_evidence.py`
additionally verifies the complete ZIP inventory and assignment matrix from a
fresh temporary extraction. Both forms of verification are same-lab consistency
checks. They do not establish external replication, complete platform access
telemetry, or independent model identity.

## Interpret the denominators

Each selector has 16 runs in eight initially joint-feasible families, six runs
in three hard-ceiling control families, and two runs in one unbounded-receipt
control family. Keep these endpoints separate. The two repeats within a family
are repeated contexts for the same authored case, not independent scenario
families. Joint completion, preservation of the public-information guarantee,
unsafe attempts, mechanical report accuracy and explanation support are
distinct measurements.

The unbounded control initially guarantees completion of one priority job.
An honest stop after that completion can attain the prescribed worst-case
objective while the other delivery remains unknown. Favorable possible worlds
can still allow both jobs to finish. Pending observations therefore do not
establish that the receipt can never resolve.
