# Post-run public disclosure copy — round-02

This is a public copy of **JRR-RECEIPT-COMPARISON-2026-11-17-002**. It was prepared after the
participant runs. Original session filesystem prefixes in prompt, launch,
contract and selected provenance metadata have been replaced by
`<PRIVATE_WORKSPACE>`. Optional baseline presentation-QA output filenames are
relative instead of pointing into a local temporary directory.

The PDF report is unchanged. Every raw initial state, final state and event log
is byte-identical to the canonical archive. Requested model selectors,
observations, responses, final reports, costs, outcomes, timestamps and raw
event/state hashes have not been edited. No new live trials were run.

## Identities and limits

Canonical original archive: `Receipt_Comparison_Evidence.zip`

Canonical original archive SHA256:
`938f0128a3eaed15a2a3f0f3ee99639d4b84a68e681c6dfedc1a3196ed2a5fe9`

`PUBLIC_EXPORT.json` records the original and public digest of every file,
the exact changed-file categories and counts, the original frozen-manifest
identity, and the new public inventory. It does not disclose the private prefix.
The old `frozen.json`, review records, result records and original inventory
retain their historical digest fields. Where path text was neutralized, the
containing file has a different public digest. The original timestamp and
digest claims describe the original record, not a newly frozen experiment.

This copy is **not byte-identical to the original archive**. Its companion
checksum identifies this public ZIP. The canonical originals remain retained
unchanged separately. These are same-lab records and verification, without
external attestation or an independently verified backend model identity.

## Verify this public copy

After extracting, run from this directory:

```sh
python3 verify_public_evidence.py
```

Or use the repository tool on the ZIP, with a fresh temporary extraction:

```sh
python3 tools/verify_public_evidence.py evidence/round-02.zip --output publication-verification.json
```

The checker requires only the Python standard library. It validates the public
inventory and retained original inventory, enforces every unchanged frozen
source hash, checks each declared path-redacted file against both its original
identity and its new disclosed identity, runs the original semantic tests,
and invokes the unchanged original scientific replay routines. For redacted
prompt and launch text, only in-memory copies of expected hash fields are
adapted to the public bytes. Original digest fields on disk are not rewritten.
Every mechanical result, final report, event count and final event hash must
match the archived original replay results.

The original README/PDF reproduction commands describe verification of the
canonical original bytes. Direct original inventory/replay commands will
reject changed path metadata in this disclosure copy; use the public checker
above. Its receipt is new publication verification, not a replacement for the
original independent-review record and not a claim of new external independence.
It cannot byte-verify the withheld original path text without that private text.
