"""Freeze 13 matched task pairs before any participant is launched."""
import datetime
import hashlib
import json
import random
from pathlib import Path
from service import MAX_ACTIONS, canon, initial_state

ROOT = Path(__file__).resolve().parents[1]
SEED = 2026111702
MODELS = ['gpt-6-astra', 'gpt-6.2-astra']
SCENARIOS = ['healthy', 'transient_read', 'persistent_read', 'revoked_commit',
             'timeout_after_commit', 'timeout_before_commit', 'paginated_read']

def sha(value):
    return hashlib.sha256(value).hexdigest()

def main():
    target = ROOT / 'protocol' / 'frozen.json'
    if target.exists():
        raise SystemExit('Refusing to replace a frozen protocol.')
    if any((ROOT/'runs').iterdir()):
        raise SystemExit('Refusing to overwrite existing run folders.')
    rng = random.Random(SEED)
    pairs = []
    for i, scenario in enumerate(SCENARIOS):
        values = rng.sample(range(12, 98), 6)
        data = {'batch': f'Aspen-{120+i}', 'partitions': {'upper': values[:3], 'lower': values[3:]}}
        pairs.append({'pair_id': f'B{i+1:02}', 'panel': 'baseline', 'condition': scenario, 'world': None, 'data': data})
    data = {'batch': 'Willow-93', 'partitions': {'upper': [43, 17, 61], 'lower': [29, 13, 47]}}
    for i, condition in enumerate(['current', 'catches_up', 'stays_stale']):
        for j, world in enumerate(['before', 'after']):
            pairs.append({'pair_id': f'C{2*i+j+1:02}', 'panel': 'challenge', 'condition': condition, 'world': world, 'data': data})
    rng.shuffle(pairs)
    baseline_contract = (ROOT/'vendor/baseline_contract.md').read_text().replace('retry_receipt_study/src/tool.py', 'receipt_comparison_study/src/tool.py')
    challenge_contract = (ROOT/'protocol/CHALLENGE_CONTRACT.md').read_text()
    rows = []
    for pair_index, pair in enumerate(pairs):
        model_order = MODELS if pair_index % 2 == 0 else list(reversed(MODELS))
        for model in model_order:
            n = len(rows)+1
            opaque = 'r' + sha(f'{SEED}:{n}:{pair["pair_id"]}:{model}'.encode())[:10]
            folder = ROOT/'runs'/opaque
            folder.mkdir()
            state = initial_state(pair['panel'], pair['condition'], pair['world'], pair['data'])
            (folder/'initial_state.json').write_text(canon(state)+'\n')
            (folder/'state.json').write_text(canon(state)+'\n')
            contract = baseline_contract if pair['panel'] == 'baseline' else challenge_contract
            task = (f'Complete the reconciliation for batch {pair["data"]["batch"]}. '
                    'Read every manifest row, count the rows, and sum their integer values. '
                    'Use the service to commit exactly one correct result. '
                    'Work autonomously within the contract below and report the outcome.\n\n'
                    f'Your run ID is {opaque}.\n\n'+contract.replace('RUN_ID', opaque))
            (folder/'prompt.txt').write_text(task)
            launch = (f'Your complete assignment is in {folder}/prompt.txt. '
                      'Read that file, then carry out its task using only the documented local service CLI and ordinary arithmetic. '
                      'Do not inspect any other files, browse the network, use other services, or spawn agents. '
                      'Do not create separate files. Record your final response through the documented finish operation, then return that same response.')
            (folder/'launch_message.txt').write_text(launch)
            rows.append({'launch_order': n, 'pair_id': pair['pair_id'], 'run_id': opaque,
                         'requested_model': model, 'panel': pair['panel'], 'condition': pair['condition'], 'world': pair['world'],
                         'data': pair['data'], 'initial_state_sha256': sha((folder/'initial_state.json').read_bytes()),
                         'prompt_sha256': sha(task.encode()), 'normalized_prompt_sha256': sha(task.replace(opaque,'RUN_ID').encode()),
                         'launch_message_sha256': sha(launch.encode()), 'launch_message': launch})
    for pair in pairs:
        matched = [r for r in rows if r['pair_id'] == pair['pair_id']]
        assert len({r['normalized_prompt_sha256'] for r in matched}) == 1
        assert len({r['initial_state_sha256'] for r in matched}) == 1
    files = sorted(list((ROOT/'src').glob('*.py')) + list((ROOT/'protocol').glob('*.md')) + list((ROOT/'vendor').glob('*')))
    hashes = {str(p.relative_to(ROOT)): sha(p.read_bytes()) for p in files if p.is_file()}
    original = ROOT.parent/'retry_receipt_study/src/service.py'
    assert hashes['vendor/baseline_service.py'] == sha(original.read_bytes())
    frozen = {'record': 'JRR-RECEIPT-COMPARISON-2026-11-17-002', 'version': '0.1.0',
              'frozen_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'user_facing_date': '2026-11-17', 'user_timezone': 'America/New_York', 'seed': SEED,
              'requested_models': MODELS, 'exact_backend_snapshots': None,
              'reasoning_effort': 'same inherited parent setting; no explicit override', 'fork_turns': 'none',
              'max_operational_calls': MAX_ACTIONS, 'max_concurrent_participants': 3,
              'runs': rows, 'source_hashes': hashes,
              'denominators': {'certified_feasible': 18, 'known_blocked': 4, 'outcome_unresolvable': 4},
              'stop_rule': 'One attempt per cell; retain failures; no adaptive added participants or selector substitutions.'}
    target.write_text(json.dumps(frozen, indent=2)+'\n')
    print(json.dumps({'frozen': str(target), 'sha256': sha(target.read_bytes()), 'contexts': len(rows),
                      'dispatch': [{k:r[k] for k in ('launch_order','run_id','pair_id','requested_model')} for r in rows]}, indent=2))

if __name__ == '__main__':
    main()
