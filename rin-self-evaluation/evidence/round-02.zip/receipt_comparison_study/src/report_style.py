"""Create the reader-facing PDF using retained results. No browser required."""
import json
from pathlib import Path
from xml.sax.saxutils import escape
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'A_Receipt_That_Had_Not_Caught_Up.pdf'
INK=colors.HexColor('#17283c')
MUTED=colors.HexColor('#4a5f74')
TEAL=colors.HexColor('#006b70')
LINE=colors.HexColor('#cbd6e1')
PALE=colors.HexColor('#edf6f6')
WIDTH=A4[0]-88

for name,path in [
    ('Lab','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),
    ('LabBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),
    ('LabItalic','/usr/share/fonts/truetype/dejavu/DejaVuSans-Oblique.ttf'),
]:
    pdfmetrics.registerFont(TTFont(name,path))
pdfmetrics.registerFontFamily('Lab',normal='Lab',bold='LabBold',italic='LabItalic',boldItalic='LabBold')

styles={
 'body':ParagraphStyle('body',fontName='Lab',fontSize=9.8,leading=14,textColor=INK,spaceAfter=8),
 'small':ParagraphStyle('small',fontName='Lab',fontSize=8.3,leading=11.5,textColor=MUTED,spaceAfter=7),
 'title':ParagraphStyle('title',fontName='LabBold',fontSize=31,leading=34,textColor=INK,spaceAfter=13),
 'h1':ParagraphStyle('h1',fontName='LabBold',fontSize=22,leading=26,textColor=INK,spaceAfter=15),
 'h2':ParagraphStyle('h2',fontName='LabBold',fontSize=13,leading=17,textColor=TEAL,spaceBefore=8,spaceAfter=7),
 'kicker':ParagraphStyle('kicker',fontName='LabBold',fontSize=8.5,leading=12,textColor=TEAL,spaceAfter=14),
 'cell':ParagraphStyle('cell',fontName='Lab',fontSize=8.1,leading=11.4,textColor=INK),
 'cellbold':ParagraphStyle('cellbold',fontName='LabBold',fontSize=8.1,leading=11.4,textColor=INK),
 'quote':ParagraphStyle('quote',fontName='Lab',fontSize=9.2,leading=13.2,textColor=INK,leftIndent=10,borderColor=TEAL,borderWidth=1,borderPadding=7,spaceAfter=9),
 'metric':ParagraphStyle('metric',fontName='LabBold',fontSize=24,leading=29,textColor=TEAL,spaceAfter=5),
}


def clean(t):
    for a,b in [('—','-'),('–','-'),('‑','-'),('’',"'"),('“','"'),('”','"')]:
        t=t.replace(a,b)
    return t


def p(t,style='body'):
    return Paragraph(clean(t),styles[style])


def table(rows,widths,header=True):
    matrix=[]
    for i,row in enumerate(rows):
        matrix.append([p(str(x),'cellbold' if (i==0 and header) else 'cell') for x in row])
    t=Table(matrix,colWidths=widths,hAlign='LEFT',repeatRows=1 if header else 0)
    rules=[('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),9),
           ('RIGHTPADDING',(0,0),(-1,-1),9),('TOPPADDING',(0,0),(-1,-1),7),
           ('BOTTOMPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.45,LINE)]
    if header:rules.append(('BACKGROUND',(0,0),(-1,0),PALE))
    t.setStyle(TableStyle(rules))
    return t


def page(c,doc):
    c.saveState()
    w,h=A4
    c.setFillColor(TEAL);c.rect(0,h-8,w,8,fill=1,stroke=0)
    c.setFont('LabBold',8);c.setFillColor(MUTED)
    c.drawString(44,h-31,"JOSH & RIN'S LAB")
    c.setFont('Lab',8);c.drawRightString(w-44,h-31,'NOVEMBER 17, 2026')
    c.setStrokeColor(LINE);c.line(44,42,w-44,42)
    c.setFont('Lab',7.3);c.setFillColor(MUTED)
    c.drawString(44,29,'JRR-RECEIPT-COMPARISON-2026-11-17-002 | Same-lab verification')
    c.drawRightString(w-44,29,str(doc.page))
    c.restoreState()


def new_page(story,title,kicker=None):
    story.append(PageBreak())
    if kicker:story.append(p(kicker,'kicker'))
    story.append(p(title,'h1'))


