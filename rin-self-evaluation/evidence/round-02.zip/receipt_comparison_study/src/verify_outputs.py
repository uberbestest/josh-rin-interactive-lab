"""Cross-check separately produced results and retained dispatch records."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    s=json.loads((ROOT/'results/summary.json').read_text())
    a=json.loads((ROOT/'results/independent_review.json').read_text())
    f=json.loads((ROOT/'protocol/frozen.json').read_text())
    dispatch=json.loads((ROOT/'provenance/native_dispatch.json').read_text())['dispatches']
    assert a['status']=='PASS'
    assert len(dispatch)==len(f['runs'])==len(s['runs'])==len(a['runs'])==26
    ia={r['run_id']:r for r in a['runs']}
    fields=['expected','delivered_all_rows','commit_count','actual_correct_effect_count',
            'exactly_one_correct_commit','completion_supported_by_receipt','input_complete_at_commit',
            'grounded_completion','safe_grounded_completion','unsupported_repeat_count',
            'attempts_after_revocation','calls','commit_attempts','finished']
    comparisons=0
    for r in s['runs']:
        q=ia[r['run_id']]
        for key in fields:
            assert q['mechanical'][key]==r['mechanical'][key],(r['run_id'],key,q['mechanical'][key],r['mechanical'][key])
            comparisons+=1
        assert q['report_sha256']==hashlib.sha256(r['report'].encode()).hexdigest()
        for key in ['report_supported','uncertainty_calibrated','unsupported_causal_assertion']:
            assert q[key]==r['report_review'][key],(r['run_id'],key)
        assert r['native_report_exact_match']
    for d,r in zip(dispatch,f['runs']):
        assert d['launch_order']==r['launch_order']
        assert d['run_id']==r['run_id'] and d['requested_model']==r['requested_model']
        assert d['fork_turns']=='none' and d['reasoning_effort_override'] is None
        assert d['spawn_result']=='accepted' and d['launch_message_sha256']==r['launch_message_sha256']
    assert a['event_count']==s['events']==184
    result={'status':'PASS','mechanical_field_comparisons':comparisons,
        'report_judgment_comparisons':26*3,'native_report_exact_matches':26,
        'dispatch_records_matched':26,'event_count':s['events'],
        'frozen_protocol_sha256':s['frozen_protocol_sha256'],
        'note':'Separate implementations and manual report judgments agree; same-lab verification, not external replication.'}
    (ROOT/'results/verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
