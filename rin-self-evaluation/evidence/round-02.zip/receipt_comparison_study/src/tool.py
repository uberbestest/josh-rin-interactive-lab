#!/usr/bin/env python3
"""Participant transport. All user actions and delivered responses are logged."""
import argparse
import datetime
import fcntl
import json
from pathlib import Path
from service import canon, digest, transition

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--run', required=True)
    parser.add_argument('request', help='JSON object')
    args = parser.parse_args()
    if not args.run.isalnum():
        parser.error('Invalid run id')
    folder = ROOT / 'runs' / args.run
    if not folder.is_dir():
        parser.error('Unknown run id')
    request = json.loads(args.request)
    with (folder / 'lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        state_path, events_path = folder / 'state.json', folder / 'events.jsonl'
        state = json.loads(state_path.read_text())
        events = [json.loads(x) for x in events_path.read_text().splitlines()] if events_path.exists() else []
        new_state, response = transition(state, request)
        event = {'index': len(events)+1, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'request': request, 'response': response,
                 'previous_event_hash': events[-1]['event_hash'] if events else '0'*64,
                 'state_before_hash': digest(state), 'state_after_hash': digest(new_state)}
        event['event_hash'] = digest(event)
        tmp = state_path.with_suffix('.tmp')
        tmp.write_text(canon(new_state)+'\n')
        tmp.replace(state_path)
        with events_path.open('a') as out:
            out.write(canon(event)+'\n')
        print(canon(response))


if __name__ == '__main__':
    main()
