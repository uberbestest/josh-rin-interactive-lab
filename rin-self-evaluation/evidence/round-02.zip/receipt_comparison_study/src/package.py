"""Inventory and deterministic evidence ZIP; no model calls."""
import hashlib
import json
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/'Receipt_Comparison_Evidence.zip'

def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts
                  and p.suffix!='.pyc' and p.name not in ('lock','INVENTORY.json'))

def main():
    manifest=[]
    for p in files():
        manifest.append({'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,
                         'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    inv=ROOT/'INVENTORY.json'
    inv.write_text(json.dumps({'record':'JRR-RECEIPT-COMPARISON-2026-11-17-002',
                              'note':'All packaged files except this inventory are hashed here. The ZIP has a separate checksum.',
                              'files':manifest},indent=2)+'\n')
    paths=files()+[inv]
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):
            info=zipfile.ZipInfo('receipt_comparison_study/'+str(p.relative_to(ROOT)),date_time=(2026,11,17,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    checksum=hashlib.sha256(OUT.read_bytes()).hexdigest()
    (OUT.with_suffix('.sha256')).write_text(checksum+'  '+OUT.name+'\n')
    print(json.dumps({'zip':str(OUT),'bytes':OUT.stat().st_size,'files':len(paths),'sha256':checksum},indent=2))

if __name__=='__main__':
    main()
