"""Check every inventoried evidence file without making model calls."""
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    inv=json.loads((ROOT/'INVENTORY.json').read_text())
    for item in inv['files']:
        p=ROOT/item['path']
        assert p.stat().st_size==item['bytes'],item['path']
        assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],item['path']
    print(json.dumps({'status':'PASS','verified_files':len(inv['files'])}))

if __name__=='__main__':
    main()
