"""Structural PDF checks; visual review is recorded separately by the root."""
import hashlib
import json
from pathlib import Path
import fitz
ROOT=Path(__file__).resolve().parents[1]
PDF=ROOT/'A_Receipt_That_Had_Not_Caught_Up.pdf'

def main():
    doc=fitz.open(PDF)
    expected=['A Receipt That Had Not Caught Up','All thirteen matched pairs','What an empty receipt proves',
              'When the outcome stays unknown','How the comparison was controlled','What this result supports']
    pages=[]
    failures=[]
    if len(doc)!=len(expected):
        failures.append('Expected six deliberately composed pages; observed '+str(len(doc)))
    for i,page in enumerate(doc):
        text=' '.join(page.get_text().split())
        title_present=i<len(expected) and expected[i] in text
        bad=[]
        for block in page.get_text('dict')['blocks']:
            for line in block.get('lines',[]):
                for span in line.get('spans',[]):
                    x0,y0,x1,y1=span['bbox']
                    if x0<0 or y0<0 or x1>page.rect.width or y1>page.rect.height:
                        bad.append(span['text'])
        if not title_present:failures.append('Unexpected section flow on page '+str(i+1))
        if bad:failures.append('Out-of-bounds text on page '+str(i+1))
        pages.append({'page':i+1,'expected_title_present':title_present,'characters':len(text),'out_of_bounds_spans':bad})
    result={'status':'PASS' if not failures else 'FAIL','pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),
            'page_count':len(doc),'pages':pages,'failures':failures,
            'scope':'Structural checks only; root separately inspects rendered pages.'}
    (ROOT/'results/pdf_qa.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    if failures:raise SystemExit(1)

if __name__=='__main__':
    main()
