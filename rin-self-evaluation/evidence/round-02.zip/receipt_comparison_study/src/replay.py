"""Verify frozen source and replay retained events; no model calls."""
import datetime
import hashlib
import json
from pathlib import Path
from service import digest, outcome, transition

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replay_run(folder, spec, frozen):
    for name, field in [('initial_state.json','initial_state_sha256'), ('prompt.txt','prompt_sha256'),
                        ('launch_message.txt','launch_message_sha256')]:
        if sha(folder/name) != spec[field]:
            raise ValueError(f'{folder.name}: changed {name}')
    state = json.loads((folder/'initial_state.json').read_text())
    previous = '0'*64
    path = folder/'events.jsonl'
    events = [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
    for n, original in enumerate(events, 1):
        event = dict(original)
        saved_hash = event.pop('event_hash')
        if saved_hash != digest(event):
            raise ValueError(f'{folder.name}:{n}: event hash mismatch')
        if event['index'] != n or event['previous_event_hash'] != previous:
            raise ValueError(f'{folder.name}:{n}: chain mismatch')
        if datetime.datetime.fromisoformat(event['utc']) < datetime.datetime.fromisoformat(frozen['frozen_at_utc']):
            raise ValueError(f'{folder.name}:{n}: event before freeze')
        if event['state_before_hash'] != digest(state):
            raise ValueError(f'{folder.name}:{n}: prior state mismatch')
        state, response = transition(state, event['request'])
        if response != event['response'] or event['state_after_hash'] != digest(state):
            raise ValueError(f'{folder.name}:{n}: replay mismatch')
        previous = saved_hash
    if state != json.loads((folder/'state.json').read_text()):
        raise ValueError(f'{folder.name}: final state mismatch')
    return {'events': len(events), 'final_event_hash': previous,
            'mechanical': outcome(state), 'report': state['inner']['report'],
            'sequence': [(str(e['request'].get('op','<missing>')) if isinstance(e['request'],dict) else '<invalid-request>')
                         + (':'+e['response']['error'] if e['response'].get('error') else '') for e in events]}

def main():
    frozen = json.loads((ROOT/'protocol/frozen.json').read_text())
    for path, expected in frozen['source_hashes'].items():
        if sha(ROOT/path) != expected:
            raise ValueError(f'Frozen source changed: {path}')
    rows = [{**{k:v for k,v in r.items() if k != 'launch_message'},
             **replay_run(ROOT/'runs'/r['run_id'],r,frozen)} for r in frozen['runs']]
    result = {'status':'PASS','run_count':len(rows),'event_count':sum(r['events'] for r in rows),
              'frozen_protocol_sha256':sha(ROOT/'protocol/frozen.json'),'runs':rows}
    (ROOT/'results/replay.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':'PASS','runs':len(rows),'events':result['event_count'],
                      'finished':sum(r['mechanical']['finished'] for r in rows),
                      'safe_completions':sum(r['mechanical']['safe_grounded_completion'] for r in rows)},indent=2))

if __name__ == '__main__':
    main()
