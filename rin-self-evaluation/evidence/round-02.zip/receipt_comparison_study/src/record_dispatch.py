"""Root bookkeeping after accepted native spawn calls; not a serving attestation."""
import datetime
import json
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
p=ROOT/'provenance/native_dispatch.json'
f=json.loads((ROOT/'protocol/frozen.json').read_text())
record=json.loads(p.read_text())
existing={r['launch_order'] for r in record['dispatches']}
for n in map(int,sys.argv[1:]):
    if n in existing:
        raise SystemExit('Refusing duplicate dispatch record.')
    r=next(x for x in f['runs'] if x['launch_order']==n)
    record['dispatches'].append({'launch_order':n,'run_id':r['run_id'],'task_name':'/root/paired'+str(n).zfill(2),
        'requested_model':r['requested_model'],'fork_turns':'none','reasoning_effort_override':None,
        'spawn_result':'accepted','recorded_after_dispatch_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'launch_message_sha256':r['launch_message_sha256']})
record['dispatches'].sort(key=lambda x:x['launch_order'])
p.write_text(json.dumps(record,indent=2)+'\n')
print('Accepted dispatch records:',len(record['dispatches']))
