# The Experiment That Answers the Question

Record: JRR-SCIENTIFIC-IDENTIFICATION-2026-11-17-003. User-facing date: November 17, 2026, America/New_York.

## Scientific question and scope

Can requested native model configurations distinguish observational fit from identification of a physical target, choose experiments that preserve a guaranteed solution within a budget, and provide exact compatible-model certificates? This is an authored, finite, noiseless inference experiment. It is not a frontier-science discovery, a broad capability benchmark, a statistical failure-rate estimate, or an external replication.

The two earlier tool-recovery studies remain unchanged. This study changes the task: arithmetic and exact hypothesis enumeration are permitted, measurements are reliable, and success depends on inference and experimental design rather than recovery from service faults.

## Models and execution

Exactly 24 fresh native participant contexts are planned: six instrument profiles, two hidden truths per profile, and two requested model selectors per truth. The selectors are gpt-6-astra and gpt-6.2-astra. Use fork_turns=none and the same inherited reasoning setting without an explicit override. The requested selectors are recorded; exact serving snapshots, UI-tier equivalence, tokens, latency, and billing are not comparative endpoints.

One execution per declared cell. No outcome-dependent additions, rescue prompts, silent selector replacement, or retries of a poor inference result. Preserve model-access and transport failures as operational events, separately from scientific errors. Freeze instrument, oracle, tests, protocol, payloads, model mapping, dispatch order, participant prompts, and launch messages before the first participant action.

Shuffle the twelve matched pairs with a fixed seed and alternate which selector is dispatched first within each pair. Dispatch in that order with at most three participant contexts active concurrently. The two actors in a pair receive identical public data and instructions apart from opaque identifiers and work paths. Each receives its own empty calculation directory. Participants may run their own local Python calculations; no model API, network, other agent, instrument source, hidden state, oracle, other run, or evaluator output is permitted.

## Instrument families

### Polynomial response and unknown detector orientation

Physical response F(x)=a*x+c*x^2. Instrument output Y(x,r)=B+s*(F(x)+r), where r is a controlled physical reference added before measurement. Target: sign(a), the physical derivative at x=0; it is not the sign of the observed finite difference or of s*a.

The closed parameter family has integer B in0..60; a in{-12,..,-1,1,..,12}; c in{-4,..,4}; and detector orientation s in{-1,+1}, except the known-orientation profile fixes s=+1. Initial readings are at (x,r)=(1,0),(2,0). Available experiments are (0,0),(-1,0),(3,0), each costing one credit, and (1,1), costing one or two credits as stated. The detector parameters are fixed across all readings.

Four profiles each have two predeclared truths with identical initial public observations:

| Profile | Initial Y1,Y2 | Orientation | Credits | Cost of (1,1) | Initial compatible models | Minimum guaranteed cost |
| --- | --- | --- | ---: | ---: | ---: | ---: |
| Known orientation; unknown curvature | 30,35 | s=+1 | 1 | 1 | 7 | 1 |
| Target versus nuisance detail | 32,45 | Unknown | 1 | 1 | 8 | 1 |
| Complementary measurements | 30,30 | Unknown | 2 | 1 | 16 | 2 |
| Expensive decisive reference | 32,45 | Unknown | 2 | 2 | 8 | 2 |

For Y2-Y1=13, the declared bounds force s*a>0. A known reference reveals s and thus sign(a), while four nuisance-parameter models can remain. This inference is conditional on the stated finite bounds. An ordinary third point reveals more full-model information under a uniform illustrative distribution but leaves physical direction unresolved under the polarity symmetry. In the complementary profile, one ordinary measurement and one reference are both required.

### Quantized phase detection

The instrument returns y(t,delta)=1 when (beta+omega*t+delta) mod8<4, and zero otherwise. The family has beta in0..7 and omega in{-3,-1,1,3}. Target: sign(omega). Each probe samples an identically reset system with the same unknown beta and omega. Delta is a known controlled shift of the detector reference. Initial y(0,0)=y(1,0)=1 leaves eight compatible models.

The active profile offers A=(0,2), B=(1,1), C=(1,3), each costone, with two credits. A first, then B after A=0 or C after A=1, guarantees direction. B or C first loses the worst-case two-credit guarantee, although a favorable actual branch can still legitimately identify direction.

The passive profile offers (t,0) for t=2..7, each costone, with two credits. The transformation (beta,omega)->((3-beta)mod8,-omega) preserves every passive integer-time response and reverses direction. The two truths (1,+1) and (2,-1) exercise both active branches and form such a passive reflection pair.

## Objective and exact oracle

The actor is explicitly asked to identify the target within its budget whenever an adaptive strategy can do so for every initially compatible model. No prior probabilities are supplied. Information-gain calculations under a uniform distribution are explanatory diagnostics, not the optimization objective.

The evaluator always reconstructs the compatible set from the full declared family and delivered observations. An actor's registration is a scientific claim, never a restriction on evaluator hypotheses. For a compatible set S, identification means that every world in S has the same target sign.

The oracle exhaustively checks experiments and every nonempty result branch. A guaranteed strategy with budget b exists if the sign is already unique, or if some experiment of cost<=b leaves every result branch with a guaranteed strategy using the remaining budget. A separate minimum-cost recursion and explicit enumeration of trees up to two credits cross-check the finite cases. Repeated deterministic measurements supply no new information.

Across both selectors there are 20 initially guaranteed-identifiable contexts and four structurally unidentifiable passive contexts. Per selector: ten and two. Structural-impossible contexts are excluded from the target-completion denominator and from guarantee-preserving-design denominators.

## Recorded scientific claims

Every context must register before new measurements, including when it plans to stop without measuring. Registration contains the full initial compatible-model set, possible target signs, a boolean assertion of guaranteed identifiability within the credits, and a brief note. A claimed indistinguishability limitation may be certified with an opposite-sign pair that gives identical results for every available experiment. Registration is sealed without scientific grading feedback.

Finish contains the full remaining compatible-model set, possible signs, and concise report. The exact report is returned as the native final answer. Finish acknowledges recording only; a scientifically incorrect certificate is retained, not rejected with answer feedback.

Certificate comparison ignores ordering. Duplicate world entries are disallowed. World objects must contain exactly the declared parameter keys; integer-valued JSON numbers are normalized to integers, excluding booleans. Sign lists are compared as mathematical sets with valid labels. The feasibility field must be a boolean.

## Endpoints

Keep separate: exact initial compatible-set certificate; correct initial sign set; correct initial feasibility claim; valid structural nonidentifiability witness; actual final target identification; exact final compatible-set certificate; supported final sign set and report; nuisance-parameter overclaim; experiment choice; and measurement credits used.

A guarantee-losing decision occurs when the full compatible set before an action still admits a guaranteed solution within the remaining credits, but the chosen experiment has some possible result branch that no longer does. Score this before seeing which result actually occurs. Once recorded, later favorable results do not erase it. If the task was structurally impossible from the start, this criterion is not applicable.

A favorable actual branch can support a correct scientific conclusion even after a guarantee-losing choice. Do not call that supported conclusion false. Report observed target identification and identification without a guarantee-losing decision separately. These data evaluate choices on the observed path plus the exact counterfactual feasibility of each chosen action; they do not show how the actor would behave on every unobserved branch.

An actor can correctly report remaining ambiguity after a poor experiment. That preserves report accuracy but does not recover missed feasible identification or the lost design guarantee. Exhaustive certificates permit distinguishing target identification from unique identification of every parameter. Partial model-set omissions and extra inadmissible models are scored explicitly rather than collapsed into a vague success label.

Operational errors and over-budget measurement requests are separate from scientific claims. Twelve operational calls plus free finish bound the service; the one- or two-credit measurement budget is the scientific resource constraint. No latency or optimal polling inference is made.

## Verification and limits

Before launch, verify exact initial counts, minimum guaranteed costs, selected truth admissibility, paired public-task equality, both symmetry identities, the nonlinear known-orientation control, the target-versus-nuisance example, the costly-reference trap, and the phase planning policy. Review the source before freeze.

After launch, replay every service request/response, hash chain, and final state through the frozen instrument. Independently reconstruct candidate sets and exact scientific claims in a separate implementation without importing the primary model or oracle modules. Compare native final messages to sealed reports and inspect prose against observations. Retain own-calculation artifacts when produced.

The service log is harness-generated and not externally attested. State replacement precedes event append; this pair is not crash-atomic. Participants share a filesystem restricted by instruction rather than OS isolation. Complete host-tool transcripts and hidden reasoning are not retained. Requested selector identity is not independent backend attestation. Separate same-session reviewers provide same-lab verification, not external replication. The finite closed families, exact measurements, explicit goals, and small authored case set limit generalization.
