"""Create a shuffled model-blinded raw-record packet after all actors finish."""
import hashlib
import json
import random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    frozen = json.loads((ROOT / 'protocol/frozen.json').read_text())
    rows = []
    for run in frozen['runs']:
        rid = run['run_id']
        folder = ROOT / 'runs' / rid
        initial = json.loads((folder / 'initial_state.json').read_text())
        final = json.loads((folder / 'state.json').read_text())
        native = json.loads((ROOT / 'provenance/native_messages' / (rid + '.json')).read_text())
        assert final['finished'], rid
        assert native['message'] == final['report'], rid
        rows.append({'run_id': rid, 'profile_id': run['profile_id'],
                     'public_task': initial['task'], 'initial_state': initial,
                     'final_state': final,
                     'events': [json.loads(line) for line in (folder / 'events.jsonl').read_text().splitlines()],
                     'native_message': native['message']})
    random.Random(2026111803).shuffle(rows)
    result = {'scope': 'Raw shuffled records with model selectors and dispatch order withheld.',
              'frozen_at_utc': frozen['frozen_at_utc'],
              'frozen_protocol_sha256': hashlib.sha256((ROOT / 'protocol/frozen.json').read_bytes()).hexdigest(),
              'runs': rows}
    (ROOT / 'provenance/review_packet.json').write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    print(json.dumps({'blinded_runs': len(rows), 'events': sum(len(row['events']) for row in rows)}))


if __name__ == '__main__':
    main()
