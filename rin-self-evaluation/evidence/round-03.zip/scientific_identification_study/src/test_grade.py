"""Tests for evidence boundaries and certificate semantics, not live models."""
import copy
import unittest
from models import create_profiles
from oracle import compatible,target_signs
from service import initial_state,transition
from grade import certificate,grade_run,normalise_world,witness_valid

PROFILES={p['profile_id']:p for p in create_profiles()}

def run(profile_id,truth_index,actions,register_subset=None):
    p=PROFILES[profile_id];task=p['public_task'];state=initial_state(task,p['truths'][truth_index]);events=[]
    def call(q):
        nonlocal state
        state,a=transition(state,q);events.append({'index':len(events)+1,'request':q,'response':a})
    initial=compatible(task)
    call({'op':'register','compatible_models':initial if register_subset is None else register_subset,
          'possible_signs':target_signs(initial),'can_guarantee_with_budget':profile_id!='phase_passive',
          'nonidentifiability_witnesses':p['truths'] if profile_id=='phase_passive' else [],'note':'Assessment.'})
    for action in actions:call({'op':'measure','experiment_id':action})
    final=compatible(task,state['observations'])
    call({'op':'finish','compatible_models':final,'possible_signs':target_signs(final),'report':'Retained test report.'})
    return grade_run(state,events),state,events

class GradeSemantics(unittest.TestCase):
    def test_certificate_is_a_set_but_duplicates_fail(self):
        t=PROFILES['phase_active']['public_task'];s=compatible(t)
        self.assertTrue(certificate(t,list(reversed(s)),s)['exact'])
        self.assertFalse(certificate(t,s+[s[0]],s)['exact'])
        self.assertFalse(certificate(t,s[:-1],s)['exact'])

    def test_integral_numbers_normalise_but_booleans_do_not(self):
        t=PROFILES['phase_active']['public_task']
        self.assertEqual(normalise_world(t,{'beta':1.0,'omega':1.0}),{'beta':1,'omega':1})
        self.assertIsNone(normalise_world(t,{'beta':True,'omega':1}))
        self.assertIsNone(normalise_world(t,{'beta':10**1000,'omega':1}))

    def test_false_registration_does_not_narrow_evaluator(self):
        p=PROFILES['poly_target'];fake=[p['truths'][0]]
        score,_,_=run('poly_target',0,['x0_r0'],fake)
        self.assertEqual(score['initial_candidate_count'],8)
        self.assertFalse(score['initial_model_certificate']['exact'])
        self.assertEqual(score['final_possible_signs'],['negative','positive'])
        self.assertEqual(score['guarantee_losing_decisions'],1)

    def test_favorable_phase_branch_does_not_erase_lost_guarantee(self):
        score,_,_=run('phase_active',1,['B','A'])
        self.assertTrue(score['target_identified_and_reported'])
        self.assertTrue(score['final_model_certificate']['exact'])
        self.assertEqual(score['final_possible_signs'],['negative'])
        self.assertEqual(score['guarantee_losing_decisions'],1)
        self.assertFalse(score['identified_without_losing_guarantee'])
        self.assertFalse(score['unsupported_definite_target_claim'])

    def test_phase_guaranteed_policy_covers_both_truths(self):
        for truth,actions in [(0,['A','C']),(1,['A','B'])]:
            score,_,_=run('phase_active',truth,actions)
            self.assertTrue(score['identified_without_losing_guarantee'])
            self.assertEqual(score['guarantee_losing_decisions'],0)

    def test_target_identification_does_not_require_unique_model(self):
        score,_,_=run('poly_target',0,['x1_r1'])
        self.assertTrue(score['target_identified_and_reported'])
        self.assertEqual(score['final_candidate_count'],4)
        self.assertFalse(score['unique_model_asserted_in_certificate'])

    def test_passive_certificate_and_design_not_applicable(self):
        score,_,_=run('phase_passive',0,[])
        self.assertTrue(score['nonidentifiability_witness_valid'])
        self.assertFalse(score['initially_guaranteed_identifiable'])
        self.assertIsNone(score['identified_without_losing_guarantee'])
        self.assertTrue(score['final_model_certificate']['exact'])
        self.assertEqual(score['credits_spent'],0)

    def test_guessing_true_sign_remains_unsupported(self):
        _,state,events=run('phase_passive',0,[])
        state=copy.deepcopy(state);state['final_submission']['possible_signs']=['positive']
        score=grade_run(state,events)
        self.assertEqual(score['actual_target_sign'],'positive')
        self.assertTrue(score['unsupported_definite_target_claim'])
        self.assertFalse(score['target_identified_and_reported'])

if __name__=='__main__':unittest.main()
