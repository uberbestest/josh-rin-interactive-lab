"""Deterministic synthetic instruments. Responses contain no grading feedback."""
from __future__ import annotations
import copy
import hashlib
import json
from models import evaluate

MAX_ACTIONS=12

def canon(x):
    return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)

def digest(x):
    return hashlib.sha256(canon(x).encode()).hexdigest()

def initial_state(task,truth):
    return {'task':copy.deepcopy(task),'truth':copy.deepcopy(truth),
        'credits_remaining':task['budget'],'calls':0,'registration':None,
        'observations':copy.deepcopy(task['initial_observations']),'measurements':[],
        'finished':False,'final_submission':None,'report':None}

def error(code,message):
    return {'ok':False,'error':code,'message':message}

def transition(state,request):
    s=copy.deepcopy(state)
    if not isinstance(request,dict):
        return s,error('INVALID_REQUEST','Request must be a JSON object.')
    if s['finished']:
        return s,error('SESSION_CLOSED','The final submission is sealed.')
    op=request.get('op')
    if op=='finish':
        report=request.get('report')
        if not isinstance(report,str) or not report.strip():
            return s,error('INVALID_REPORT','Provide a nonempty report string.')
        s['finished']=True
        s['report']=report
        s['final_submission']={k:copy.deepcopy(v) for k,v in request.items() if k!='op'}
        return s,{'ok':True,'submission_recorded':True}
    if s['calls']>=MAX_ACTIONS:
        return s,error('ACTION_BUDGET_EXHAUSTED','No operational calls remain. Submit your final report with finish.')
    s['calls']+=1
    if op=='register':
        if s['registration'] is not None:
            return s,error('ALREADY_REGISTERED','The initial assessment is already sealed.')
        s['registration']={k:copy.deepcopy(v) for k,v in request.items() if k!='op'}
        return s,{'ok':True,'registration_recorded':True,'credits_remaining':s['credits_remaining']}
    if op=='measure':
        if s['registration'] is None:
            return s,error('ASSESSMENT_REQUIRED','Register your initial assessment before measuring.')
        experiment=next((e for e in s['task']['experiments'] if e['id']==request.get('experiment_id')),None)
        if experiment is None:
            return s,error('UNKNOWN_EXPERIMENT','Use an experiment_id listed in your assignment.')
        if experiment['cost']>s['credits_remaining']:
            return s,error('INSUFFICIENT_CREDITS','The requested experiment exceeds your remaining measurement credits. No measurement was made.')
        value=evaluate(s['task'],s['truth'],experiment['settings'])
        observation={'experiment_id':experiment['id'],'settings':copy.deepcopy(experiment['settings']),'value':value}
        s['credits_remaining']-=experiment['cost']
        s['observations'].append(observation)
        s['measurements'].append({'number':len(s['measurements'])+1,'observation':observation,'cost':experiment['cost']})
        return s,{'ok':True,'observation':observation,'credits_remaining':s['credits_remaining']}
    return s,error('UNKNOWN_OPERATION','Use register, measure, or finish.')
