"""Compare primary and independently implemented endpoints and exact-text reviews."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(relative):
    return json.loads((ROOT / relative).read_text())


def main():
    primary = read('results/summary.json')
    independent = read('results/independent_review.json')
    frozen = read('protocol/frozen.json')
    packet = read('provenance/review_packet.json')
    dispatch = read('provenance/native_dispatch.json')['dispatches']
    assert independent['integrity_status'] == 'verified'
    assert primary['frozen_protocol_sha256'] == independent['frozen_protocol_sha256']
    assert primary['events'] == independent['event_count'] == 78
    a = {r['run_id']: r for r in primary['runs']}
    b = {r['run_id']: r for r in independent['runs']}
    c = {r['run_id']: r for r in packet['runs']}
    assert set(a) == set(b) == set(c) == {r['run_id'] for r in frozen['runs']}
    assert len(a) == len(dispatch) == 24
    assert [r['launch_order'] for r in dispatch] == list(range(1, 25))
    for d, f in zip(dispatch, frozen['runs']):
        for key in ['launch_order', 'run_id', 'requested_model', 'launch_message_sha256']:
            assert d[key] == f[key], (d['run_id'], key)
        assert d['spawn_result'] == 'accepted' and d['fork_turns'] == 'none'
        assert d['reasoning_effort_override'] is None

    names = ['initial_candidate_count', 'initial_possible_signs', 'initially_guaranteed_identifiable',
             'initial_signs_exact', 'initial_feasibility_correct', 'nonidentifiability_witness_valid',
             'final_candidate_count', 'final_possible_signs', 'final_signs_exact',
             'target_identified_from_observations', 'target_identified_and_reported',
             'guarantee_losing_decisions', 'identified_without_losing_guarantee',
             'unsupported_definite_target_claim', 'calls', 'measurements', 'credits_spent',
             'credits_remaining', 'finished']
    comparisons = judgments = native_matches = raw_matches = 0
    details = []
    for rid in sorted(a):
        row, other = a[rid], b[rid]
        mechanical = row['mechanical']
        expected = {key: mechanical[key] for key in names}
        expected.update({'initial_model_certificate_exact': mechanical['initial_model_certificate']['exact'],
                         'final_model_certificate_exact': mechanical['final_model_certificate']['exact'],
                         'native_report_exact_match': row['native_report_exact_match'],
                         'event_count': row['events'],
                         'report_sha256': hashlib.sha256(row['report'].encode()).hexdigest()})
        for key, value in expected.items():
            assert value == other[key], (rid, key, value, other[key])
            comparisons += 1
        for key in ['report_supported', 'nuisance_overclaim', 'reported_target']:
            assert row['report_review'][key] == other[key], (rid, key)
            judgments += 1
        assert other['observations_match_truth'] and other['state_replay_valid']
        assert other['hash_chain_and_endpoints_valid'] and other['post_freeze_event_chronology_valid']
        assert not other['integrity_errors']
        raw = c[rid]
        folder = ROOT / 'runs' / rid
        assert raw['initial_state'] == json.loads((folder / 'initial_state.json').read_text())
        assert raw['final_state'] == json.loads((folder / 'state.json').read_text())
        assert raw['events'] == [json.loads(line) for line in (folder / 'events.jsonl').read_text().splitlines()]
        native = read('provenance/native_messages/' + rid + '.json')
        assert native['message'] == raw['native_message'] == row['report']
        native_matches += 1
        raw_matches += 1
        details.append({'run_id': rid, 'mechanical_fields_agreed': len(expected),
                        'manual_judgments_agreed': 3, 'raw_packet_matches': True,
                        'independent_state_replay_valid': True})
    result = {'status': 'PASS', 'run_count': len(a), 'events': primary['events'],
              'mechanical_comparisons': comparisons, 'report_judgment_comparisons': judgments,
              'native_report_exact_matches': native_matches, 'packet_raw_matches': raw_matches,
              'accepted_dispatches': len(dispatch), 'independent_integrity_runs': len(details),
              'frozen_protocol_sha256': primary['frozen_protocol_sha256'], 'runs': details,
              'scope': 'Exact data and field agreement between two implementations; manual report judgments remain human-readable adjudications by two same-lab model reviewers, not external replication.'}
    (ROOT / 'results/comparison_verification.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('runs', 'scope')}, indent=2))


if __name__ == '__main__':
    main()
