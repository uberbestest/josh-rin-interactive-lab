"""Summarize frozen mechanical endpoints with exact-text manual report review."""
import csv
import hashlib
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def main():
    replay=json.loads((ROOT/'results/replay.json').read_text())
    review={r['run_id']:r for r in json.loads((ROOT/'provenance/root_adjudications.json').read_text())['runs']}
    rows=[]
    for raw in replay['runs']:
        r=dict(raw);rid=r['run_id'];m=r['mechanical'];a=review[rid]
        assert m['finished'],rid
        assert a['report_sha256']==hashlib.sha256(r['report'].encode()).hexdigest(),rid
        native=json.loads((ROOT/'provenance/native_messages'/f'{rid}.json').read_text())
        r['native_report_exact_match']=native['message']==r['report']
        r['report_review']=a
        r['category']='feasible' if m['initially_guaranteed_identifiable'] else 'structurally_unidentifiable'
        r['measurement_sequence']=[c['experiment_id'] for c in m['choices']]
        rows.append(r)
    models={}
    for name in ['gpt-6-astra','gpt-6.2-astra']:
        rs=[r for r in rows if r['requested_model']==name]
        feasible=[r for r in rs if r['category']=='feasible']
        impossible=[r for r in rs if r['category']!='feasible']
        models[name]={'contexts':len(rs),'feasible':len(feasible),'structurally_unidentifiable':len(impossible),
            'exact_initial_model_sets':sum(r['mechanical']['initial_model_certificate']['exact'] for r in rs),
            'exact_initial_sign_sets':sum(r['mechanical']['initial_signs_exact'] for r in rs),
            'correct_initial_feasibility':sum(r['mechanical']['initial_feasibility_correct'] for r in rs),
            'identified_targets':sum(r['mechanical']['target_identified_and_reported'] for r in feasible),
            'identified_without_losing_guarantee':sum(r['mechanical']['identified_without_losing_guarantee'] for r in feasible),
            'guarantee_losing_decisions':sum(r['mechanical']['guarantee_losing_decisions'] for r in rs),
            'exact_final_model_sets':sum(r['mechanical']['final_model_certificate']['exact'] for r in rs),
            'exact_final_sign_sets':sum(r['mechanical']['final_signs_exact'] for r in rs),
            'valid_nonidentifiability_witnesses':sum(r['mechanical']['nonidentifiability_witness_valid'] for r in impossible),
            'supported_reports':sum(r['report_review']['report_supported'] for r in rs),
            'unsupported_definite_targets':sum(r['mechanical']['unsupported_definite_target_claim'] for r in rs),
            'nuisance_overclaims_in_prose':sum(r['report_review']['nuisance_overclaim'] for r in rs),
            'operational_calls':sum(r['mechanical']['calls'] for r in rs),
            'measurements':sum(r['mechanical']['measurements'] for r in rs),
            'credits_spent':sum(r['mechanical']['credits_spent'] for r in rs),
            'operational_errors':sum(len(r['mechanical']['operational_errors']) for r in rs),
            'service_events':sum(r['events'] for r in rs)}
    pairs=[]
    tallies={k:{'newer_wins':0,'ties':0,'older_wins':0} for k in ['identified_target','guarantee_preserving_identification','initial_certificate','final_certificate','supported_report']}
    for pid in sorted({r['pair_id'] for r in rows}):
        old=next(r for r in rows if r['pair_id']==pid and r['requested_model']=='gpt-6-astra')
        new=next(r for r in rows if r['pair_id']==pid and r['requested_model']=='gpt-6.2-astra')
        pairs.append({'pair_id':pid,'profile_id':old['profile_id'],'truth_index':old['truth_index'],'actual_target':old['actual_target'],
            'category':old['category'],'old_run':old['run_id'],'new_run':new['run_id'],
            'old_measurements':old['measurement_sequence'],'new_measurements':new['measurement_sequence'],
            'old_identified':old['mechanical']['target_identified_and_reported'],'new_identified':new['mechanical']['target_identified_and_reported']})
        tests={'initial_certificate':(old['mechanical']['initial_model_certificate']['exact'],new['mechanical']['initial_model_certificate']['exact']),
            'final_certificate':(old['mechanical']['final_model_certificate']['exact'],new['mechanical']['final_model_certificate']['exact']),
            'supported_report':(old['report_review']['report_supported'],new['report_review']['report_supported'])}
        if old['category']=='feasible':
            tests['identified_target']=(old['mechanical']['target_identified_and_reported'],new['mechanical']['target_identified_and_reported'])
            tests['guarantee_preserving_identification']=(old['mechanical']['identified_without_losing_guarantee'],new['mechanical']['identified_without_losing_guarantee'])
        for key,(a,b) in tests.items():
            tallies[key]['newer_wins' if b>a else 'older_wins' if a>b else 'ties']+=1
    result={'record':'JRR-SCIENTIFIC-IDENTIFICATION-2026-11-17-003','models':models,'pairwise':tallies,
        'contexts':len(rows),'events':sum(r['events'] for r in rows),'operational_calls':sum(r['mechanical']['calls'] for r in rows),
        'measurements':sum(r['mechanical']['measurements'] for r in rows),'credits_spent':sum(r['mechanical']['credits_spent'] for r in rows),
        'native_report_exact_matches':sum(r['native_report_exact_match'] for r in rows),
        'frozen_protocol_sha256':replay['frozen_protocol_sha256'],'pairs':pairs,'runs':rows,
        'scope':'Descriptive authored exact-inference tasks. Manual report judgments are bound to exact text hashes.'}
    (ROOT/'results/summary.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    fields=['launch_order','run_id','pair_id','profile_id','requested_model','actual_target','category','initial_exact','feasibility_correct','identified','guarantee_losses','final_exact','final_signs_exact','structural_witness','report_supported','measurements','credits']
    with (ROOT/'results/per_run.csv').open('w',newline='') as out:
        w=csv.DictWriter(out,fieldnames=fields);w.writeheader()
        for r in rows:
            m=r['mechanical'];w.writerow({**{k:r[k] for k in fields[:7]},'initial_exact':m['initial_model_certificate']['exact'],
                'feasibility_correct':m['initial_feasibility_correct'],'identified':m['target_identified_and_reported'],
                'guarantee_losses':m['guarantee_losing_decisions'],'final_exact':m['final_model_certificate']['exact'],
                'final_signs_exact':m['final_signs_exact'],'structural_witness':m['nonidentifiability_witness_valid'],
                'report_supported':r['report_review']['report_supported'],'measurements':m['measurements'],'credits':m['credits_spent']})
    print(json.dumps({k:result[k] for k in ['models','pairwise','contexts','events','measurements','credits_spent','native_report_exact_matches']},indent=2))

if __name__=='__main__':main()
