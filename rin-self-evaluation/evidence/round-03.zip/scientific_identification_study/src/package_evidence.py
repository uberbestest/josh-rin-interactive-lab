"""Package a settled study snapshot, its exact inventory, and an external receipt.

Run only after the README, scientific checks, report, reviews and PDF QA are final.
This script never launches participants or modifies frozen scientific files.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
STUDY_NAME = 'scientific_identification_study'
INVENTORY = 'provenance/file_inventory.json'
ARCHIVE_NAME = 'Scientific_Identification_Evidence.zip'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def ignored(relative: Path) -> bool:
    return ('__pycache__' in relative.parts or relative.suffix in ('.pyc', '.pyo')
            or (relative.parts[0] == 'runs' and relative.name == 'lock')
            or relative.name.endswith(('~', '.tmp', '.temp', '.swp', '.swo')))


def files(root: Path) -> dict[str, Path]:
    answer = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if ignored(relative):
            continue
        if path.is_symlink():
            raise ValueError('Study snapshot contains a symlink: ' + relative.as_posix())
        if path.is_file():
            answer[relative.as_posix()] = path
        elif not path.is_dir():
            raise ValueError('Study snapshot contains a nonregular file: ' + relative.as_posix())
    return answer


def read_json(root: Path, name: str):
    return json.loads((root / name).read_text(encoding='utf-8'))


def outside(root: Path, path: Path, label: str) -> None:
    if path.resolve().is_relative_to(root):
        raise ValueError(label + ' must be outside the study snapshot')


def package(root: Path, archive: Path, receipt_path: Path) -> dict:
    root = root.resolve()
    archive = archive.resolve()
    receipt_path = receipt_path.resolve()
    if root.name != STUDY_NAME:
        raise ValueError('Expected project directory named ' + STUDY_NAME)
    outside(root, archive, 'Archive')
    outside(root, receipt_path, 'Packaging receipt')
    checksum_path = archive.with_suffix('.sha256')
    if len({archive, checksum_path, receipt_path}) != 3:
        raise ValueError('Archive, checksum and receipt paths must be distinct')
    for required in ['README.txt', 'The_Experiment_That_Answers_the_Question.pdf',
                     'provenance/REPORT_REVIEW.md', 'provenance/INDEPENDENT_REVIEW.md']:
        if not (root / required).is_file() or not (root / required).stat().st_size:
            raise ValueError('Final required artifact missing or empty: ' + required)
    summary = read_json(root, 'results/summary.json')
    if summary['contexts'] != 24 or any(not row['mechanical']['finished'] for row in summary['runs']):
        raise ValueError('All 24 planned contexts must be finished')
    if read_json(root, 'results/comparison_verification.json')['status'] != 'PASS':
        raise ValueError('Cross-implementation verification has not passed')
    if read_json(root, 'results/independent_review.json')['integrity_status'] != 'verified':
        raise ValueError('Independent audit has not verified integrity')
    qa = read_json(root, 'results/pdf_qa.json')
    if qa['status'] != 'PASS' or str(qa.get('visual_review', '')).lower().startswith('pending'):
        raise ValueError('Final PDF QA is incomplete')
    pdf = root / 'The_Experiment_That_Answers_the_Question.pdf'
    if qa['pdf_sha256'] != digest(pdf.read_bytes()):
        raise ValueError('PDF QA refers to a different PDF')
    frozen = read_json(root, 'protocol/frozen.json')
    frozen_sha = digest((root / 'protocol/frozen.json').read_bytes())
    if frozen_sha != summary['frozen_protocol_sha256']:
        raise ValueError('Frozen protocol does not match the checked summary')
    for name, expected in frozen['source_hashes'].items():
        if digest((root / name).read_bytes()) != expected:
            raise ValueError('Frozen file changed: ' + name)

    paths = files(root)
    paths.pop(INVENTORY, None)
    payloads = {name: path.read_bytes() for name, path in paths.items()}
    inventory = {
        'format_version': 1, 'record': frozen['record'], 'root_directory': STUDY_NAME,
        'scope': 'Every included regular file is inventoried except this inventory itself.',
        'exclusions': ['__pycache__ directories', '*.pyc and *.pyo', 'per-run files named lock',
                       'temporary suffixes: ~, .tmp, .temp, .swp, .swo'],
        'files': [{'path': name, 'bytes': len(data), 'sha256': digest(data)}
                  for name, data in sorted(payloads.items())],
    }
    inventory_bytes = (json.dumps(inventory, indent=2, ensure_ascii=False, sort_keys=True) + '\n').encode()
    (root / INVENTORY).write_bytes(inventory_bytes)
    payloads[INVENTORY] = inventory_bytes
    if set(files(root)) != set(payloads):
        raise ValueError('Snapshot membership changed while packaging; wait for writers to finish')
    for name, data in payloads.items():
        if (root / name).read_bytes() != data:
            raise ValueError('Snapshot changed while packaging: ' + name)

    archive.parent.mkdir(parents=True, exist_ok=True)
    temporary = archive.with_name('.' + archive.name + '.' + str(os.getpid()) + '.tmp')
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
            for name, data in sorted(payloads.items()):
                info = zipfile.ZipInfo(STUDY_NAME + '/' + name, date_time=(1980, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                bundle.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        if set(files(root)) != set(payloads):
            raise ValueError('Snapshot membership changed before packaging completed')
        for name, data in payloads.items():
            if (root / name).read_bytes() != data:
                raise ValueError('Snapshot changed before packaging completed: ' + name)
        temporary.replace(archive)
    finally:
        temporary.unlink(missing_ok=True)
    archive_sha = digest(archive.read_bytes())
    checksum_path.write_text(archive_sha + '  ' + archive.name + '\n', encoding='utf-8')
    receipt = {
        'status': 'PASS', 'record': frozen['record'],
        'packaged_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'archive': str(archive), 'archive_bytes': archive.stat().st_size, 'archive_sha256': archive_sha,
        'checksum_file': str(checksum_path), 'inventory_file': INVENTORY,
        'inventoried_files': len(inventory['files']), 'archive_files': len(payloads),
        'inventory_sha256': digest(inventory_bytes), 'frozen_protocol_sha256': frozen_sha,
        'scope': 'Deterministic ZIP metadata; snapshot content and membership checked before publication. Receipt is external to avoid self-reference.',
    }
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    return receipt


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', type=Path, default=ROOT.parent / ARCHIVE_NAME)
    parser.add_argument('--receipt', type=Path, help='External JSON receipt; defaults beside archive')
    args = parser.parse_args()
    result = package(args.root, args.output, args.receipt or args.output.with_suffix('.packaging.json'))
    print(json.dumps({key: result[key] for key in ['status', 'archive', 'archive_files', 'inventoried_files',
                                                  'archive_bytes', 'archive_sha256']}, indent=2))


if __name__ == '__main__':
    main()
