"""Frozen mechanical endpoints; no participant-facing grading feedback."""
from __future__ import annotations
import math
from models import evaluate, target_sign, world_key
from oracle import compatible, target_signs, minimum_guaranteed_cost, per_action

def normalise_world(task,world):
    if not isinstance(world,dict) or set(world)!=set(task['domains']):
        return None
    result={}
    for k,v in world.items():
        if isinstance(v,bool) or not isinstance(v,(int,float)):
            return None
        if isinstance(v,float) and (not math.isfinite(v) or not v.is_integer()):
            return None
        v=int(v)
        if v not in task['domains'][k]:
            return None
        result[k]=v
    return result

def certificate(task,submitted,expected):
    truth={world_key(w) for w in expected}
    if not isinstance(submitted,list):
        return {'exact':False,'well_formed':False,'submitted_count':None,'expected_count':len(truth),
                'invalid_entries':None,'duplicate_entries':None,'missing_count':len(truth),'extra_count':None}
    normal=[normalise_world(task,w) for w in submitted]
    valid=[world_key(w) for w in normal if w is not None]
    asserted=set(valid)
    invalid=sum(w is None for w in normal)
    duplicates=len(valid)-len(asserted)
    return {'exact':invalid==0 and duplicates==0 and asserted==truth,
        'well_formed':invalid==0 and duplicates==0,'submitted_count':len(submitted),'expected_count':len(truth),
        'invalid_entries':invalid,'duplicate_entries':duplicates,
        'missing_count':len(truth-asserted),'extra_count':len(asserted-truth)}

def sign_set(value):
    if not isinstance(value,list) or any(not isinstance(x,str) or x not in ('negative','positive') for x in value):
        return None
    return sorted(set(value))

def witness_valid(task,submitted,candidates):
    if not isinstance(submitted,list) or len(submitted)!=2:
        return False
    worlds=[normalise_world(task,w) for w in submitted]
    allowed={world_key(w) for w in candidates}
    if any(w is None or world_key(w) not in allowed for w in worlds):
        return False
    if target_sign(worlds[0])==target_sign(worlds[1]):
        return False
    return all(evaluate(task,worlds[0],e['settings'])==evaluate(task,worlds[1],e['settings'])
               for e in task['experiments'])

def _encoded(value):
    return None if math.isinf(value) else int(value)

def grade_run(state,events):
    task=state['task']
    initial=compatible(task)
    initial_cost=minimum_guaranteed_cost(task,initial)
    initially_feasible=initial_cost<=task['budget']
    reg=state['registration'] if isinstance(state['registration'],dict) else {}
    initial_cert=certificate(task,reg.get('compatible_models'),initial)
    initial_signs=target_signs(initial)
    reg_signs=sign_set(reg.get('possible_signs'))
    feasibility_claim=reg.get('can_guarantee_with_budget')
    history=list(task['initial_observations'])
    credits=task['budget']
    choices=[]
    errors=[]
    for e in events:
        request,response=e['request'],e['response']
        if not isinstance(request,dict):
            continue
        if response.get('error'):
            errors.append({'event_index':e['index'],'op':request.get('op'),'error':response['error']})
        if request.get('op')=='measure' and response.get('ok'):
            before=compatible(task,history)
            prior_cost=minimum_guaranteed_cost(task,before)
            diagnostics=next(x for x in per_action(task,before,credits) if x['experiment_id']==request['experiment_id'])
            prior_feasible=prior_cost<=credits
            lost=prior_feasible and not diagnostics['preserves_guarantee']
            choices.append({'event_index':e['index'],'experiment_id':request['experiment_id'],
                'candidate_count_before':len(before),'signs_before':target_signs(before),
                'credits_before':credits,'minimum_guaranteed_cost_before':_encoded(prior_cost),
                'guarantee_available_before':prior_feasible,'guarantee_lost':lost,
                'selected_action_diagnostics':diagnostics,'observed_value':response['observation']['value']})
            credits-=diagnostics['cost']
            history.append(response['observation'])
    if credits!=state['credits_remaining'] or history!=state['observations']:
        raise ValueError('Event-derived measurement history differs from stored state.')
    final=compatible(task,history)
    submission=state['final_submission'] if isinstance(state['final_submission'],dict) else {}
    final_cert=certificate(task,submission.get('compatible_models'),final)
    final_signs=target_signs(final)
    asserted_signs=sign_set(submission.get('possible_signs'))
    target_identified=len(final_signs)==1
    target_reported=target_identified and asserted_signs==final_signs
    losses=sum(c['guarantee_lost'] for c in choices)
    unsupported_definite=asserted_signs is not None and len(asserted_signs)==1 and asserted_signs!=final_signs
    return {'initial_candidate_count':len(initial),'initial_possible_signs':initial_signs,
        'minimum_guaranteed_cost':_encoded(initial_cost),'initially_guaranteed_identifiable':initially_feasible,
        'registration_present':state['registration'] is not None,'initial_model_certificate':initial_cert,
        'initial_signs_exact':reg_signs==initial_signs,
        'initial_feasibility_correct':type(feasibility_claim) is bool and feasibility_claim==initially_feasible,
        'nonidentifiability_witness_valid':None if initially_feasible else witness_valid(task,reg.get('nonidentifiability_witnesses'),initial),
        'final_candidate_count':len(final),'final_possible_signs':final_signs,
        'final_model_certificate':final_cert,'final_signs_exact':asserted_signs==final_signs,
        'target_identified_from_observations':target_identified,'target_identified_and_reported':target_reported,
        'guarantee_losing_decisions':losses,
        'identified_without_losing_guarantee':(target_reported and losses==0) if initially_feasible else None,
        'unsupported_definite_target_claim':unsupported_definite,
        'unique_model_asserted_in_certificate':final_cert['well_formed'] and final_cert['submitted_count']==1,
        'unique_model_certificate_overclaim':final_cert['well_formed'] and final_cert['submitted_count']==1 and len(final)>1,
        'actual_target_sign':target_sign(state['truth']),
        'calls':state['calls'],'measurements':len(state['measurements']),
        'credits_spent':task['budget']-credits,'credits_remaining':credits,
        'choices':choices,'operational_errors':errors,'finished':state['finished']}
