#!/usr/bin/env python3
"""Independent, model-blinded audit of the exact scientific inference study.

This implementation is authored after protocol freeze from audit_spec.json and
the blinded raw packet alone.  It intentionally imports no study source module.
Standard library only.  Human prose adjudications are bound to report SHA256s.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import itertools
import json
import math
from collections import defaultdict
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any


STUDY = Path(__file__).resolve().parents[1]
SPEC_PATH = STUDY / "provenance" / "audit_spec.json"
PACKET_PATH = STUDY / "provenance" / "review_packet.json"
ADJUDICATION_PATH = STUDY / "provenance" / "independent_adjudications.json"
RESULT_PATH = STUDY / "results" / "independent_review.json"
ZERO_HASH = "0" * 64


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def object_hash(value: Any) -> str:
    return hashlib.sha256(canonical_bytes(value)).hexdigest()


def text_hash(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def read_json(path: Path) -> Any:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def strict_integer(value: Any) -> int | None:
    """Accept JSON integers and finite integral floats, explicitly not bools."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    if isinstance(value, float) and (not math.isfinite(value) or not value.is_integer()):
        return None
    return int(value)


def utc_time(value: str) -> datetime:
    stamp = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if stamp.tzinfo is None:
        raise ValueError("A provenance timestamp lacks an explicit timezone")
    return stamp.astimezone(timezone.utc)


def reading(family: str, world: dict[str, int], settings: dict[str, int]) -> int:
    """The two instrument equations, independently transcribed from the spec."""
    if family == "polynomial":
        x = settings["x"]
        r = settings["r"]
        return world["B"] + world["s"] * (world["a"] * x + world["c"] * x * x + r)
    if family == "phase":
        residue = (world["beta"] + world["omega"] * settings["t"] + settings["delta"]) % 8
        return int(residue < 4)
    raise ValueError(f"Unknown model family {family!r}")


class ExactProblem:
    """Finite worlds and exhaustive adaptive decision trees with integer costs."""

    def __init__(self, public_task: dict[str, Any]):
        self.public_task = public_task
        self.family = public_task["family"]
        self.keys = tuple(sorted(public_task["domains"]))
        self.domains = {key: frozenset(public_task["domains"][key]) for key in self.keys}
        self.world_tuples = tuple(itertools.product(*(public_task["domains"][k] for k in self.keys)))
        self.worlds = tuple(dict(zip(self.keys, values)) for values in self.world_tuples)
        self.world_index = {values: i for i, values in enumerate(self.world_tuples)}
        self.target = "a" if self.family == "polynomial" else "omega"
        self.sign_values = tuple("positive" if w[self.target] > 0 else "negative" for w in self.worlds)
        self.experiments = {entry["id"]: entry for entry in public_task["experiments"]}
        if len(self.experiments) != len(public_task["experiments"]):
            raise ValueError("Duplicate experiment identifiers")
        self.outputs = {
            name: tuple(reading(self.family, w, entry["settings"]) for w in self.worlds)
            for name, entry in self.experiments.items()
        }
        self.initial = self.filter_observations(tuple(range(len(self.worlds))),
                                                public_task["initial_observations"])
        self.initial_budget = public_task["budget"]
        if isinstance(self.initial_budget, bool) or self.initial_budget not in (1, 2):
            raise ValueError("This audit is specified for one or two initial credits")
        for experiment in self.experiments.values():
            if type(experiment["cost"]) is not int or experiment["cost"] <= 0:
                raise ValueError("Experiment costs must be positive integers")

    def signs(self, indices: tuple[int, ...]) -> list[str]:
        return sorted({self.sign_values[i] for i in indices})

    def filter_observations(self, indices: tuple[int, ...], observations: list[dict[str, Any]]) -> tuple[int, ...]:
        return tuple(i for i in indices if all(
            reading(self.family, self.worlds[i], obs["settings"]) == obs["value"]
            for obs in observations))

    def partition(self, indices: tuple[int, ...], experiment_id: str) -> dict[int, tuple[int, ...]]:
        groups = defaultdict(list)
        outputs = self.outputs[experiment_id]
        for i in indices:
            groups[outputs[i]].append(i)
        return {outcome: tuple(group) for outcome, group in sorted(groups.items())}

    @lru_cache(maxsize=None)
    def guaranteed(self, indices: tuple[int, ...], credits: int) -> bool:
        if not indices:
            return False
        if len(self.signs(indices)) == 1:
            return True
        for name, experiment in self.experiments.items():
            cost = experiment["cost"]
            if cost <= credits and all(self.guaranteed(branch, credits - cost)
                                       for branch in self.partition(indices, name).values()):
                return True
        return False

    def choice_preserves_guarantee(self, indices: tuple[int, ...], credits: int, experiment_id: str) -> bool:
        cost = self.experiments[experiment_id]["cost"]
        return cost <= credits and bool(indices) and all(
            self.guaranteed(branch, credits - cost)
            for branch in self.partition(indices, experiment_id).values())

    def safe_actions(self, indices: tuple[int, ...], credits: int) -> list[str]:
        return [name for name in self.experiments
                if self.choice_preserves_guarantee(indices, credits, name)]

    def normalize_world(self, item: Any) -> tuple[int, ...] | None:
        if not isinstance(item, dict) or set(item) != set(self.keys):
            return None
        values = tuple(strict_integer(item[key]) for key in self.keys)
        if any(value is None or value not in self.domains[key]
               for key, value in zip(self.keys, values)):
            return None
        return values

    def models_exact(self, certificate: Any, indices: tuple[int, ...]) -> bool:
        if not isinstance(certificate, list):
            return False
        normalized = [self.normalize_world(item) for item in certificate]
        if any(item is None for item in normalized):
            return False
        if len(normalized) != len(set(normalized)):
            return False
        return set(normalized) == {self.world_tuples[i] for i in indices}

    def signs_exact(self, certificate: Any, indices: tuple[int, ...]) -> bool:
        return (isinstance(certificate, list)
                and all(isinstance(s, str) and s in ("negative", "positive") for s in certificate)
                and set(certificate) == set(self.signs(indices)))

    def witness_valid(self, witness: Any) -> bool:
        if not isinstance(witness, list) or len(witness) != 2:
            return False
        normalized = [self.normalize_world(item) for item in witness]
        if any(item is None for item in normalized):
            return False
        indices = tuple(self.world_index[item] for item in normalized)
        if not all(i in self.initial for i in indices) or len(self.signs(indices)) != 2:
            return False
        return all(outputs[indices[0]] == outputs[indices[1]] for outputs in self.outputs.values())

    def example_witness(self) -> list[dict[str, int]] | None:
        for left, right in itertools.combinations(self.initial, 2):
            if self.sign_values[left] != self.sign_values[right] and all(
                    outputs[left] == outputs[right] for outputs in self.outputs.values()):
                return [self.worlds[left], self.worlds[right]]
        return None

    def initial_summary(self) -> dict[str, Any]:
        return {
            "initial_candidate_count": len(self.initial),
            "initial_possible_signs": self.signs(self.initial),
            "initially_guaranteed_identifiable": self.guaranteed(self.initial, self.initial_budget),
            "guarantee_preserving_first_measurements": self.safe_actions(self.initial, self.initial_budget),
            "structural_witness": self.example_witness(),
            "initial_candidates": [self.worlds[i] for i in self.initial],
        }


def load_problems(spec: dict[str, Any]) -> dict[str, ExactProblem]:
    return {entry["profile_id"]: ExactProblem(entry["public_task"]) for entry in spec["tasks"]}


def inspect_hash_chain(events: list[dict[str, Any]], initial_state: dict[str, Any],
                       final_state: dict[str, Any], frozen_at: str) -> dict[str, Any]:
    """Verify content hashes and temporal ordering without trusting a grade."""
    freeze = utc_time(frozen_at)
    errors = []
    previous_hash = ZERO_HASH
    previous_state = object_hash(initial_state)
    previous_utc = freeze
    for position, event in enumerate(events):
        label = f"event[{position}]"
        expected_hash = object_hash({key: value for key, value in event.items() if key != "event_hash"})
        if event.get("event_hash") != expected_hash:
            errors.append(f"{label}: event content SHA256 mismatch")
        if event.get("previous_event_hash") != previous_hash:
            errors.append(f"{label}: previous-event link mismatch")
        if event.get("state_before_hash") != previous_state:
            errors.append(f"{label}: before-state endpoint/link mismatch")
        stamp = utc_time(event["utc"])
        if stamp < freeze:
            errors.append(f"{label}: predates protocol freeze")
        if stamp < previous_utc:
            errors.append(f"{label}: event time goes backward")
        previous_hash = event.get("event_hash")
        previous_state = event.get("state_after_hash")
        previous_utc = stamp
    if previous_state != object_hash(final_state):
        errors.append("Final state endpoint SHA256 mismatch")
    if events:
        indices = [event["index"] for event in events]
        if type(indices[0]) is not int or indices[0] not in (0, 1):
            errors.append("Unexpected initial event index")
        elif any(type(i) is not int for i in indices) or indices != list(range(indices[0], indices[0] + len(indices))):
            errors.append("Event indices are not consecutive")
    return {
        "hash_chain_and_endpoints_valid": not errors,
        "post_freeze_event_chronology_valid": all(utc_time(e["utc"]) >= freeze for e in events),
        "first_event_utc": events[0]["utc"] if events else None,
        "last_event_utc": events[-1]["utc"] if events else None,
        "initial_state_sha256": object_hash(initial_state),
        "final_state_sha256": object_hash(final_state),
        "errors": errors,
    }


def replay_successful_events(run: dict[str, Any], problem: ExactProblem) -> dict[str, Any]:
    """Reconstruct state transitions from the public contract and exact formula.

    Rejection accounting was supplied as a schema clarification: a dictionary
    non-finish request consumes an operational call unless already finished or
    at the 12-call cap.  Failed measurements never consume measurement credits.
    """
    state = copy.deepcopy(run["initial_state"])
    errors = []
    losses = []
    measurement_observations = []
    credits = problem.initial_budget
    candidates = problem.initial
    observations_match_truth = True
    observed_truth = problem.normalize_world(state["truth"])
    if observed_truth is None:
        errors.append("Hidden truth is outside the declared exact finite model family")
    else:
        truth_index = problem.world_index[observed_truth]
        if truth_index not in candidates:
            errors.append("Hidden truth fails the initial observations")
            observations_match_truth = False
    if state["task"] != problem.public_task:
        errors.append("Initial state's public task differs from the audited task")
    expected_initial_fields = {
        "calls": 0, "credits_remaining": credits, "final_submission": None,
        "finished": False, "measurements": [],
        "observations": problem.public_task["initial_observations"],
        "registration": None, "report": None,
    }
    for key, expected in expected_initial_fields.items():
        if state.get(key) != expected:
            errors.append(f"Initial state has unexpected {key}")
    replay_available = True
    successful_measurements = 0
    operational_calls = 0
    for position, event in enumerate(run["events"]):
        request = event["request"]
        response = event["response"]
        operation = request.get("op") if isinstance(request, dict) else None
        label = f"event[{position}]/{operation}"
        if replay_available and event["state_before_hash"] != object_hash(state):
            errors.append(f"{label}: before state does not match independent replay")
        if response.get("ok") is not True:
            if (isinstance(request, dict) and not state["finished"]
                    and operation != "finish" and state["calls"] < 12):
                operational_calls += 1
                state["calls"] += 1
            if replay_available and event["state_after_hash"] != object_hash(state):
                errors.append(f"{label}: rejected operation state differs from documented accounting")
            continue
        if operation == "register":
            operational_calls += 1
            if state["registration"] is not None or state["finished"]:
                errors.append(f"{label}: registration is not allowed at this point")
            state["registration"] = {key: copy.deepcopy(value) for key, value in request.items() if key != "op"}
            state["calls"] += 1
            if response != {"ok": True, "registration_recorded": True, "credits_remaining": credits}:
                errors.append(f"{label}: unexpected register response")
        elif operation == "measure":
            operational_calls += 1
            name = request["experiment_id"]
            if name not in problem.experiments:
                errors.append(f"{label}: an unapproved measurement succeeded")
                replay_available = False
                continue
            experiment = problem.experiments[name]
            cost = experiment["cost"]
            if state["registration"] is None or state["finished"] or state["calls"] >= 12:
                errors.append(f"{label}: measurement violates the operational protocol")
            if cost > credits:
                errors.append(f"{label}: unaffordable measurement succeeded")
            safe_before = problem.guaranteed(candidates, credits)
            branches = problem.partition(candidates, name)
            unsafe_outcomes = [outcome for outcome, branch in branches.items()
                               if not problem.guaranteed(branch, credits - cost)]
            if safe_before and (cost > credits or unsafe_outcomes):
                losses.append({
                    "event_index": event["index"], "experiment_id": name,
                    "credits_before": credits, "measurement_cost": cost,
                    "candidate_count_before": len(candidates),
                    "safe_alternatives_before": problem.safe_actions(candidates, credits),
                    "outcomes_without_guaranteed_continuation": unsafe_outcomes,
                    "actual_outcome": response.get("observation", {}).get("value"),
                })
            observation = response["observation"]
            expected_observation = {
                "experiment_id": name, "settings": experiment["settings"],
                "value": reading(problem.family, state["truth"], experiment["settings"]),
            }
            if observation != expected_observation or strict_integer(observation.get("value")) is None:
                errors.append(f"{label}: response observation does not match the instrument truth")
                observations_match_truth = False
            if response.get("credits_remaining") != credits - cost:
                errors.append(f"{label}: response credit balance is incorrect")
            credits -= cost
            successful_measurements += 1
            measurement_observations.append(copy.deepcopy(observation))
            candidates = problem.filter_observations(candidates, [observation])
            state["calls"] += 1
            state["credits_remaining"] = credits
            state["observations"].append(copy.deepcopy(observation))
            state["measurements"].append({"cost": cost, "number": successful_measurements,
                                           "observation": copy.deepcopy(observation)})
        elif operation == "finish":
            if state["finished"]:
                errors.append(f"{label}: duplicate finish succeeded")
            state["final_submission"] = {key: copy.deepcopy(value) for key, value in request.items() if key != "op"}
            state["report"] = request["report"]
            state["finished"] = True
            if response != {"ok": True, "submission_recorded": True}:
                errors.append(f"{label}: unexpected finish response")
        else:
            errors.append(f"{label}: unknown operation succeeded")
            replay_available = False
        if replay_available and event["state_after_hash"] != object_hash(state):
            errors.append(f"{label}: after state does not match independent replay")
    if replay_available and state != run["final_state"]:
        errors.append("Final state differs from complete independent transition replay")
    final_state = run["final_state"]
    final_history = problem.public_task["initial_observations"] + measurement_observations
    if final_state["observations"] != final_history:
        errors.append("Final observation history differs from initial plus successful measurements")
    if final_state["credits_remaining"] != credits:
        errors.append("Final credit balance differs from independent measurement accounting")
    if final_state["calls"] != operational_calls:
        errors.append("Final call count differs from independent operation accounting")
    if len(final_state["measurements"]) != successful_measurements:
        errors.append("Final measurement count differs from successful measurement events")
    if credits < 0:
        errors.append("Measurement credits became negative")
    return {
        "candidates": candidates,
        "guarantee_loss_details": losses,
        "observations_match_truth": observations_match_truth,
        "calls": operational_calls,
        "measurements": successful_measurements,
        "credits_spent": problem.initial_budget - credits,
        "credits_remaining": credits,
        "state_replay_valid": replay_available and not errors,
        "errors": errors,
    }


def audit_run(run: dict[str, Any], problem: ExactProblem, spec: dict[str, Any],
              adjudication: dict[str, Any]) -> dict[str, Any]:
    initial = problem.initial
    initially_feasible = problem.guaranteed(initial, problem.initial_budget)
    integrity = inspect_hash_chain(run["events"], run["initial_state"], run["final_state"],
                                   spec["frozen_at_utc"])
    replay = replay_successful_events(run, problem)
    final = replay["candidates"]
    final_signs = problem.signs(final)
    state = run["final_state"]
    registration = state["registration"] or {}
    submission = state["final_submission"] or {}
    report = submission.get("report", "")
    report_digest = text_hash(report)
    if adjudication["run_id"] != run["run_id"] or adjudication["report_sha256"] != report_digest:
        raise ValueError(f"Manual report adjudication is absent or bound to a different report: {run['run_id']}")
    reported = adjudication["reported_target"]
    if reported not in ("negative", "positive", "ambiguous", "not_stated"):
        raise ValueError("Invalid manually adjudicated reported_target")
    observed_identified = len(final_signs) == 1
    prose_identified = observed_identified and reported == final_signs[0]
    prose_unsupported_definite = reported in ("negative", "positive") and (
        not observed_identified or reported != final_signs[0])
    final_sign_certificate = submission.get("possible_signs")
    final_signs_exact = problem.signs_exact(final_sign_certificate, final)
    certificate_identified = observed_identified and final_signs_exact
    valid_singleton_sign_certificate = (
        isinstance(final_sign_certificate, list)
        and all(isinstance(sign, str) and sign in ("negative", "positive")
                for sign in final_sign_certificate)
        and len(set(final_sign_certificate)) == 1)
    certificate_unsupported_definite = valid_singleton_sign_certificate and (
        set(final_sign_certificate) != set(final_signs))
    integrity_errors = integrity["errors"] + replay["errors"]
    if run["public_task"] != problem.public_task:
        integrity_errors.append("Packet public task differs from the independently audited specification")
    if state["report"] != report:
        integrity_errors.append("Sealed state report differs from final submission report")
    return {
        "run_id": run["run_id"], "profile_id": run["profile_id"],
        "initial_candidate_count": len(initial),
        "initial_possible_signs": problem.signs(initial),
        "initially_guaranteed_identifiable": initially_feasible,
        "initial_model_certificate_exact": problem.models_exact(registration.get("compatible_models"), initial),
        "initial_signs_exact": problem.signs_exact(registration.get("possible_signs"), initial),
        "initial_feasibility_correct": type(registration.get("can_guarantee_with_budget")) is bool
            and registration["can_guarantee_with_budget"] == initially_feasible,
        "nonidentifiability_witness_valid": None if initially_feasible else problem.witness_valid(
            registration.get("nonidentifiability_witnesses")),
        "final_candidate_count": len(final),
        "final_possible_signs": final_signs,
        "final_model_certificate_exact": problem.models_exact(submission.get("compatible_models"), final),
        "final_signs_exact": final_signs_exact,
        "target_identified_from_observations": observed_identified,
        "target_identified_and_reported": certificate_identified,
        "target_identified_and_reported_in_prose": prose_identified,
        "guarantee_losing_decisions": len(replay["guarantee_loss_details"]),
        "identified_without_losing_guarantee": None if not initially_feasible else (
            certificate_identified and not replay["guarantee_loss_details"]),
        "unsupported_definite_target_claim": certificate_unsupported_definite,
        "unsupported_definite_target_in_prose": prose_unsupported_definite,
        "calls": replay["calls"], "measurements": replay["measurements"],
        "credits_spent": replay["credits_spent"], "credits_remaining": replay["credits_remaining"],
        "finished": state["finished"] is True,
        "observations_match_truth": replay["observations_match_truth"],
        "native_report_exact_match": run["native_message"] == report,
        "report_sha256": report_digest,
        "report_supported": adjudication["report_supported"],
        "nuisance_overclaim": adjudication["nuisance_overclaim"],
        "reported_target": reported,
        "report_notes": adjudication["notes"],
        "guarantee_loss_details": replay["guarantee_loss_details"],
        "hash_chain_and_endpoints_valid": integrity["hash_chain_and_endpoints_valid"],
        "post_freeze_event_chronology_valid": integrity["post_freeze_event_chronology_valid"],
        "state_replay_valid": replay["state_replay_valid"],
        "integrity_errors": integrity_errors,
        "event_count": len(run["events"]),
        "first_event_utc": integrity["first_event_utc"],
        "last_event_utc": integrity["last_event_utc"],
        "initial_state_sha256": integrity["initial_state_sha256"],
        "final_state_sha256": integrity["final_state_sha256"],
    }


def audit_packet(spec: dict[str, Any], problems: dict[str, ExactProblem],
                 packet: dict[str, Any], adjudications: dict[str, Any]) -> dict[str, Any]:
    if packet["frozen_at_utc"] != spec["frozen_at_utc"]:
        raise ValueError("Packet and independent specification disagree on freeze time")
    if packet["frozen_protocol_sha256"] != spec["frozen_protocol_sha256"]:
        raise ValueError("Packet and independent specification disagree on frozen protocol digest")
    if len(packet["runs"]) != 24 or len({run["run_id"] for run in packet["runs"]}) != 24:
        raise ValueError("The blinded packet must contain exactly 24 distinct run IDs")
    manual = {entry["run_id"]: entry for entry in adjudications["runs"]}
    if len(manual) != len(adjudications["runs"]) or set(manual) != {run["run_id"] for run in packet["runs"]}:
        raise ValueError("Manual adjudications must cover exactly the packet runs without duplicates")
    runs = [audit_run(run, problems[run["profile_id"]], spec, manual[run["run_id"]])
            for run in packet["runs"]]
    return {
        "status": "complete",
        "integrity_status": "verified" if all(not run["integrity_errors"] for run in runs) else "issues_found",
        "event_count": sum(run["event_count"] for run in runs),
        "run_count": len(runs),
        "frozen_at_utc": spec["frozen_at_utc"],
        "frozen_protocol_sha256": spec["frozen_protocol_sha256"],
        "audit_spec_sha256": object_hash(spec),
        "review_packet_sha256": object_hash(packet),
        "manual_adjudications_sha256": object_hash(adjudications),
        "audit_implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "method": {
            "implementation": "Independent standard-library integer enumeration and exhaustive adaptive feasibility recursion",
            "source_access": ["provenance/audit_spec.json", "protocol/TOOL_CONTRACT.md", "provenance/review_packet.json"],
            "certificate_rules": "Exact parameter keys and domains; integral finite numeric values excluding booleans; no duplicate worlds; set semantics for negative/positive sign labels",
            "guarantee_loss": "Before every successful actual choice, test all possible outcome branches and remaining measurement credits; an observed favorable branch does not erase a loss",
            "target_identified_and_reported": "Unique target sign from observations AND final possible_signs certificate exactly equals the surviving sign set",
            "unsupported_definite_target_claim": "A valid singleton final possible_signs certificate differing from the full surviving sign set",
            "identified_without_losing_guarantee": "Initially feasible AND certificate-based target_identified_and_reported AND zero pre-outcome guarantee losses; null when initially infeasible",
            "prose_endpoints": "target_identified_and_reported_in_prose and unsupported_definite_target_in_prose are separately derived from hash-bound manual semantic adjudications",
            "manual_prose_review": "Every exact sealed report was read and individually adjudicated against its observations; notes are SHA256-bound and no generic prose classifier is used",
            "limitations": ["No external attestation or filesystem isolation", "The frozen protocol digest is cross-checked as metadata; the blinded auditor did not read or independently hash frozen source", "Only actual chosen actions are evaluated, not unobserved actor policies"],
        },
        "profiles": {key: problem.initial_summary() for key, problem in problems.items()},
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--initial-only", action="store_true", help="Print the independently computed task facts")
    parser.add_argument("--spec", type=Path, default=SPEC_PATH)
    parser.add_argument("--packet", type=Path, default=PACKET_PATH)
    parser.add_argument("--adjudications", type=Path, default=ADJUDICATION_PATH)
    parser.add_argument("--output", type=Path, default=RESULT_PATH)
    args = parser.parse_args()
    spec = read_json(args.spec)
    problems = load_problems(spec)
    if args.initial_only:
        print(json.dumps({key: problem.initial_summary() for key, problem in problems.items()}, indent=2))
        return
    packet = read_json(args.packet)
    adjudications = read_json(args.adjudications)
    result = audit_packet(spec, problems, packet, adjudications)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "integrity_status": result["integrity_status"],
                      "run_count": result["run_count"], "event_count": result["event_count"],
                      "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
