"""Exact synthetic scientific models and six predeclared task profiles.

Public tasks contain the full admissible model family and measurement contract.
Profile identifiers and truth dictionaries are evaluator metadata, not hints to
participants. No external device, account, or physical measurement is involved.
"""
from __future__ import annotations

import copy
import itertools


def world_key(world):
    """Canonical hashable key independent of dictionary insertion order."""
    return tuple(sorted(world.items()))


def enumerate_worlds(task):
    """Return every admissible integer parameter dictionary in a public task."""
    keys = sorted(task['domains'])
    return [dict(zip(keys, values))
            for values in itertools.product(*(task['domains'][k] for k in keys))]


def is_admissible(task, world):
    return (isinstance(world, dict) and set(world) == set(task['domains'])
            and all(type(world[k]) is int and world[k] in task['domains'][k]
                    for k in task['domains']))


def target_sign(world):
    """Target is the sign of a for the transducer, or omega for the phase model."""
    if 'a' in world and 'omega' not in world:
        value = world['a']
    elif 'omega' in world and 'a' not in world:
        value = world['omega']
    else:
        raise ValueError('World must specify exactly one target parameter.')
    if type(value) is not int or value == 0:
        raise ValueError('The declared target parameter is a nonzero integer.')
    return 'positive' if value > 0 else 'negative'


def evaluate(task, world, settings):
    """Exact integer observation; callers validate admission and charge costs.

    The optional kind label is descriptive. Polynomial controls are x and r;
    phase controls are t and delta. Every measurement starts from an identical
    reset and uses the same hidden parameters, so order has no physical effect.
    """
    if task['family'] == 'polynomial':
        x, r = settings['x'], settings['r']
        if type(x) is not int or type(r) is not int:
            raise ValueError('Polynomial controls must be integers.')
        return world['B'] + world['s'] * (world['a']*x + world['c']*x*x + r)
    if task['family'] == 'phase':
        t, delta = settings['t'], settings['delta']
        if type(t) is not int or type(delta) is not int:
            raise ValueError('Phase controls must be integers.')
        return int((world['beta'] + world['omega']*t + delta) % 8 < 4)
    raise ValueError('Unknown model family.')


def _poly_task(first, second, budget, bias_cost, known_s=False):
    domains = {'B': list(range(61)),
               'a': list(range(-12, 0)) + list(range(1, 13)),
               'c': list(range(-4, 5)), 's': [1] if known_s else [-1, 1]}
    experiments = [
        {'id': 'x0_r0', 'settings': {'kind': 'polynomial', 'x': 0, 'r': 0}, 'cost': 1},
        {'id': 'xm1_r0', 'settings': {'kind': 'polynomial', 'x': -1, 'r': 0}, 'cost': 1},
        {'id': 'x3_r0', 'settings': {'kind': 'polynomial', 'x': 3, 'r': 0}, 'cost': 1},
        {'id': 'x1_r1', 'settings': {'kind': 'polynomial', 'x': 1, 'r': 1}, 'cost': bias_cost},
    ]
    return {
        'family': 'polynomial', 'domains': domains,
        'model_description': (
            'An ideal signed transducer has physical response F(x)=a*x+c*x^2. '
            'A known signed control r is added to that response before the detector. '
            'The detector returns Y(x,r)=B+s*(a*x+c*x^2+r). '
            'B is the detector offset and s is its polarity. All parameters are '
            'fixed throughout this task and lie in the declared finite domains. '
            'Readings are exact integers without noise.'),
        'reset_description': 'Every measurement resets identically; controls do not alter hidden parameters.',
        'target_description': 'Determine whether the physical initial slope F\u2032(0)=a is positive or negative.',
        'initial_observations': [
            {'settings': {'kind': 'polynomial', 'x': 1, 'r': 0}, 'value': first},
            {'settings': {'kind': 'polynomial', 'x': 2, 'r': 0}, 'value': second}],
        'experiments': experiments, 'budget': budget,
    }


def _phase_task(active):
    if active:
        experiments = [
            {'id': 'A', 'settings': {'kind': 'phase', 't': 0, 'delta': 2}, 'cost': 1},
            {'id': 'B', 'settings': {'kind': 'phase', 't': 1, 'delta': 1}, 'cost': 1},
            {'id': 'C', 'settings': {'kind': 'phase', 't': 1, 'delta': 3}, 'cost': 1},
        ]
    else:
        experiments = [{'id': f't{t}_d0', 'settings': {'kind': 'phase', 't': t, 'delta': 0}, 'cost': 1}
                       for t in range(2, 8)]
    return {
        'family': 'phase', 'domains': {'beta': list(range(8)), 'omega': [-3, -1, 1, 3]},
        'model_description': (
            'A cyclic phase has eight equally spaced positions. After each identical reset, '
            'its phase at integer time t with applied phase offset delta is '
            '(beta+omega*t+delta) modulo 8, using residues 0 through 7. '
            'The binary detector returns 1 exactly when that residue is less than 4, '
            'and returns 0 otherwise. beta and omega remain fixed and lie in the '
            'declared finite domains; all observations are exact.'),
        'reset_description': 'Every probe begins from the identical reset beta; times are measured from that reset.',
        'target_description': 'Determine whether the signed phase velocity omega is positive or negative.',
        'initial_observations': [
            {'settings': {'kind': 'phase', 't': 0, 'delta': 0}, 'value': 1},
            {'settings': {'kind': 'phase', 't': 1, 'delta': 0}, 'value': 1}],
        'experiments': experiments, 'budget': 2,
    }


def create_profiles():
    """Six profiles, each with one positive-target and one negative-target truth.

    The known-polarity profile lists its negative truth first. Truth order does
    not encode a participant-facing label, and preparation may shuffle cells.
    """
    poly_mirror = [{'B': 25, 'a': 4, 'c': 3, 's': 1},
                   {'B': 25, 'a': -4, 'c': -3, 's': -1}]
    phase_mirror = [{'beta': 1, 'omega': 1}, {'beta': 2, 'omega': -1}]
    return [
        {'profile_id': 'poly_known', 'public_task': _poly_task(30, 35, 1, 1, known_s=True),
         'truths': [{'B': 29, 'a': -1, 'c': 2, 's': 1}, {'B': 25, 'a': 5, 'c': 0, 's': 1}]},
        {'profile_id': 'poly_target', 'public_task': _poly_task(32, 45, 1, 1),
         'truths': copy.deepcopy(poly_mirror)},
        {'profile_id': 'poly_complement', 'public_task': _poly_task(30, 30, 2, 1),
         'truths': [{'B': 26, 'a': 6, 'c': -2, 's': 1}, {'B': 26, 'a': -6, 'c': 2, 's': -1}]},
        {'profile_id': 'poly_cost', 'public_task': _poly_task(32, 45, 2, 2),
         'truths': copy.deepcopy(poly_mirror)},
        {'profile_id': 'phase_active', 'public_task': _phase_task(True),
         'truths': copy.deepcopy(phase_mirror)},
        {'profile_id': 'phase_passive', 'public_task': _phase_task(False),
         'truths': copy.deepcopy(phase_mirror)},
    ]
