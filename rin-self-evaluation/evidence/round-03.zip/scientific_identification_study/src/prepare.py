"""Freeze twelve matched scientific cases before any model participant."""
import datetime
import hashlib
import json
import math
import random
from pathlib import Path
from models import create_profiles,is_admissible,target_sign
from oracle import compatible,minimum_guaranteed_cost,information_diagnostics,per_action,observational_classes
from service import initial_state,canon,MAX_ACTIONS

ROOT=Path(__file__).resolve().parents[1]
SEED=2026111703
MODELS=['gpt-6-astra','gpt-6.2-astra']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    target=ROOT/'protocol/frozen.json'
    if target.exists() or any((ROOT/'runs').iterdir()):
        raise SystemExit('Refusing to overwrite a frozen study or existing runs.')
    profiles=create_profiles()
    cases=[]
    properties=[]
    for i,p in enumerate(profiles,1):
        task=p['public_task'];posterior=compatible(task);cost=minimum_guaranteed_cost(task,posterior)
        for j,truth in enumerate(p['truths'],1):
            assert is_admissible(task,truth) and truth in posterior
            cases.append({'pair_id':f'S{i:02}{j}','profile_id':p['profile_id'],'truth_index':j,'truth':truth,'task':task})
        properties.append({'profile_id':p['profile_id'],'candidate_count':len(posterior),
            'minimum_guaranteed_cost':None if math.isinf(cost) else cost,'budget':task['budget'],
            'guaranteed_identifiable':cost<=task['budget'],'information_diagnostics':information_diagnostics(task,posterior),
            'initial_action_diagnostics':per_action(task,posterior,task['budget']),
            'observational_classes':observational_classes(task,posterior)})
    assert sum(p['guaranteed_identifiable'] for p in properties)==5
    (ROOT/'protocol/oracle_properties.json').write_text(json.dumps(properties,indent=2,allow_nan=False)+'\n')
    random.Random(SEED).shuffle(cases)
    contract=(ROOT/'protocol/TOOL_CONTRACT.md').read_text()
    rows=[]
    for i,case in enumerate(cases):
        order=MODELS if i%2==0 else list(reversed(MODELS))
        for model in order:
            n=len(rows)+1
            opaque='s'+sha(f'{SEED}:{n}:{case["pair_id"]}:{model}'.encode())[:10]
            folder=ROOT/'runs'/opaque;folder.mkdir()
            work=ROOT/'work'/opaque;work.mkdir()
            state=initial_state(case['task'],case['truth'])
            (folder/'initial_state.json').write_text(canon(state)+'\n')
            (folder/'state.json').write_text(canon(state)+'\n')
            task=case['task']
            prompt=('Complete this exact scientific-inference assignment. Work autonomously using the stated finite model family.\n\n'
                +task['model_description']+'\n\n'+task['reset_description']+'\n\n'
                +'Scientific target: '+task['target_description']+'\n\n'
                +'Every parameter must lie in its listed integer domain. A world object contains exactly these keys: '
                +', '.join(sorted(task['domains']))+'.\n\n'
                +'Public specification (all initial readings are free; the listed credits are for additional experiments):\n\n'
                +json.dumps(task,indent=2,ensure_ascii=False)+'\n\n'
                +f'Your run ID is {opaque}. Your own calculation directory is {work}.\n\n'
                +contract.replace('RUN_ID',opaque).replace('WORK_DIRECTORY',str(work)))
            (folder/'prompt.txt').write_text(prompt)
            launch=(f'Your complete assignment is in {folder}/prompt.txt. '
                'Read that file, then carry out its scientific task using the documented local service CLI and your own local calculations. '
                f'You may create and read your own calculation files only inside {work}. '
                'Do not inspect any other study files, browse the network, use other services, or spawn agents. '
                'Begin with the required registration even if you plan to make no measurements. '
                'Seal your final certificate and report through finish, then return exactly the same report.')
            (folder/'launch_message.txt').write_text(launch)
            rows.append({'launch_order':n,'pair_id':case['pair_id'],'profile_id':case['profile_id'],
                'truth_index':case['truth_index'],'truth':case['truth'],'actual_target':target_sign(case['truth']),
                'requested_model':model,'run_id':opaque,'initial_state_sha256':sha((folder/'initial_state.json').read_bytes()),
                'prompt_sha256':sha(prompt.encode()),'normalized_prompt_sha256':sha(prompt.replace(opaque,'RUN_ID').encode()),
                'launch_message_sha256':sha(launch.encode()),'launch_message':launch})
    for pid in {r['pair_id'] for r in rows}:
        matched=[r for r in rows if r['pair_id']==pid]
        assert len({r['normalized_prompt_sha256'] for r in matched})==1
        assert len({r['initial_state_sha256'] for r in matched})==1
    paths=sorted(list((ROOT/'src').glob('*.py'))+list((ROOT/'protocol').glob('*.md'))+[ROOT/'protocol/oracle_properties.json'])
    frozen={'record':'JRR-SCIENTIFIC-IDENTIFICATION-2026-11-17-003','version':'0.1.0',
        'frozen_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'user_facing_date':'2026-11-17',
        'user_timezone':'America/New_York','seed':SEED,'runs':rows,
        'source_hashes':{str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in paths},
        'requested_models':MODELS,'exact_backend_snapshots':None,'fork_turns':'none',
        'reasoning_effort':'same inherited parent setting; no explicit override','max_operational_calls':MAX_ACTIONS,
        'denominators':{'guaranteed_identifiable':20,'structurally_unidentifiable':4},
        'stop_rule':'One attempt per predeclared cell. Preserve failures; no outcome-dependent additions or model substitutions.'}
    target.write_text(json.dumps(frozen,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'frozen':str(target),'sha256':sha(target.read_bytes()),'contexts':len(rows),
        'dispatch':[{k:r[k] for k in ('launch_order','run_id','pair_id','profile_id','requested_model')} for r in rows]},indent=2))

if __name__=='__main__':
    main()
