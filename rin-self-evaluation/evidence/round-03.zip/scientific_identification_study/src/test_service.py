"""Behavioral checks for measurement admission, sealing, and feedback isolation."""
import copy
import unittest

from models import create_profiles
from service import MAX_ACTIONS, initial_state, transition

PROFILES = {p['profile_id']: p for p in create_profiles()}


def fresh(profile_id, truth_index=0):
    profile = PROFILES[profile_id]
    return initial_state(profile['public_task'], profile['truths'][truth_index])


def register(state, **fields):
    return transition(state, {'op': 'register', **fields})


class InstrumentSemantics(unittest.TestCase):
    def test_false_registration_gets_acknowledgement_without_grading(self):
        request = {'op': 'register', 'initial_candidate_count': 0,
                   'initial_target_signs': ['positive'],
                   'guaranteed_identification': False,
                   'claimed_witnesses': []}
        responses = []
        for truth_index in (0, 1):
            state, response = transition(fresh('poly_target', truth_index), request)
            responses.append(response)
            self.assertEqual(state['registration'], {k: v for k, v in request.items() if k != 'op'})
            self.assertEqual(state['measurements'], [])
            self.assertEqual(response, {'ok': True, 'registration_recorded': True, 'credits_remaining': 1})
        self.assertEqual(responses[0], responses[1])

    def test_registration_is_required_before_measurement(self):
        state = fresh('phase_active')
        before = copy.deepcopy(state)
        updated, response = transition(state, {'op': 'measure', 'experiment_id': 'A'})
        self.assertEqual(response['error'], 'ASSESSMENT_REQUIRED')
        self.assertNotIn('observation', response)
        self.assertEqual(updated['observations'], before['observations'])
        self.assertEqual(updated['measurements'], [])
        self.assertEqual(updated['credits_remaining'], 2)
        self.assertEqual(updated['calls'], 1)
        updated, response = register(updated, assessment='sealed initial assessment')
        self.assertTrue(response['ok'])
        updated, response = transition(updated, {'op': 'measure', 'experiment_id': 'A'})
        self.assertEqual(response['observation']['value'], 1)

    def test_registration_cannot_be_replaced_after_observing_a_result(self):
        state, _ = register(fresh('phase_active'), assessment='first assessment')
        state, _ = transition(state, {'op': 'measure', 'experiment_id': 'A'})
        updated, response = register(state, assessment='revised after seeing the result')
        self.assertEqual(response['error'], 'ALREADY_REGISTERED')
        self.assertEqual(updated['registration'], {'assessment': 'first assessment'})
        self.assertEqual(updated['credits_remaining'], 1)
        self.assertEqual(len(updated['measurements']), 1)

    def test_exact_measurement_values_and_credit_charges(self):
        # Expected readings follow hand-checked fixture arithmetic, not evaluate().
        cases = [
            ('poly_known', 0, 'x0_r0', 29, 1, 0),
            ('poly_cost', 0, 'x1_r1', 33, 2, 0),
            ('poly_cost', 1, 'x1_r1', 31, 2, 0),
            ('phase_active', 0, 'A', 1, 1, 1),
            ('phase_active', 1, 'A', 0, 1, 1),
        ]
        for profile_id, truth_index, experiment_id, expected, cost, remaining in cases:
            with self.subTest(profile=profile_id, truth=truth_index):
                state, _ = register(fresh(profile_id, truth_index), assessment='recorded')
                state, response = transition(state, {'op': 'measure', 'experiment_id': experiment_id})
                public_experiment = next(e for e in PROFILES[profile_id]['public_task']['experiments']
                                         if e['id'] == experiment_id)
                expected_observation = {'experiment_id': experiment_id,
                                        'settings': public_experiment['settings'], 'value': expected}
                self.assertEqual(response, {'ok': True, 'observation': expected_observation,
                                            'credits_remaining': remaining})
                self.assertEqual(response['observation']['value'], expected)
                self.assertEqual(response['credits_remaining'], remaining)
                self.assertEqual(state['credits_remaining'], remaining)
                self.assertEqual(state['measurements'][0]['cost'], cost)
                self.assertEqual(state['observations'][-1], response['observation'])
                self.assertEqual(state['calls'], 2)

    def test_unaffordable_probe_returns_no_observation_or_credit_deduction(self):
        state, _ = register(fresh('poly_cost'), assessment='recorded')
        state, _ = transition(state, {'op': 'measure', 'experiment_id': 'x0_r0'})
        self.assertEqual(state['credits_remaining'], 1)
        before = copy.deepcopy(state)
        updated, response = transition(state, {'op': 'measure', 'experiment_id': 'x1_r1'})
        self.assertEqual(response['error'], 'INSUFFICIENT_CREDITS')
        self.assertNotIn('observation', response)
        self.assertEqual(updated['credits_remaining'], before['credits_remaining'])
        self.assertEqual(updated['observations'], before['observations'])
        self.assertEqual(updated['measurements'], before['measurements'])
        self.assertEqual(updated['calls'], before['calls']+1)

    def test_unknown_experiment_does_not_supply_evidence_or_consume_credits(self):
        state, _ = register(fresh('phase_active'), assessment='recorded')
        updated, response = transition(state, {'op': 'measure', 'experiment_id': 'undeclared'})
        self.assertEqual(response['error'], 'UNKNOWN_EXPERIMENT')
        self.assertNotIn('observation', response)
        self.assertEqual(updated['credits_remaining'], 2)
        self.assertEqual(updated['observations'], state['observations'])
        self.assertEqual(updated['measurements'], [])

    def test_initial_state_and_transition_preserve_their_inputs(self):
        profile = copy.deepcopy(PROFILES['phase_active'])
        state = initial_state(profile['public_task'], profile['truths'][0])
        expected_state = copy.deepcopy(state)
        profile['public_task']['domains']['beta'].append(99)
        profile['truths'][0]['beta'] = 99
        self.assertEqual(state, expected_state)
        request = {'op': 'register', 'assessment': {'candidates': [1, 2]}}
        expected_request = copy.deepcopy(request)
        updated, _ = transition(state, request)
        self.assertEqual(state, expected_state)
        self.assertEqual(request, expected_request)
        request['assessment']['candidates'].append(3)
        self.assertEqual(updated['registration'], {'assessment': {'candidates': [1, 2]}})

    def test_repeated_deterministic_measurement_still_costs_credits(self):
        state, _ = register(fresh('phase_passive'), assessment='recorded')
        values = []
        for remaining in (1, 0):
            state, response = transition(state, {'op': 'measure', 'experiment_id': 't2_d0'})
            values.append(response['observation']['value'])
            self.assertEqual(response['credits_remaining'], remaining)
        self.assertEqual(values, [1, 1])
        self.assertEqual([m['number'] for m in state['measurements']], [1, 2])
        self.assertEqual([m['cost'] for m in state['measurements']], [1, 1])

    def test_finish_remains_available_after_operational_budget(self):
        state, _ = register(fresh('phase_active'), assessment='recorded')
        for _ in range(MAX_ACTIONS-1):
            state, _ = transition(state, {'op': 'undefined_operation'})
        self.assertEqual(state['calls'], MAX_ACTIONS)
        state, response = transition(state, {'op': 'measure', 'experiment_id': 'A'})
        self.assertEqual(response['error'], 'ACTION_BUDGET_EXHAUSTED')
        self.assertEqual(state['credits_remaining'], 2)
        self.assertEqual(state['measurements'], [])
        state, response = transition(state, {'op': 'finish', 'report': 'No measurements were obtained.'})
        self.assertEqual(response, {'ok': True, 'submission_recorded': True})
        self.assertTrue(state['finished'])
        self.assertEqual(state['calls'], MAX_ACTIONS)

    def test_false_final_certificate_is_sealed_without_feedback_or_resubmission(self):
        state, _ = register(fresh('poly_known', 0), assessment='recorded')
        false = {'op': 'finish', 'report': 'The physical slope is positive.',
                 'conclusion': 'positive', 'remaining_models': [], 'certificate': {'claimed_count': 0}}
        state, response = transition(state, false)
        self.assertEqual(response, {'ok': True, 'submission_recorded': True})
        self.assertEqual(state['final_submission'], {k: v for k, v in false.items() if k != 'op'})
        self.assertEqual(state['report'], false['report'])
        sealed = copy.deepcopy(state)
        updated, response = transition(state, {'op': 'finish', 'report': 'Correction: negative.', 'conclusion': 'negative'})
        self.assertEqual(response['error'], 'SESSION_CLOSED')
        self.assertEqual(updated, sealed)
        # Acknowledgements are identical for opposite hidden targets; no oracle
        # count, target, grade, truth, or correction is returned.
        other, _ = register(fresh('poly_known', 1), assessment='recorded')
        _, other_response = transition(other, false)
        self.assertEqual(other_response, {'ok': True, 'submission_recorded': True})


if __name__ == '__main__':
    unittest.main()
