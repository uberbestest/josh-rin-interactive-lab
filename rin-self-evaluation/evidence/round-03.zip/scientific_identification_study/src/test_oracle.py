"""Semantic and independently enumerated witnesses for the exact instrument."""
import copy
import itertools
import math
import unittest
from models import create_profiles, enumerate_worlds, evaluate, is_admissible, target_sign, world_key
from oracle import (compatible, target_signs, minimum_guaranteed_cost, can_guarantee,
                    per_action, observational_classes, information_diagnostics)

PROFILES = {p['profile_id']: p for p in create_profiles()}


def history_with(task, world, experiment_id):
    e = next(x for x in task['experiments'] if x['id'] == experiment_id)
    return task['initial_observations'] + [{'settings': e['settings'], 'value': evaluate(task, world, e['settings'])}]


def brute_two_measurement_policy_exists(task, worlds, budget):
    """Enumerate explicit depth-at-most-two decision trees, without oracle DP.

    Each branch may stop or choose one additional affordable experiment. A tree
    is verified directly across every candidate world, comparing the signs in
    every final observed transcript. This is bounded to the study's <=2 credits.
    """
    if len({target_sign(w) for w in worlds}) == 1:
        return True
    experiments = task['experiments']
    for first in experiments:
        if first['cost'] > budget:
            continue
        first_values = sorted({evaluate(task,w,first['settings']) for w in worlds})
        choices = [None] + [e for e in experiments if first['cost']+e['cost'] <= budget]
        for decisions in itertools.product(choices, repeat=len(first_values)):
            branch_action = dict(zip(first_values, decisions))
            leaves = {}
            for w in worlds:
                v = evaluate(task,w,first['settings'])
                second = branch_action[v]
                transcript = (v,) if second is None else (v,second['id'],evaluate(task,w,second['settings']))
                leaves.setdefault(transcript,set()).add(target_sign(w))
            if all(len(signs)==1 for signs in leaves.values()):
                return True
    return False


class IdentificationSemantics(unittest.TestCase):
    def test_truths_are_admissible_match_initial_data_and_span_both_targets(self):
        for profile in PROFILES.values():
            task = profile['public_task']
            self.assertEqual(target_signs(profile['truths']), ['negative','positive'])
            for truth in profile['truths']:
                self.assertTrue(is_admissible(task,truth))
                for observation in task['initial_observations']:
                    self.assertEqual(evaluate(task,truth,observation['settings']), observation['value'])

    def test_initial_candidate_counts_and_exact_credit_bounds(self):
        expected = {'poly_known':(7,1),'poly_target':(8,1),'poly_complement':(16,2),
                    'poly_cost':(8,2),'phase_active':(8,2),'phase_passive':(8,math.inf)}
        for key,(count,cost) in expected.items():
            task=PROFILES[key]['public_task']
            self.assertEqual(len(compatible(task)),count,key)
            self.assertEqual(minimum_guaranteed_cost(task),cost,key)

    def test_known_polarity_does_not_remove_curvature_ambiguity(self):
        task=PROFILES['poly_known']['public_task']
        self.assertEqual(target_signs(compatible(task)),['negative','positive'])
        for truth in PROFILES['poly_known']['truths']:
            remaining=compatible(task,history_with(task,truth,'x0_r0'))
            self.assertEqual(remaining,[truth])

    def test_target_information_can_beat_parameter_information(self):
        task=PROFILES['poly_target']['public_task']
        info={r['experiment_id']:r for r in information_diagnostics(task)['experiments']}
        self.assertEqual(info['x0_r0']['outcome_entropy_bits'],2.0)
        self.assertEqual(info['x0_r0']['target_information_bits'],0.0)
        self.assertEqual(info['x1_r1']['outcome_entropy_bits'],1.0)
        self.assertEqual(info['x1_r1']['target_information_bits'],1.0)
        for truth in PROFILES['poly_target']['truths']:
            remaining=compatible(task,history_with(task,truth,'x1_r1'))
            self.assertEqual(len(remaining),4)
            self.assertEqual(target_signs(remaining),[target_sign(truth)])

    def test_complementary_probes_need_both_kinds_and_either_order_works(self):
        task=PROFILES['poly_complement']['public_task']
        for truth in PROFILES['poly_complement']['truths']:
            for order in [('x0_r0','x1_r1'),('x1_r1','x0_r0')]:
                history=list(task['initial_observations'])
                for n,eid in enumerate(order):
                    e=next(e for e in task['experiments'] if e['id']==eid)
                    history.append({'settings':e['settings'],'value':evaluate(task,truth,e['settings'])})
                    remaining=compatible(task,history)
                    self.assertEqual(len(target_signs(remaining)),2 if n==0 else 1)
                self.assertEqual(remaining,[truth])

    def test_costly_bias_probe_requires_preserving_its_credit(self):
        task=PROFILES['poly_cost']['public_task']
        actions={x['experiment_id']:x for x in per_action(task,None,2)}
        self.assertTrue(actions['x1_r1']['preserves_guarantee'])
        for eid in ['x0_r0','xm1_r0','x3_r0']:
            self.assertFalse(actions[eid]['preserves_guarantee'])
            self.assertEqual(actions[eid]['minimum_total_cost_if_first'],3)

    def test_polynomial_sign_flip_preserves_every_ordinary_integer_probe(self):
        task=PROFILES['poly_complement']['public_task']
        for w in compatible(task):
            twin={**w,'s':-w['s'],'a':-w['a'],'c':-w['c']}
            self.assertTrue(is_admissible(task,twin))
            self.assertNotEqual(target_sign(w),target_sign(twin))
            for x in range(-12,13):
                settings={'x':x,'r':0}
                self.assertEqual(evaluate(task,w,settings),evaluate(task,twin,settings))
            self.assertNotEqual(evaluate(task,w,{'x':1,'r':1}),evaluate(task,twin,{'x':1,'r':1}))

    def test_phase_active_requires_nonmyopic_first_action(self):
        task=PROFILES['phase_active']['public_task']
        actions={x['experiment_id']:x for x in per_action(task,None,2)}
        self.assertTrue(actions['A']['preserves_guarantee'])
        self.assertFalse(actions['B']['preserves_guarantee'])
        self.assertFalse(actions['C']['preserves_guarantee'])
        self.assertEqual(actions['A']['minimum_total_cost_if_first'],2)
        self.assertEqual(actions['B']['minimum_total_cost_if_first'],3)
        self.assertEqual(actions['C']['minimum_total_cost_if_first'],3)

    def test_phase_adaptive_witness_covers_every_candidate_world(self):
        task=PROFILES['phase_active']['public_task']
        ex={e['id']:e for e in task['experiments']}
        for truth in compatible(task):
            a=evaluate(task,truth,ex['A']['settings'])
            second=ex['B' if a==0 else 'C']
            history=task['initial_observations'] + [
                {'settings':ex['A']['settings'],'value':a},
                {'settings':second['settings'],'value':evaluate(task,truth,second['settings'])}]
            self.assertEqual(target_signs(compatible(task,history)),[target_sign(truth)])

    def test_selected_active_truths_are_ambiguous_after_every_single_probe(self):
        profile=PROFILES['phase_active'];task=profile['public_task']
        for truth in profile['truths']:
            for e in task['experiments']:
                self.assertEqual(target_signs(compatible(task,history_with(task,truth,e['id']))),['negative','positive'])

    def test_passive_reflection_is_observationally_invisible(self):
        task=PROFILES['phase_passive']['public_task']
        for w in compatible(task):
            twin={'beta':(3-w['beta'])%8,'omega':-w['omega']}
            self.assertTrue(is_admissible(task,twin))
            self.assertNotEqual(target_sign(w),target_sign(twin))
            for t in range(-24,25):
                self.assertEqual(evaluate(task,w,{'t':t,'delta':0}),evaluate(task,twin,{'t':t,'delta':0}))
        classes=observational_classes(task)
        self.assertEqual(len(classes),4)
        self.assertTrue(all(len(c['worlds'])==2 and not c['target_identified'] for c in classes))

    def test_reset_readings_do_not_depend_on_probe_order(self):
        for profile in PROFILES.values():
            task=profile['public_task'];world=copy.deepcopy(profile['truths'][0]);before=copy.deepcopy(world)
            forward={e['id']:evaluate(task,world,e['settings']) for e in task['experiments']}
            reverse={e['id']:evaluate(task,world,e['settings']) for e in reversed(task['experiments'])}
            self.assertEqual(forward,reverse)
            self.assertEqual(world,before)

    def test_explicit_depth_two_tree_enumeration_agrees_for_every_budget(self):
        for profile in PROFILES.values():
            task=profile['public_task'];worlds=compatible(task)
            for budget in (0,1,2):
                self.assertEqual(can_guarantee(task,worlds,budget),
                                 brute_two_measurement_policy_exists(task,worlds,budget),
                                 (profile['profile_id'],budget))

    def test_dp_finite_cost_exactly_matches_all_menu_target_classes(self):
        for profile in PROFILES.values():
            task=profile['public_task']
            finite=math.isfinite(minimum_guaranteed_cost(task))
            self.assertEqual(finite,all(c['target_identified'] for c in observational_classes(task)))

    def test_inconsistent_evidence_never_becomes_vacuous_identification(self):
        task=PROFILES['phase_active']['public_task']
        observations=task['initial_observations']+[{'settings':{'t':0,'delta':0},'value':0}]
        self.assertEqual(compatible(task,observations),[])
        self.assertEqual(target_signs([]),[])
        with self.assertRaises(ValueError):
            minimum_guaranteed_cost(task,[])


if __name__=='__main__':
    unittest.main()
