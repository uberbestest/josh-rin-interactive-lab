"""Build the seven-page reader report from the completed, checked study."""
from report_style import *
from reportlab.platypus import Flowable


class PhaseTree(Flowable):
    """Exact oracle policy, not an assertion of every actor's unseen behavior."""
    def __init__(self):
        super().__init__()
        self.width = WIDTH
        self.height = 208

    def draw(self):
        c = self.canv
        root = (WIDTH / 2, 174)
        branches = [(125, 112), (WIDTH - 125, 112)]
        leaves = [(58, 38), (184, 38), (WIDTH - 184, 38), (WIDTH - 58, 38)]
        c.setStrokeColor(LINE)
        c.setLineWidth(1.2)
        for x, y in branches:
            c.line(root[0], root[1] - 17, x, y + 17)
        for j, (x, y) in enumerate(leaves):
            bx, by = branches[j // 2]
            c.line(bx, by - 17, x, y + 23)
        c.setFont('Lab', 8.4)
        c.setFillColor(MUTED)
        for x, y, label in [(178, 144, 'A = 0'), (WIDTH - 178, 144, 'A = 1'),
                            (81, 78, 'B = 0'), (171, 78, 'B = 1'),
                            (WIDTH - 171, 78, 'C = 0'), (WIDTH - 81, 78, 'C = 1')]:
            c.drawCentredString(x, y, label)

        def box(x, y, title, subtitle, w=112, h=34):
            c.setFillColor(PALE)
            c.setStrokeColor(LINE)
            c.roundRect(x - w / 2, y - h / 2, w, h, 5, fill=1, stroke=1)
            c.setFillColor(INK)
            c.setFont('LabBold', 9)
            c.drawCentredString(x, y + 3, title)
            c.setFont('Lab', 8)
            c.setFillColor(MUTED)
            c.drawCentredString(x, y - 10, subtitle)

        box(*root, 'Probe A', '(t, δ) = (0, 2)')
        box(*branches[0], 'Probe B', '(t, δ) = (1, 1)')
        box(*branches[1], 'Probe C', '(t, δ) = (1, 3)')
        for (x, y), title, subtitle in zip(leaves,
                ['Positive', 'Negative', 'Positive', 'Negative'],
                ['1 compatible world', '3 compatible worlds', '3 compatible worlds', '1 compatible world']):
            box(x, y, title, subtitle, w=112, h=46)


def main():
    data = json.loads((ROOT / 'results/summary.json').read_text())
    audit = json.loads((ROOT / 'results/comparison_verification.json').read_text())
    assert audit['status'] == 'PASS'
    assert data['contexts'] == 24 and data['events'] == 78
    old = data['models']['gpt-6-astra']
    new = data['models']['gpt-6.2-astra']
    assert all(m['identified_targets'] == 10 and m['supported_reports'] == 12
               and m['guarantee_losing_decisions'] == 0 for m in [old, new])
    story = []

    # 1. Outcome first.
    story += [p('ROUND 3  /  EXACT SCIENTIFIC INFERENCE', 'kicker'),
              p('The Experiment<br/>That Answers<br/>the Question', 'title'),
              p('A matched test of choosing measurements, identifying physical direction, '
                'and preserving uncertainty when the evidence cannot settle it.'),
              p('24 fresh contexts · 12 matched task pairs · 6 authored instrument profiles', 'small')]
    rows = [['Recorded outcome', 'gpt-6-astra', 'gpt-6.2-astra'],
            ['Feasible target signs identified', '10 / 10', '10 / 10'],
            ['Identified without losing the design guarantee', '10 / 10', '10 / 10'],
            ['Structural impossibilities correctly certified', '2 / 2', '2 / 2'],
            ['Exact initial / final model sets', '12 / 12 each', '12 / 12 each'],
            ['Supported final reports', '12 / 12', '12 / 12'],
            ['Unsupported definite directions', '0', '0']]
    story += [table(rows, [WIDTH - 212, 106, 106]), Spacer(1, 12),
              p('<b>Result: both reached the ceiling on the defined scientific endpoints.</b> '
                'This round demonstrates successful exact inference and experiment selection '
                'by both requested configurations. It supplies no observed 6.2 advantage on these tasks.'),
              p('The strongest behavior was keeping the scientific target separate from a full parameter fit. '
                'Both models sometimes identified the direction while correctly retaining several possible '
                'parameter settings. They also supplied valid reasons why the passive instrument could never reveal direction.'),
              p('These are authored, noiseless finite problems with local calculation tools. '
                'They are not a broad capability ranking, an estimate of real-world reliability, '
                'or evidence of a new scientific discovery.', 'small')]

    # 2. Design and fixed denominators.
    new_page(story, 'What was actually tested', 'DESIGN  /  FIXED BEFORE THE FIRST PARTICIPANT ACTION')
    story += [p('Each model received the same public instrument description, exact initial readings, '
                'allowed experiments and measurement credits for a matched task. It first registered '
                'every compatible parameter setting and whether a guaranteed solution existed. '
                'The service recorded this claim without revealing whether it was correct.'),
              p('It then selected measurements and submitted a final compatible-model set, possible signs '
                'and explanatory report. A compatible model is a parameter setting consistent with every '
                'observed value. The requested sign is identified only when all remaining settings agree.'),
              table([
                  ['Profile', 'Initial models', 'Credits', 'What it tests'],
                  ['Known polarity', '7', '1', 'Curvature can make the observed rise disagree with the physical initial slope.'],
                  ['Target versus nuisance detail', '8', '1', 'Choose a reference that answers the sign question while four models remain.'],
                  ['Complementary measurements', '16', '2', 'Two measurements together settle a sign that neither resolves alone.'],
                  ['Expensive decisive reference', '8', '2', 'A useful reference costs both credits; a cheap detour destroys the guarantee.'],
                  ['Active phase detection', '8', '2', 'Plan an adaptive two-step experiment instead of optimizing only its first reading.'],
                  ['Passive phase detection', '8', '2', 'Certify a symmetry that makes direction unidentifiable.']
              ], [134, 62, 54, WIDTH - 250]), Spacer(1, 10),
              p('Each profile had two hidden truths with identical initial public observations. '
                'There were ten feasible tasks and two structurally impossible tasks per model. '
                'Exactly one fresh context was used per cell, with no rescue prompts or outcome-dependent additions.'),
              p('The twelve pair orders were shuffled with a fixed seed; which model was dispatched first '
                'alternated. Paired prompts and initial states matched after removing opaque identifiers and paths. '
                'Participants could use their own local Python calculations. The requested selectors were recorded; '
                'exact serving snapshots, equal token use and equivalence to a ChatGPT subscription tier were not verified.', 'small'),
              p('Identifiability and experimental design are established subjects [1, 2]. '
                'This study uses its own finite, exact, worst-case decision-tree oracle; '
                'it does not implement either cited paper’s analysis method.', 'small')]

    # 3. Polynomial structure and target-specific information.
    new_page(story, 'More detail can miss the question', 'POLYNOMIAL INSTRUMENT  /  PHYSICAL SLOPE VERSUS DETECTOR POLARITY')
    story += [p('<b>F(x) = ax + cx²</b> &nbsp;&nbsp; and &nbsp;&nbsp; <b>Y(x, r) = B + s(ax + cx² + r)</b>', 'quote'),
              p('The target is the sign of the physical initial slope, F′(0) = a. The offset B, curvature c '
                'and detector polarity s are nuisance parameters. The controlled reference r is added before detection. '
                'The closed integer domains are B = 0…60, nonzero a = −12…12, c = −4…4, and s = ±1 '
                '(or known +1 in the control). The unknown-polarity family contains 26,352 settings.'),
              p('<b>Why ordinary samples can fail.</b> When s is unknown and r = 0, replacing (B, a, c, s) with '
                '(B, −a, −c, −s) leaves every reading unchanged while reversing the target sign. '
                'Measuring another point can reveal curvature or offset and still leave the physical direction unresolved.'),
              p('<b>Why the reference succeeds in the target profile.</b> Initial readings 32 and 45 imply '
                's(a + 3c) = 13. Set A = sa and C = sc. Then A = 13 − 3C ≥ 1 because C ≤ 4, '
                'so sign(a) = s. The extra reading at (x, r) = (1, 1) differs from 32 by exactly s. '
                'A result of 33 establishes positive a; 31 establishes negative a. This conclusion depends '
                'on the declared bounds.'),
              table([
                  ['First measurement in that profile', 'Full-model information', 'Target-sign information'],
                  ['An ordinary third point, r = 0', '2 bits', '0 bits'],
                  ['The signed reference, x = 1 and r = 1', '1 bit', '1 bit']
              ], [WIDTH - 230, 115, 115]), Spacer(1, 7),
              p('Information values use equal weights over the eight initial settings, solely to explain '
                'the example. No prior was given to participants; the task objective was a guarantee over all compatible worlds.', 'small'),
              p('Both models chose the reference in all four matched target/cost tasks. Four settings remained '
                'after each result: positive slopes {1, 4, 7, 10} or negative slopes {−10, −7, −4, −1}. '
                'Both reported a definite sign without claiming a unique magnitude.'),
              p('The other polynomial controls also succeeded. With known s = +1, readings 30 and 35 '
                'can conceal a = −1 and c = 2; measuring the offset resolves this. With equal initial readings '
                '30 and 30, an offset measurement and a reference are complementary: neither alone resolves '
                'the sign, but together they identify all parameters. Both orders preserve the guarantee.', 'small')]

    # 4. Adaptive experiment planning.
    new_page(story, 'The first experiment must leave a way forward', 'ACTIVE PHASE INSTRUMENT  /  TWO CREDITS AND AN ADAPTIVE CHOICE')
    story += [p('The detector reports 1 when <b>(β + ωt + δ) mod 8 &lt; 4</b>, and 0 otherwise. '
                'Here β = 0…7, ω ∈ {−3, −1, 1, 3}, and the target is sign(ω). '
                'Every probe starts from the same reset. Initial readings at (t, δ) = (0, 0) and (1, 0) '
                'are both 1, leaving eight settings.'),
              p('Three probes cost one credit each: A = (0, 2), B = (1, 1) and C = (1, 3). '
                '<b>Only A first preserves a guaranteed solution within two credits.</b> '
                'The next probe depends on its result:'),
              PhaseTree(),
              p('Figure: the exact oracle’s complete decision tree. Leaf counts describe all initially '
                'compatible worlds reaching that leaf. The live runs exercise only their observed paths.', 'small'),
              p('Both models used <b>A = 1, then C = 0</b> for the positive hidden truth. '
                'They retained (β, ω) = (0, 1), (0, 3) and (1, 1). For the negative hidden truth, '
                'both used <b>A = 0, then B = 1</b>, retaining (2, −1), (3, −3) and (3, −1). '
                'All four reports identified the direction while retaining ambiguity in phase and speed.'),
              p('<b>A useful trap for short-horizon design.</b> Under equal illustrative weights, '
                'A supplies about 0.189 bits of immediate sign information, while B or C supplies '
                'about 0.311 bits. The more informative first reading can leave an unresolved branch '
                'with too little budget. Future feasibility matters.'),
              p('We score a chosen action against every result it could have produced before observing its outcome. '
                'A lucky branch can still justify a correct final answer after a bad design choice; those are separate endpoints. '
                'No such guarantee-losing choice occurred here. We do not infer how an actor would behave '
                'on every unobserved branch.', 'small')]

    # 5. A constructive impossibility proof.
    new_page(story, 'A correct answer can be a proof of ambiguity', 'PASSIVE PHASE INSTRUMENT  /  MORE OF THE SAME MEASUREMENT CANNOT RESOLVE DIRECTION')
    story += [p('The passive profile uses the same detector and initial readings but permits only zero-offset '
                'probes at integer times 2 through 7. Two credits are available. '
                'The reflection <b>(β, ω) → ((3 − β) mod 8, −ω)</b> reverses direction while preserving '
                'every permitted reading.'),
              p('To see why, let a phase residue be q. Reflection sends it to (3 − q) mod 8. '
                'Residues 0, 1, 2, 3 map to 3, 2, 1, 0; residues 4, 5, 6, 7 map to 7, 6, 5, 4. '
                'The detector returns the same bit for both. An adaptive strategy receives the same '
                'history in these opposite-direction worlds, so it cannot distinguish them.'),
              table([
                  ['Opposite-direction setting', 't0', 't1', 't2', 't3', 't4', 't5', 't6', 't7'],
                  ['β = 1, ω = +1', '1', '1', '1', '0', '0', '0', '0', '1'],
                  ['β = 2, ω = −1', '1', '1', '1', '0', '0', '0', '0', '1']
              ], [171] + [(WIDTH - 171) / 8] * 8), Spacer(1, 10),
              p('<b>All four live runs preserved the ambiguity.</b> Each registered a valid opposite-sign '
                'witness agreeing on every available probe. Every final report explained the symmetry '
                'rather than inventing a direction from the hidden truth.'),
              p('Three runs took no additional measurements and retained the full eight-setting initial set. '
                'In the negative-truth case, gpt-6-astra measured t = 2 and t = 3, obtaining 1 and 0. '
                'That narrowed the possibilities to the two rows above. It correctly learned |ω| = 1 '
                'while saying the direction remained unknown. The matched 6.2 run stopped with a valid '
                'impossibility proof and eight settings still possible.'),
              table([
                  ['Resource total over twelve contexts', 'gpt-6-astra', 'gpt-6.2-astra'],
                  ['Measurements', str(old['measurements']), str(new['measurements'])],
                  ['Measurement credits spent', str(old['credits_spent']), str(new['credits_spent'])],
                  ['Operational calls, including registration', str(old['operational_calls']), str(new['operational_calls'])]
              ], [WIDTH - 204, 102, 102]), Spacer(1, 9),
              p('The two-credit difference comes entirely from that optional passive investigation. '
                'The older configuration learned an extra nuisance property; the newer configuration spent fewer credits. '
                'The protocol imposed no penalty for optional measurements in an impossible case, so this is '
                'a descriptive tradeoff, not a scientific-success advantage.', 'small')]

    # 6. All matched observations in one place.
    new_page(story, 'Every matched result', 'OBSERVED MEASUREMENT SEQUENCES  /  NO OMITTED CELLS')
    story += [p('O denotes the polynomial offset probe (x, r) = (0, 0); R denotes its reference probe '
                '(1, 1). A, B and C are defined on the previous active-phase page. P2 and P3 are passive '
                'zero-offset readings at t = 2 and 3. Numbers after “=” are observed instrument values.', 'small')]
    runs = {r['run_id']: r for r in data['runs']}
    labels = {'poly_known': 'Known polarity', 'poly_target': 'Target versus detail',
              'poly_complement': 'Complementary', 'poly_cost': 'Costly reference',
              'phase_active': 'Active phase', 'phase_passive': 'Passive phase'}
    aliases = {'x0_r0': 'O', 'x1_r1': 'R', 'A': 'A', 'B': 'B', 'C': 'C', 't2_d0': 'P2', 't3_d0': 'P3'}

    def trace(row):
        return ' → '.join(aliases[c['experiment_id']] + '=' + str(c['observed_value'])
                          for c in row['mechanical']['choices']) or 'No probes'

    ledger = [['Profile / hidden sign', 'gpt-6-astra', 'gpt-6.2-astra', 'Final models old / new', 'Reported signs']]
    for pair in data['pairs']:
        a, b = runs[pair['old_run']], runs[pair['new_run']]
        sign = '+' if pair['actual_target'] == 'positive' else '−'
        result = 'Both remain' if pair['category'] != 'feasible' else ('Positive' if sign == '+' else 'Negative')
        ledger.append([labels[pair['profile_id']] + '<br/>Hidden sign: ' + sign,
                       trace(a), trace(b),
                       str(a['mechanical']['final_candidate_count']) + ' / ' + str(b['mechanical']['final_candidate_count']),
                       result])
    story += [table(ledger, [135, 111, 111, 76, WIDTH - 433]), Spacer(1, 10),
              p('All initial and final compatible-model sets were exact. Both models’ initial feasibility '
                'assessments and possible-sign sets were correct in every context. No operational errors '
                'or unsupported definite directions were recorded.'),
              p('“Hidden sign” is evaluator information, revealed here after completion. It was absent '
                'from participant prompts. In the passive cases the scientifically supported answer '
                'remains ambiguous even though the evaluator knows which world produced the readings.', 'small')]

    # 7. Integrity, reproduction, and scope.
    new_page(story, 'How the result was checked', 'REPLAYABLE RECORD  /  SAME-LAB VERIFICATION')
    story += [p('<b>Before launch:</b> 33 tests checked the finite families, exact guarantees, complementary '
                'measurements, symmetry proofs, budgets and recording semantics. A separate source review '
                'checked the instrument and twelve scripted integration witnesses. These scripted checks '
                'are not counted as live participants. Instrument, oracle, grader and test source, protocol, '
                'truth mapping, prompts and dispatch order were frozen before participant actions. '
                'Analysis, independent audit and report code were written and retained afterward.'),
              p('<b>After completion:</b> all 78 service events replayed through the frozen instrument, '
                'including exact responses and intermediate state hashes. All 24 delivered native final '
                'messages matched their sealed reports. A separate model reviewer, given shuffled raw records '
                'without model identities or root scores, independently implemented the instrument and '
                'decision-tree checks, then manually reviewed every final report.'),
              p(f'The two implementations agreed on <b>{audit["mechanical_comparisons"]} mechanical field comparisons</b>; '
                f'the two reviewers agreed on <b>{audit["report_judgment_comparisons"]} report judgments</b>. '
                'These individually read prose judgments by model reviewers are bound to exact text hashes and per-report notes. '
                'This does not amount to an automatic general-purpose truthfulness test.'),
              p('<b>Reproduce the checks.</b> Extract the evidence archive, enter scientific_identification_study, '
                'then run the following with Python 3. The scientific tests and replay/audit scripts use the standard library:', 'small'),
              p('python3 -m unittest discover -s src -p &quot;test_*.py&quot;<br/>'
                'python3 src/replay.py<br/>'
                'python3 src/analyze.py<br/>'
                'python3 src/audit_independent.py<br/>'
                'python3 src/verify_comparison.py', 'small'),
              p('<b>Limits.</b> Six authored profiles, each with two truths, do not represent a random sample '
                'of scientific problems. Exact arithmetic, explicit model families and small budgets make '
                'these tasks tractable by exhaustive calculation. Both configurations reached the measured '
                'ceiling, so this dataset cannot establish an advantage elsewhere or equal overall ability. '
                'Requested selector names are not independent attestation of backend snapshots.'),
              p('The recorder and reviewers ran in the same lab. Filesystem boundaries were enforced by '
                'instruction, not operating-system isolation. Hashes and replays support internal consistency; '
                'they are not external attestation. The state-write/event-append pair is not crash-atomic. '
                'Full host-tool transcripts and hidden reasoning are not retained. No claim about comparative '
                'token cost, latency or subscription-tier performance is made.', 'small'),
              p('<b>Background sources</b>', 'h2'),
              p('[1] Raue et al. (2009). <i>Structural and practical identifiability analysis of partially '
                'observed dynamical models by exploiting the profile likelihood.</i> '
                '<link href="https://pubmed.ncbi.nlm.nih.gov/19505944/" color="#006b70">DOI: 10.1093/bioinformatics/btp358</link>.', 'small'),
              p('[2] Myung and Pitt (2009). <i>Optimal Experimental Design for Model Discrimination.</i> '
                '<link href="https://pmc.ncbi.nlm.nih.gov/articles/PMC2743521/" color="#006b70">DOI: 10.1037/a0016104</link>. '
                'These support the background framing; the task counts, proofs and live outcomes come from '
                'this study’s retained records.', 'small')]

    doc = SimpleDocTemplate(str(OUT), pagesize=A4, rightMargin=44, leftMargin=44,
                           topMargin=56, bottomMargin=54, invariant=1,
                           title='The Experiment That Answers the Question', author="Josh & Rin's Lab",
                           subject='A matched, exact scientific-inference comparison of two requested model configurations')
    doc.build(story, onFirstPage=page, onLaterPages=page)
    print(str(OUT))


if __name__ == '__main__':
    main()
