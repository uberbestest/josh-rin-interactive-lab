"""Extract an evidence ZIP freshly and reproduce its scientific checks without network access.

Only run this on the trusted study archive: reproduction executes its retained
Python checks. It never calls the participant service or creates new trials.
The JSON receipt is written outside the archived project.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import platform
import stat
import subprocess
import sys
import tempfile
import time
import zipfile

STUDY_NAME = 'scientific_identification_study'
INVENTORY = 'provenance/file_inventory.json'
SCRIPT_ROOT = Path(__file__).resolve().parents[1]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_relative(name: str) -> PurePosixPath:
    if not name or '\\' in name or ':' in name or '\x00' in name:
        raise ValueError('Unsafe archive or inventory path: ' + repr(name))
    raw = name.split('/')
    if any(part in ('', '.', '..') for part in raw):
        raise ValueError('Noncanonical archive or inventory path: ' + repr(name))
    relative = PurePosixPath(name)
    if relative.is_absolute():
        raise ValueError('Absolute archive or inventory path: ' + repr(name))
    return relative


def extract(archive: Path, destination: Path) -> Path:
    with zipfile.ZipFile(archive) as bundle:
        names = set()
        entries = []
        for info in bundle.infolist():
            normalized = info.filename[:-1] if info.is_dir() else info.filename
            relative = safe_relative(normalized)
            if relative.parts[0] != STUDY_NAME:
                raise ValueError('Archive member lies outside the expected project root')
            if normalized in names:
                raise ValueError('Duplicate archive member: ' + normalized)
            names.add(normalized)
            mode = info.external_attr >> 16
            kind = stat.S_IFMT(mode)
            if stat.S_ISLNK(mode) or kind not in (0, stat.S_IFREG, stat.S_IFDIR):
                raise ValueError('Symlink or nonregular archive member: ' + normalized)
            if info.flag_bits & 1:
                raise ValueError('Encrypted archive members are unsupported')
            target = destination.joinpath(*relative.parts)
            if not target.resolve().is_relative_to(destination.resolve()):
                raise ValueError('Archive extraction would escape its fresh directory')
            entries.append((info, target))
        for info, target in entries:
            if info.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            else:
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open('xb') as stream:
                    stream.write(bundle.read(info))
    project = destination / STUDY_NAME
    if not project.is_dir():
        raise ValueError('Expected project directory missing after extraction')
    return project


def actual_files(root: Path, ignore_generated_caches: bool = False) -> dict[str, Path]:
    result = {}
    for path in root.rglob('*'):
        relative = path.relative_to(root)
        if ignore_generated_caches and ('__pycache__' in relative.parts or path.suffix in ('.pyc', '.pyo')):
            continue
        if path.is_symlink():
            raise ValueError('Unexpected symlink in extracted project')
        if path.is_file():
            result[relative.as_posix()] = path
        elif not path.is_dir():
            raise ValueError('Unexpected nonregular extracted file')
    return result


def check_inventory(project: Path, inventory: dict, ignore_generated_caches: bool = False) -> int:
    if inventory.get('format_version') != 1 or inventory.get('root_directory') != STUDY_NAME:
        raise ValueError('Unrecognized inventory format or project root')
    expected = {}
    for row in inventory['files']:
        name = safe_relative(row['path']).as_posix()
        if name == INVENTORY or name in expected:
            raise ValueError('Self-referential or duplicate inventory row: ' + name)
        if type(row['bytes']) is not int or row['bytes'] < 0:
            raise ValueError('Invalid inventory byte count: ' + name)
        sha = row['sha256']
        if not isinstance(sha, str) or len(sha) != 64 or any(c not in '0123456789abcdef' for c in sha):
            raise ValueError('Invalid inventory digest: ' + name)
        expected[name] = row
    actual = actual_files(project, ignore_generated_caches)
    if set(actual) != set(expected) | {INVENTORY}:
        missing = sorted(set(expected) - set(actual))
        extra = sorted(set(actual) - (set(expected) | {INVENTORY}))
        raise ValueError('Inventory membership mismatch: ' + json.dumps({'missing': missing, 'extra': extra}))
    for name, row in expected.items():
        data = actual[name].read_bytes()
        if len(data) != row['bytes'] or digest(data) != row['sha256']:
            raise ValueError('Inventory content mismatch: ' + name)
    return len(expected)


def run_checks(archive: Path, receipt: dict) -> None:
    receipt['archive_sha256'] = digest(archive.read_bytes())
    receipt['archive_bytes'] = archive.stat().st_size
    with tempfile.TemporaryDirectory(prefix='scientific-identification-reproduction-') as temporary:
        project = extract(archive, Path(temporary))
        raw_inventory = (project / INVENTORY).read_bytes()
        inventory = json.loads(raw_inventory)
        receipt['inventory_sha256'] = digest(raw_inventory)
        receipt['inventoried_files'] = check_inventory(project, inventory)
        receipt['inventory_before'] = 'PASS'
        commands = [
            [sys.executable, '-B', '-m', 'unittest', 'discover', '-s', 'src', '-p', 'test_*.py'],
            [sys.executable, '-B', 'src/replay.py'],
            [sys.executable, '-B', 'src/analyze.py'],
            [sys.executable, '-B', 'src/audit_independent.py'],
            [sys.executable, '-B', 'src/verify_comparison.py'],
        ]
        for command in commands:
            started = time.monotonic()
            try:
                result = subprocess.run(command, cwd=project, text=True, encoding='utf-8',
                                        stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, check=False)
            except subprocess.TimeoutExpired as exc:
                def decoded(value):
                    return value.decode('utf-8', errors='replace') if isinstance(value, bytes) else (value or '')
                receipt['commands'].append({'command': command, 'returncode': None,
                    'elapsed_seconds': round(time.monotonic() - started, 6),
                    'stdout': decoded(exc.stdout), 'stderr': decoded(exc.stderr), 'timed_out': True})
                raise RuntimeError('Reproduction command exceeded 60 seconds: ' + ' '.join(command)) from exc
            entry = {'command': command, 'returncode': result.returncode,
                     'elapsed_seconds': round(time.monotonic() - started, 6),
                     'stdout': result.stdout, 'stderr': result.stderr}
            receipt['commands'].append(entry)
            if result.returncode:
                raise RuntimeError('Reproduction command failed: ' + ' '.join(command))
        receipt['unchanged_inventoried_files'] = check_inventory(project, inventory, ignore_generated_caches=True)
        if (project / INVENTORY).read_bytes() != raw_inventory:
            raise ValueError('Inventory itself changed during reproduction')
        receipt['inventory_after'] = 'PASS'
        receipt['inventory_self_unchanged'] = True
        comparison = json.loads((project / 'results/comparison_verification.json').read_text())
        if comparison['status'] != 'PASS':
            raise ValueError('Reproduced comparison did not pass')
        receipt['reproduced_comparison'] = {key: comparison[key] for key in
            ['status', 'run_count', 'events', 'mechanical_comparisons', 'report_judgment_comparisons']}
    receipt['temporary_extraction_removed'] = True
    receipt['status'] = 'PASS'


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--receipt', type=Path, help='External JSON receipt; defaults beside archive')
    args = parser.parse_args()
    archive = args.archive.resolve()
    receipt_path = (args.receipt or archive.with_suffix('.reproduction.json')).resolve()
    if receipt_path == archive or receipt_path.is_relative_to(SCRIPT_ROOT):
        raise ValueError('Reproduction receipt must be outside the study project and distinct from the ZIP')
    receipt = {'status': 'FAIL', 'archive': str(archive),
               'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'python_version': platform.python_version(), 'commands': [],
               'scope': 'Fresh extraction, exact inventory verification, five retained standard-library checks, and byte-identical post-check comparison. No participant trials or network calls are made.'}
    try:
        run_checks(archive, receipt)
    except Exception as exc:
        receipt['error'] = type(exc).__name__ + ': ' + str(exc)
    receipt['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    receipt_path.write_text(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    print(json.dumps({key: receipt.get(key) for key in
                      ['status', 'archive_sha256', 'inventoried_files', 'unchanged_inventoried_files', 'error']}
                     | {'commands_passed': sum(c['returncode'] == 0 for c in receipt['commands']),
                        'receipt': str(receipt_path)}, indent=2))
    if receipt['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
