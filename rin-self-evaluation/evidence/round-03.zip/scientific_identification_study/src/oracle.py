"""Exact finite identification oracle, independent of participant choices.

The objective is guaranteed identification of the target sign, not recovery of
all nuisance parameters or maximization of Shannon information. Positive costs,
fixed parameters and identical resets make repeated deterministic measurements
uninformative. A finite decision-tree dynamic program therefore explores every
useful adaptive policy by partitioning the current hypothesis set.

Public interfaces accept world dictionaries. minimum_guaranteed_cost returns an
integer or math.inf; diagnostic dictionaries encode an infinite cost as None so
they remain strict-JSON-compatible. Empty hypothesis sets raise ValueError when
asked for an identification guarantee, rather than earning a vacuous success.
"""
from __future__ import annotations

import math
from functools import lru_cache
from models import enumerate_worlds, evaluate, is_admissible, target_sign, world_key


def compatible(task, observations=None):
    """Enumerate worlds matching the complete supplied observation history.

    With observations=None, use task.initial_observations. A supplied list is
    the complete history, including initial observations; it is not an implicit
    delta to be appended. Repeated identical observations are harmless.
    """
    history = task['initial_observations'] if observations is None else observations
    return [w for w in enumerate_worlds(task)
            if all(evaluate(task, w, o['settings']) == o['value'] for o in history)]


def target_signs(worlds):
    present = {target_sign(w) for w in worlds}
    return [label for label in ('negative', 'positive') if label in present]


def _encoded_cost(value):
    return None if math.isinf(value) else int(value)


def _normalise(task, worlds):
    values = compatible(task) if worlds is None else list(worlds)
    if not values:
        raise ValueError('No compatible worlds: inconsistent evidence is not identification.')
    if any(not is_admissible(task, w) for w in values):
        raise ValueError('World subset contains an inadmissible parameter dictionary.')
    unique = {world_key(w): dict(w) for w in values}
    return [unique[k] for k in sorted(unique)]


class IdentificationOracle:
    """Small exact policy oracle over a specified current hypothesis set."""
    def __init__(self, task, worlds=None):
        self.task = task
        self.worlds = _normalise(task, worlds)
        self.experiments = list(task['experiments'])
        if len({e['id'] for e in self.experiments}) != len(self.experiments):
            raise ValueError('Experiment identifiers must be unique.')
        if any(type(e['cost']) is not int or e['cost'] <= 0 for e in self.experiments):
            raise ValueError('Every experiment must have positive integer cost.')
        self.full = tuple(range(len(self.worlds)))
        self.signs = tuple(target_sign(w) for w in self.worlds)
        self.responses = {
            e['id']: tuple(evaluate(task, w, e['settings']) for w in self.worlds)
            for e in self.experiments}

        @lru_cache(None)
        def minimum(indices):
            if len({self.signs[i] for i in indices}) == 1:
                return 0
            best = math.inf
            for experiment in self.experiments:
                parts = self.partitions(indices, experiment['id'])
                # A constant observation cannot change any future decision.
                if len(parts) <= 1:
                    continue
                tail = max(minimum(child) for child in parts.values())
                best = min(best, experiment['cost'] + tail)
            return best
        self._minimum = minimum

    def partitions(self, indices, experiment_id):
        groups = {}
        for i in indices:
            groups.setdefault(self.responses[experiment_id][i], []).append(i)
        return {value: tuple(group) for value, group in sorted(groups.items())}

    def minimum_cost(self):
        return self._minimum(self.full)

    def action_diagnostics(self, budget):
        if type(budget) is not int or budget < 0:
            raise ValueError('Budget must be a nonnegative integer.')
        answer = []
        for e in self.experiments:
            parts = self.partitions(self.full, e['id'])
            branch_costs = [self._minimum(indices) for indices in parts.values()]
            worst = max(branch_costs)
            remaining = budget-e['cost']
            outcomes = []
            for value, indices in parts.items():
                signs = sorted({self.signs[i] for i in indices})
                tail = self._minimum(indices)
                outcomes.append({'value': value, 'candidate_count': len(indices),
                    'target_signs': signs, 'minimum_followup_cost': _encoded_cost(tail),
                    'guarantees_with_remaining_budget': remaining >= 0 and tail <= remaining})
            answer.append({'experiment_id': e['id'], 'cost': e['cost'],
                'affordable': remaining >= 0, 'remaining_budget': max(remaining, 0),
                'outcomes': outcomes,
                # Ambiguity here is the number of distinct target signs, 1 or 2.
                'worst_case_residual_target_ambiguity': max(len(x['target_signs']) for x in outcomes),
                'worst_case_followup_cost': _encoded_cost(worst),
                'minimum_total_cost_if_first': _encoded_cost(e['cost']+worst),
                'preserves_guarantee': remaining >= 0 and worst <= remaining})
        return answer


def minimum_guaranteed_cost(task, worldsubset=None):
    return IdentificationOracle(task, worldsubset).minimum_cost()


def can_guarantee(task, worldsubset, budget):
    if type(budget) is not int or budget < 0:
        return False
    return minimum_guaranteed_cost(task, worldsubset) <= budget


def per_action(task, worldsubset, budget):
    return IdentificationOracle(task, worldsubset).action_diagnostics(budget)


def observational_classes(task, worldsubset=None):
    """Equivalence under every available experiment, independent of budget.

    With fixed parameters and identical resets, repeating experiments supplies
    no extra information. A mixed-sign class proves that no available policy at
    any budget can identify the target for all worlds in that class.
    """
    worlds = _normalise(task, worldsubset)
    experiments = task['experiments']
    groups = {}
    for w in worlds:
        signature = tuple(evaluate(task, w, e['settings']) for e in experiments)
        groups.setdefault(signature, []).append(w)
    return [{'responses': dict(zip([e['id'] for e in experiments], signature)),
             'worlds': group, 'target_signs': target_signs(group),
             'target_identified': len(target_signs(group)) == 1}
            for signature, group in sorted(groups.items())]


def information_diagnostics(task, worldsubset=None):
    """Illustrative information under uniform weights on current candidates.

    Uniform weights are a diagnostic convention, not a statement about how
    truths were sampled and not the policy objective. Exact partition sizes and
    target labels accompany the floating-point entropy summaries.
    """
    oracle = IdentificationOracle(task, worldsubset)
    n = len(oracle.worlds)
    def entropy(counts):
        total = sum(counts)
        return -sum((c/total)*math.log2(c/total) for c in counts if c)
    prior_target = entropy([oracle.signs.count(label) for label in ('negative','positive')])
    results = []
    for e in oracle.experiments:
        parts = oracle.partitions(oracle.full, e['id'])
        remaining_target = 0.0
        encoded = []
        for value, indices in parts.items():
            counts = {label: sum(oracle.signs[i] == label for i in indices)
                      for label in ('negative','positive')}
            remaining_target += len(indices)/n*entropy(list(counts.values()))
            encoded.append({'value': value, 'candidate_count': len(indices), 'target_counts': counts})
        target_gain = prior_target-remaining_target
        if abs(target_gain) < 1e-12:
            target_gain = 0.0
        results.append({'experiment_id': e['id'], 'outcomes': encoded,
                        'outcome_entropy_bits': entropy([len(v) for v in parts.values()]),
                        'target_information_bits': target_gain})
    return {'weighting': 'uniform over the current compatible parameter dictionaries; illustrative only',
            'candidate_count': n, 'prior_target_entropy_bits': prior_target, 'experiments': results}
