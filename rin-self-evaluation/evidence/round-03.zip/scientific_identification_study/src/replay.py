"""Verify frozen files and replay every retained instrument event."""
import datetime
import hashlib
import json
from pathlib import Path
from service import digest,transition
from grade import grade_run

ROOT=Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def replay_run(spec,frozen):
    folder=ROOT/'runs'/spec['run_id']
    for name,key in [('initial_state.json','initial_state_sha256'),('prompt.txt','prompt_sha256'),('launch_message.txt','launch_message_sha256')]:
        assert sha(folder/name)==spec[key],f'{folder.name}: {name} changed'
    state=json.loads((folder/'initial_state.json').read_text())
    path=folder/'events.jsonl'
    events=[json.loads(l) for l in path.read_text().splitlines()] if path.exists() else []
    prev='0'*64
    for n,raw in enumerate(events,1):
        e=dict(raw);saved=e.pop('event_hash')
        assert saved==digest(e) and e['index']==n and e['previous_event_hash']==prev
        assert datetime.datetime.fromisoformat(e['utc'])>=datetime.datetime.fromisoformat(frozen['frozen_at_utc'])
        assert e['state_before_hash']==digest(state)
        state,response=transition(state,e['request'])
        assert response==e['response'] and e['state_after_hash']==digest(state),f'{folder.name}:{n}'
        prev=saved
    assert state==json.loads((folder/'state.json').read_text())
    return {'events':len(events),'final_event_hash':prev,'mechanical':grade_run(state,events),
        'report':state['report'],'registration':state['registration'],'final_submission':state['final_submission'],
        'public_task':state['task']}

def main():
    frozen=json.loads((ROOT/'protocol/frozen.json').read_text())
    for p,h in frozen['source_hashes'].items():
        assert sha(ROOT/p)==h,'Frozen source changed: '+p
    rows=[{**{k:v for k,v in r.items() if k!='launch_message'},**replay_run(r,frozen)} for r in frozen['runs']]
    result={'status':'PASS','frozen_protocol_sha256':sha(ROOT/'protocol/frozen.json'),
        'run_count':len(rows),'event_count':sum(r['events'] for r in rows),'runs':rows}
    (ROOT/'results/replay.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':'PASS','runs':len(rows),'events':result['event_count'],
        'finished':sum(r['mechanical']['finished'] for r in rows),
        'identified_and_reported':sum(r['mechanical']['target_identified_and_reported'] for r in rows),
        'guarantee_losses':sum(r['mechanical']['guarantee_losing_decisions'] for r in rows)},indent=2))

if __name__=='__main__':
    main()
