THE EXPERIMENT THAT ANSWERS THE QUESTION
Josh & Rin's Lab — Scientific Identification Study
Record: JRR-SCIENTIFIC-IDENTIFICATION-2026-11-17-003
User-facing date: November 17, 2026 (America/New_York)

RESULT

This authored, finite, noiseless experiment compares requested native selectors
gpt-6-astra and gpt-6.2-astra. There are six instrument profiles, two predeclared
hidden truths per profile, and one fresh participant context for each model in
each truth: 24 contexts and 12 matched task pairs. No poor outcome was retried.

For each model:
  - 10/10 initially feasible target signs identified.
  - 10/10 identified without a guarantee-losing measurement choice.
  - 2/2 structurally impossible tasks correctly certified with explicit witnesses.
  - 12/12 exact initial sets and 12/12 exact final sets of compatible models.
  - 12/12 supported final reports; zero unsupported definite target directions.

The ten feasible tasks, two impossible tasks, and twelve complete reports are
different denominators. Impossible tasks have null for guarantee-preserving
identification. Correctly retaining ambiguity is a successful scientific report.

Both models reached the correctness ceiling here. The result demonstrates no
observed 6.2 advantage on these defined endpoints; it does not establish equal
general ability, a real-world reliability rate, or a frontier-science discovery.

READING THE EVIDENCE

The_Experiment_That_Answers_the_Question.pdf
  Seven-page reader report: methods, exact scientific reasoning, complete
  matched result ledger, verification and limits.

protocol/PROTOCOL.md and TOOL_CONTRACT.md
  Scientific objectives, closed model families, allowed experiments, recording
  contract, endpoint definitions and stop rule.

protocol/frozen.json
  Pre-participant source hashes, truth/model mapping, launch order and payload
  hashes. Frozen at 2026-11-18T02:06:35.534991+00:00 (9:06:35 p.m. Eastern on
  November 17). SHA256:
  356522c068aa6285326d32803c02ec6d23e8f3fa74d045f1c607fea764466d42

protocol/oracle_properties.json
  Exact initial counts, minimum guaranteed costs, outcome partitions and
  explicitly illustrative uniform-weight information calculations.

runs/<opaque_id>/
  Initial and final instrument states, original prompt and launch text, and every
  instrument request/response with a hash-linked event record. Published states
  include hidden truth for reproduction; participants were instructed not to
  inspect them. Original absolute paths remain in the historical prompts, but
  the replay scripts resolve paths relative to the extracted project.

work/<opaque_id>/
  Participant-created local calculation artifacts when such files were used.
  The archive does not contain complete host-tool transcripts or hidden reasoning.

provenance/native_dispatch.json and native_messages/
  Root transcriptions of accepted native dispatches and delivered final answers.
  Requested selectors are recorded; exact backend snapshots are unverified.

provenance/root_adjudications.json and independent_adjudications.json
  Individually read, exact-text-hash-bound final-report judgments by two model
  reviewers. These are not external human reviews or a generic prose classifier.

provenance/audit_spec.json and review_packet.json
  Public scientific definitions and shuffled raw records supplied to the
  independent implementation with model identities and primary scores withheld.

provenance/PREFLIGHT_REVIEW.md, INDEPENDENT_REVIEW.md, REPORT_REVIEW.md
  Source review, independent outcome review, and reader-report claim review.

results/summary.json and per_run.csv
  Full per-model, per-pair and per-run outcomes. The summary retains mechanical
  and prose-review dimensions separately.

results/replay.json, independent_review.json, comparison_verification.json
  Frozen-service replay, separately implemented audit, and field-by-field
  comparison. There are 78 events, 576 agreeing mechanical field comparisons
  and 72 agreeing report judgments. These comparison counts are not extra
  participant runs or independent problem families.

results/pdf_qa.json and rendered_pdf/
  Final PDF identity, structural checks, rendered pages and visual-review record.

provenance/sources.json
  Primary literature supporting the background framing. The live findings,
  finite-family counts and exact proofs are derived from this study's records.

src/
  Frozen instrument/oracle/grader/test sources and later analysis, independent
  audit, report-generation and packaging programs. frozen.json identifies the
  pre-participant files. The later programs are retained, not retroactively
  described as having been frozen before outcomes.

REPRODUCING THE RESULTS

Use Python 3; the tested version is in results/runtime_versions.json. The core
checks require only the standard library. From this extracted directory run:

  python3 -m unittest discover -s src -p "test_*.py"
  python3 src/replay.py
  python3 src/analyze.py
  python3 src/audit_independent.py
  python3 src/verify_comparison.py

The 33 semantic tests are instrument/oracle checks, not live participants.
The replay restores every recorded response and intermediate state from the
frozen service. The independent audit imports none of the primary study code.
Its mechanical reporting metrics use the submitted sign certificates; separate
prose metrics retain model-reviewer interpretation of the actual explanations.

src/reproduce_archive.py accepts the evidence ZIP and performs these checks in
a fresh temporary extraction, verifies inventory hashes before and afterward,
and writes its receipt outside the archive. See its --help for arguments.
It does not launch models, request measurements, use a network or spend API
credits. src/prepare.py documents original study initialization and is not part
of record replay.

Optional report regeneration additionally requires ReportLab and DejaVu fonts.
The report environment versions are recorded in results/runtime_versions.json.
PDF regeneration and raster previews are not required to reproduce scientific
results. Poppler created the retained 1400-pixel page previews.

ARCHIVE IDENTITY

provenance/file_inventory.json lists the SHA256 and byte size of every archive
file except the inventory itself. The inventory is included in the ZIP. Lock
files, Python caches and temporary files are omitted. The external .sha256 file
identifies the whole ZIP. A separate reproduction receipt binds its checks to
that ZIP hash without a self-referential archive checksum.

INTERPRETING THE GUARANTEE

The scientific goal is to choose experiments that identify the target sign for
every initially compatible world within the measurement credits. Before each
actual choice, the oracle checks every possible outcome. A choice loses the
guarantee if some possible branch can no longer be solved with remaining
credits, even if the actual branch happens to give a supported answer.
These endpoints score observed actions plus their counterfactual feasibility;
they do not show an actor executing an entire unseen policy.

No such loss occurred. All four passive cases were impossible from the start,
because opposite directions could produce identical outputs at every permitted
probe. Three actors stopped without measuring. One older-model actor spent two
credits to identify the speed magnitude while retaining direction uncertainty.
That optional nuisance inference is a descriptive resource tradeoff; the
protocol did not impose a post-hoc penalty for it.

BOUNDARIES

This is same-lab verification, not external replication or timestamp attestation.
Participants shared a filesystem bounded by instruction, not operating-system
isolation. The service atomically replaces state and then appends an event; the
pair is not crash-atomic. Hashes and full replay check internal consistency.
No comparative claim about latency, tokens, billing or ChatGPT tier equivalence
is made. Local calculation tools were permitted in both conditions. All reported
inferences are conditional on the declared exact finite model families.
