# Independent blinded review

## Result

The independent audit completed for **24 shuffled runs and 78 instrument events**. All initial and final model certificates are exact; every initial feasibility assessment is correct; all four structural nonidentifiability witnesses are valid; and every exact final report is supported by its observations. All 20 initially feasible runs identify and accurately report the target sign without any pre-outcome loss of the worst-case guarantee. The four initially impossible runs correctly preserve sign uncertainty, so their guarantee-preserving-identification field is `null`.

No unsupported definite target claim or nuisance-parameter certainty claim was found. All native final messages exactly match the sealed report text. All event content hashes, event links, state links, initial and final endpoint hashes, full state-transition replays, instrument outputs, and measurement/call accounting checks passed.

This is a post-freeze independent outcome audit. It is not a model ranking, a population estimate of model performance, or external attestation of the study's execution environment.

## Blinding and source scope

The reviewer first read only `provenance/audit_spec.json` and implemented the finite-world enumeration and adaptive-budget solver before receiving the review packet. The public participant contract, `protocol/TOOL_CONTRACT.md`, and a coordinator-provided schema/accounting clarification were then used to implement the raw event adapter. The clarification specified rejected-request call accounting and that registration/final-submission state stores every request field except `op`.

The outcome input was `provenance/review_packet.json`: 24 shuffled raw records with opaque run identifiers, public tasks, initial/final states, events, and native final text. Model selectors, dispatch order, and root grades were withheld. The reviewer did not inspect other study source, the frozen-source file, root results, native dispatch records, other run/work files, or model mapping, and did not browse or use other agents. The implementation imports no study module.

The three authored deliverables are:

- `src/audit_independent.py`: standalone standard-library implementation.
- `provenance/independent_adjudications.json`: individual manual report judgments and substantive notes bound to exact UTF-8 SHA256 report hashes.
- `results/independent_review.json`: reproducible combined mechanical and manual results, including every requested run-level field.

This memo records scope, reasoning, checks, and limitations.

## Independent scientific model

The polynomial instrument was implemented directly as

`Y(x,r) = B + s*(a*x + c*x*x + r)`.

The phase instrument was implemented directly as

`Y(t,delta) = int(((beta + omega*t + delta) % 8) < 4)`.

All declared domain combinations were enumerated using integer arithmetic. Candidate worlds were filtered against the complete initial observation set and every successful additional measurement. Neither the participant's certificate nor the hidden truth was used to determine which candidate worlds were observationally possible. Hidden truth was used only to check that the instrument returned the proper observation.

The target is the sign of `a` or `omega`, not uniqueness of the complete world. The initial mathematical results were:

| Profile | Initial worlds | Initial signs | Guaranteed within budget? | Guarantee-preserving first measurements |
|---|---:|---|---|---|
| `poly_complement` | 16 | Negative, positive | Yes | All four approved experiments |
| `poly_cost` | 8 | Negative, positive | Yes | `x1_r1` only, costing two credits |
| `phase_active` | 8 | Negative, positive | Yes | `A` only |
| `poly_known` | 7 | Negative, positive | Yes | `x0_r0`, `xm1_r0`, or `x3_r0` |
| `poly_target` | 8 | Negative, positive | Yes | `x1_r1` only, costing one credit |
| `phase_passive` | 8 | Negative, positive | No | None |

For `poly_complement`, equal initial readings imply `a=-3c` and `B=30+2sc`. A calibration determines `s`; a shape/offset measurement determines the remaining ambiguity. Either type can be measured first, but the second choice must supply the complementary information.

For `poly_cost` and `poly_target`, write `q=sc`. The initial readings and domains imply `q` is one of 1, 2, 3, 4, `sa=13-3q>0`, and `B=19+2q`. Thus the sign of `a` equals `s`. Calibration identifies the sign while leaving four complete parameter worlds. Its different cost matters: spending one credit on a shape probe in `poly_cost` makes the needed two-credit calibration unaffordable.

For `poly_known`, the initial constraints are `a=5-3c` and `B=25+2c`, with seven compatible integer values of `c`. Each approved zero-control shape probe separates these candidates. Calibration gives no new information because `s` is already fixed.

For `phase_active`, the guaranteed policy is `A`, followed by `B` when `A=0` and `C` when `A=1`. In either follow-up, output 0 identifies positive velocity and output 1 identifies negative velocity. This policy was checked over all eight initial worlds.

For `phase_passive`, `(beta,omega) -> (3-beta,-omega)` transforms every residue `r` into `(3-r) mod 8`, preserving whether it lies below 4. It pairs every compatible world with an opposite-sign world that agrees on every approved probe. Each submitted witness `(0,1)/(3,-1)` is in the initial set and gives the identical approved-probe vector `[1,1,0,0,0,0]` at times 2 through 7. Structural ambiguity persists even with more measurement credits.

## Adaptive guarantee and certificate checks

The solver recursively considers every affordable approved experiment, partitions the current candidates by exact output, and asks whether **every** possible branch has some guaranteed continuation within the remaining credits. A nonempty state whose candidates all share one sign is a solved leaf; uniqueness of nuisance parameters is unnecessary. Positive integer measurement costs bound the recursion at at most two credits. Repeated probes are permitted and charged.

Before each actual successful measurement, the audit checks whether a guaranteed strategy exists and whether the selected action leaves a guaranteed continuation for every possible outcome. A loss is recorded before the actual outcome is used and is never erased by a favorable observed outcome. For example, in the active-phase task, choosing `B` first loses the guarantee: `B=0` happens to identify a positive sign, but `B=1` leaves no guaranteed one-credit continuation. Choosing `C` first similarly has a favorable negative branch but loses its guarantee on the other branch. This distinction was explicitly verified in the independent solver, although no actual run made either choice.

The mechanical `target_identified_and_reported` field requires a unique surviving target sign and an exactly matching final `possible_signs` certificate. The mechanical `unsupported_definite_target_claim` field flags a valid singleton sign certificate that differs from the full surviving sign set. `identified_without_losing_guarantee` means: initially feasible, certificate-based `target_identified_and_reported`, and zero pre-outcome guarantee losses. It is `null` when the task was initially infeasible. The separately named `target_identified_and_reported_in_prose` and `unsupported_definite_target_in_prose` fields preserve the manual semantic judgments; they agree with the certificate endpoints in every observed run.

Only actual chosen actions are scored; the audit does not infer an unobserved participant policy from one trajectory. Where a final report explicitly states a complete mathematical policy, its claim is additionally checked in the manual review.

Model certificates require exactly the declared parameter keys and domain values. JSON integers and finite integral floats are accepted; booleans are excluded. Duplicate worlds are rejected and order is irrelevant. Sign lists are checked with mathematical set semantics and must contain only `negative`/`positive`. Nonidentifiability witnesses require two initially compatible opposite-sign worlds that agree on **every** approved probe, not just the probes that happened to be measured.

## Manual report review

Every one of the 24 sealed reports was displayed and read in full in packet order. The reviewer checked each report's algebra, listed candidate worlds, target conclusion, parameter-certainty claims, costs, and any explicit global guarantee or symmetry argument against independent calculations. Native text was then compared byte-for-byte at the string level with the sealed report. The semantic judgments were individually authored; a generic text classifier was not used.

Each report has several specific notes in `independent_adjudications.json`. The implementation refuses to combine a manual judgment with a different report hash or a different run identifier. Therefore reproduction preserves the manual semantic review rather than silently regenerating prose grades through a heuristic.

The four passive-phase reports correctly state structural direction ambiguity. Three runs took no measurements and retained eight candidates. Run `sb80b775402` used both credits and observed 1 at time 2 and 0 at time 3; these observations leave `(1,1)` and `(2,-1)`. Its report correctly identifies speed magnitude 1 while retaining uncertain direction and offset. The stated further-probe vector `[1,0,0,0,0,1]` is correct for both remaining worlds. These measurements supply real nuisance information, even though target identification is impossible.

## Provenance and accounting

Canonical hashes use SHA256 of JSON with sorted keys, comma/colon separators, `ensure_ascii=False`, and `allow_nan=False`. Every event hash was recomputed excluding `event_hash`; the initial previous-event hash was checked against 64 zeros; consecutive event and state links were checked; and the endpoint hashes were independently recomputed from the full initial and final state objects. The complete successful-event state sequence was also reconstructed from the public contract and raw requests/responses, checking each intermediate state hash rather than only the endpoints.

The claimed protocol freeze time in the independent specification and packet agrees at **2026-11-18 02:06:35.534991 UTC**. The observed event interval is **02:07:05.459019 through 02:22:11.144503 UTC** that day. All event timestamps are after freeze and ordered within each run. The packet's filesystem modification time was 02:22:47.435245 UTC when checked. Manual adjudications were completed at **02:25:20.433844 UTC**. These records are consistent with post-freeze execution and post-run adjudication.

Both inputs give frozen protocol digest `356522c068aa6285326d32803c02ec6d23e8f3fa74d045f1c607fea764466d42`. The reviewer cross-checked that metadata without opening the withheld frozen-source file. The independent output also records canonical input/adjudication hashes and the implementation's byte hash.

Across all runs, there are **54 operational calls, 30 measurements, and 24 free finish events**, totaling 78 events. Measurements spend 34 of the 40 aggregate available credits, leaving six credits in the three unmeasured passive-phase runs. All 24 runs finish. Every measurement value matches the declared instrument equation applied to the immutable logged truth, and every call count, cost, credit balance, observation list, and measurement list matches the independent replay.

## Limitations and reproduction

The audit establishes internal mathematical and transcript consistency for this small authored finite study. Hash chains are tamper-evident only relative to the supplied records; there is no external timestamp attestation, write isolation, or claim that participant filesystem restrictions were enforced by an operating-system boundary. Record timestamps and file modification times do not independently establish historical authenticity. The frozen source's actual bytes were intentionally not rehashed by the blinded reviewer.

All 24 prose judgments are supported for the exact reports reviewed. That conclusion does not imply that a different report, unobserved strategy, or larger scientific task would receive the same judgment. All 20 feasible trajectories succeed, so these data alone do not distinguish participants on correctness. Model identities remained withheld throughout this review.

Reproduce the combined independent results using only the permitted packet/specification and the authored adjudications:

```sh
python3 src/audit_independent.py
```

The `--initial-only` option prints independent initial candidate sets and feasible first-action summaries without loading the outcome packet. The full command writes `results/independent_review.json` and requires exactly 24 unique run identifiers and exact report-hash matches for all manual adjudications.
