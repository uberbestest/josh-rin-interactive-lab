# Preflight review

Recorded at 2026-11-18T02:07:10.376011+00:00. Reviewer: same-session agent `/root/science_design_review`.

## Decision

**PASS for the declared 24-context scientific-identification study.** No remaining launch blocker was found. The reviewer communicated this decision before the root proceeded to freeze and launch. This memo may be written shortly after that communication; its source hashes identify the exact reviewed files. It is not a participant result, backend attestation, or external replication.

## Exact-source checks

Read the model definitions, oracle, service, grader, preparation and replay scripts, CLI transport, all three test modules, protocol, and participant contract. Independently ran `python3 -m unittest discover -s src -p 'test_*.py' -v`: **33 tests passed**.

The four polynomial profiles have initial compatible-set counts 7, 8, 16, and 8, and minimum guaranteed costs 1, 1, 2, and 2. Separate in-memory enumeration before source review independently confirmed these values and each profile's guarantee-preserving first actions. The active phase profile has eight candidates and minimum cost two; the passive profile has eight candidates and is structurally unidentifiable.

The minimum-cost recursion terminates because informative observations strictly shrink the compatible set; positive costs and deterministic identical resets make repeated measurements uninformative. Explicit depth-at-most-two tree enumeration cross-checks the budgeted feasibility calculations for every profile at budgets zero, one, and two. Observational equivalence classes provide the separate structural impossibility check.

Twelve additional scripted in-memory integration witnesses exercised every declared profile/truth cell through registration, measurements, finish, and grading. These were semantic checks, not model participants, and created no run folders. All ten feasible cells identified the target without a guarantee-losing decision; both passive cells retained ambiguity with a valid reflection pair and no measurements. This supports the declared 20 feasible plus four structurally unidentifiable contexts across the two requested selectors.

## Evidence and scoring boundaries

- The evaluator reconstructs hypotheses from the full declared family and actual delivered observations. An incorrect or incomplete registration never restricts evaluator hypotheses.
- Registration and finish acknowledge recording only. Scientific mistakes are retained without correction, rejection, or oracle feedback.
- Registration is sealed before measurements and cannot be revised afterward. The actor-facing contract and launch text explicitly require registration even when no measurements will be taken.
- A standalone finish without registration still retains its final certificate/report, but registration presence, initial certificate, and initial feasibility endpoints fail. An additional in-memory check confirmed this behavior.
- Candidate-list comparison ignores ordering, rejects duplicate worlds, requires exactly the declared keys, and checks domain membership. Finite integer-valued JSON numbers are normalized to integers; booleans are excluded. Sign lists are compared as sets; feasibility assertions must be booleans.
- A structural witness must contain two initially compatible, opposite-target worlds with identical responses to every listed experiment. The phase reflection satisfies this stronger condition, not merely indistinguishability under the measurements taken.
- Guarantee loss is assessed using the full candidate set before a successful measurement and every possible outcome of the chosen action. Later favorable observations do not erase earlier losses.
- The test suite explicitly verifies the favorable phase B-then-A path: the selected negative truth can become supported and correctly reported despite the earlier loss of the two-credit guarantee. The supported conclusion remains supported; the design error is retained separately.
- Structurally impossible contexts are excluded from guaranteed-identification/design-success denominators. The no-loss count alone must not be presented as proof of a successful design in those contexts.
- Target identification is independent of unique-parameter identification. Correct polynomial reference measurements can leave four compatible models; the selected optimal active phase paths leave three. Exact final certificates retain these nuisance alternatives.
- Operational errors, credit use, actual-history target identification, exact certificates, design quality, and final prose support are separate endpoints.

## Preparation and paired execution

Source inspection confirms 12 matched cases, two requested selectors, a fixed pair shuffle, alternating first-dispatch selector, fresh contexts without parent conversation, and the same inherited reasoning configuration. Public task text includes the complete domains and catalog but not the hidden truth, profile label, or requested selector. The two actors in each pair receive identical public tasks and initial states apart from opaque run/work identifiers.

`prepare.py` asserts normalized prompt equality and byte-identical initial-state equality for every generated pair. Those generated-file checks occur when the root runs preparation; this source preflight did not generate run folders or launch participants. The root should retain the resulting freeze receipt and verify hashes after execution.

## Clarifications resolved

The participant contract now explicitly requires initial registration even when taking no measurements. The protocol table now says `Known orientation; unknown curvature`, accurately reflecting that only detector polarity is fixed in that control.

The d=13 polynomial inference is conditional on the declared parameter bounds: these bounds imply s*a>0, so the signed reference identifies the physical sign while nuisance alternatives can remain. It must not be generalized to an unrestricted polynomial family.

## Scope and remaining limits

This is a small authored, finite, noiseless experiment. The reviewer helped design the phase fixture and is part of the same lab session. The review is not independent external validation or a general scientific-capability benchmark.

The mechanical grader does not judge natural-language report honesty or every nuisance-parameter claim. Its `unique_model_certificate_overclaim` field is specifically about well-formed singleton certificates when more models remain; malformed certificates and broader prose overclaims require the separately planned review. Missing or invalid sign fields are scored separately from an explicit unsupported definite sign.

The action oracle checks counterfactual feasibility of choices on the observed path. It does not show how the participant would behave on every unobserved branch and must not be described as observing a complete participant policy.

Filesystem blindness is instruction-based. The transport is harness-generated, state/event persistence is not crash-atomic, and full host-tool transcripts are not retained. Hashes and timestamps establish internal consistency, not independent provenance authentication. Exact serving snapshots and UI-tier equivalence remain unattested.

No instrument, oracle, grader, protocol, or original-study source was modified by this reviewer. The only user-facing artifact written by the reviewer is this memo.

## Reviewed source SHA-256 values

| File | SHA-256 |
| --- | --- |
| `protocol/PROTOCOL.md` | `7a0e89655b767da3c403e15f75651b7baee59aa4041ef78a43862d6226a46d61` |
| `protocol/TOOL_CONTRACT.md` | `3f74612befd028da7e4cedfb6ae661d60985449f6ea65fff0af1a70147bfc5fe` |
| `src/grade.py` | `4b2452da85a7487fb9a3aaeed6e85e6a2663fda310174101156cef5f52e66052` |
| `src/models.py` | `22f3f160b56910f907c9cee4d85d35ec412c3d60d52048d78e233101bc907a60` |
| `src/oracle.py` | `0cfe5c3baac34bead57add30690867d0005886654f15b7dabd1a689605680332` |
| `src/prepare.py` | `54bbed2de231ff75b7528448fff858386902a76101736b13ba33210a4a68ea9b` |
| `src/replay.py` | `59faef16a6cf80f1284f5b0559d93467680de638fbf14e93d1f18c959770875d` |
| `src/service.py` | `73172c3ae7bb815079aed815aa2905c173cac37b538aeb9ad90d9a5a00623f60` |
| `src/test_grade.py` | `cbcdb2a88114c348cb2aa6b8b6b4dc7e82f45556018a291a3c9474ee0269d5ce` |
| `src/test_oracle.py` | `15546bd451c74e562170bed0c0cd6e410cc9f3ab9b3d2a39ca98d731f551b1d1` |
| `src/test_service.py` | `2aa81ff0d652aa01194fd932843a7fcc3797c0903efa998838c2549ea2126a6a` |
| `src/tool.py` | `76db396485a58cfdc743fcf573acb137848ab562e7abfbb3d9bffaa81e525d68` |
