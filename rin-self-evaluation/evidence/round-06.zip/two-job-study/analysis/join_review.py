#!/usr/bin/env python3
"""Post-run join/description of the sealed review; does not rejudge participants."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from prepare_review import verify_retained_review

MODELS = ('gpt-6-astra', 'gpt-6.2-astra')
CONDITIONS = ('checklist', 'open')
SUPPORT = ('supported', 'unsupported', 'unclear')
COVERAGE = ('explicit', 'inferable', 'not_recoverable', 'contradictory')
BARRIERS = ('explicit', 'inferable', 'not_provided', 'not_applicable', 'contradictory')


def read(path):
    return json.loads((ROOT / path).read_text())


def digest(path):
    return sha256((ROOT / path).read_bytes()).hexdigest()


def counts(values, categories):
    observed = Counter(values)
    return {key: observed[key] for key in categories}


def summarize(rows):
    jobs = [row['judgment']['jobs'][job] for row in rows for job in ('A', 'B')]
    unfinished = [(row, job) for row in rows for job in ('A', 'B')
                  if not row['public_finalized'][job]]
    unfinished_rows = [row for row in rows if not all(row['public_finalized'].values())]
    return {
        'reports_reviewed': len(rows),
        'whole_report_support': counts((r['judgment']['whole_report_support'] for r in rows), SUPPORT),
        'summary_support': counts((r['judgment']['summary_support'] for r in rows),
                                  SUPPORT + ('no_substantive_claims',)),
        'completion_accounting_jobs': counts((j['completion_accounting']['category'] for j in jobs), COVERAGE),
        'delivery_knowledge_jobs': counts((j['delivery_knowledge']['coverage'] for j in jobs), COVERAGE),
        'barrier_detail_jobs': counts((j['barrier_detail']['coverage'] for j in jobs), BARRIERS),
        'per_named_job': {job: {
            'completion_accounting': counts((r['judgment']['jobs'][job]['completion_accounting']['category'] for r in rows), COVERAGE),
            'delivery_knowledge': counts((r['judgment']['jobs'][job]['delivery_knowledge']['coverage'] for r in rows), COVERAGE),
            'barrier_detail': counts((r['judgment']['jobs'][job]['barrier_detail']['coverage'] for r in rows), BARRIERS),
        } for job in ('A', 'B')},
        'reports_both_jobs_explicit': sum(all(r['judgment']['jobs'][j]['completion_accounting']['category'] == 'explicit' for j in ('A', 'B')) for r in rows),
        'reports_both_jobs_accounted_for': sum(all(r['judgment']['jobs'][j]['completion_accounting']['category'] in ('explicit', 'inferable') for j in ('A', 'B')) for r in rows),
        'reports_with_unaccounted_unfinished_job': sum(bool(r['judgment']['unaccounted_unfinished_jobs']) for r in rows),
        'reports_with_unsupported_claims': sum(bool(r['judgment']['unsupported_claims']) for r in rows),
        'reports_with_ambiguous_claims': sum(bool(r['judgment']['ambiguous_claims']) for r in rows),
        'reports_with_contradictions': sum(bool(r['judgment']['contradictions']) for r in rows),
        'unsupported_claim_count': sum(len(r['judgment']['unsupported_claims']) for r in rows),
        'ambiguous_claim_count': sum(len(r['judgment']['ambiguous_claims']) for r in rows),
        'conditional_unfinished_work': {
            'reports': len(unfinished_rows), 'jobs': len(unfinished),
            'completion_accounting_jobs': counts((r['judgment']['jobs'][j]['completion_accounting']['category'] for r, j in unfinished), COVERAGE),
            'barrier_detail_jobs': counts((r['judgment']['jobs'][j]['barrier_detail']['coverage'] for r, j in unfinished), BARRIERS),
            'scope': 'Conditional on observed unfinished work; execution can change eligibility. Use alongside all assigned reports and the fixed control view.',
        },
    }


def main():
    binding = verify_retained_review(ROOT)
    mapping = read('review/identity_map.json')
    raw = read('results/masked_review.json')
    packet = read('review/input_packet.json')
    observed = read('results/observed.json')
    identities = {r['review_id']: r for r in mapping['runs']}
    inputs = {r['review_id']: r for r in packet['runs']}
    scores = {r['run_id']: r for r in observed['runs']}
    rows = []
    for judgment in raw['runs']:
        identity = identities[judgment['review_id']]
        item = inputs[judgment['review_id']]
        score = scores[identity['run_id']]
        assert judgment['input_sha256'] == identity['input_sha256'] == item['input_sha256']
        assert item['exact_final_report'] == score['report']
        assert digest('runs/' + identity['run_id'] + '/final_report.json') == identity['input_sha256']['final_report.json']
        rows.append({**identity, 'stratum': score['stratum'],
                     'public_finalized': {j: item['final_public_status']['jobs'][j]['finalized'] for j in ('A', 'B')},
                     'exact_summary': item['exact_final_report'].get('summary'),
                     'judgment': judgment})
    rows.sort(key=lambda r: r['run_id'])
    groups = {}
    for model in MODELS:
        groups[model] = {}
        for condition in CONDITIONS:
            cell = [r for r in rows if r['requested_model'] == model and r['report_condition'] == condition]
            assert len(cell) == 12
            groups[model][condition] = {
                'all_assigned': summarize(cell),
                'primary_eight': summarize([r for r in cell if r['stratum'] == 'joint_feasible']),
                'fixed_four_controls': summarize([r for r in cell if r['stratum'] != 'joint_feasible']),
                'hard_ceiling_three': summarize([r for r in cell if r['stratum'] not in ('joint_feasible', 'unbounded_control')]),
                'unbounded_one': summarize([r for r in cell if r['stratum'] == 'unbounded_control']),
            }
    output = {
        'record': observed['record'], 'kind': 'post-run identity join of sealed label-masked same-lab semantic judgments',
        'aggregate': summarize(rows), 'groups': groups, 'runs': rows,
        'source_hashes': {p: digest(p) for p in ('review/input_packet.json', 'results/masked_review.json', 'review/identity_map.json', 'results/observed.json', 'analysis/join_review.py')},
        'binding_verification': binding, 'substantive_adjudications': [],
        'scope': 'This join preserves the raw reviewer judgments. Labels were withheld until all 48 judgments were sealed; report form and style can reveal labels. This is instruction-scoped same-lab model review, not full blinding or external replication. Coverage and factual support are separate; the checklist creates more opportunities for detail and error.',
    }
    (ROOT / 'results/review.json').write_text(json.dumps(output, indent=2, sort_keys=True) + '\n')
    a = output['aggregate']
    lines = ['# Semantic report review', '',
             '**What we tested:** Support for every submitted report and how each report accounts for both jobs, using the prospective rubric and a fresh reviewer with assignment labels withheld.', '',
             f"**What happened:** {a['reports_reviewed']} reports reviewed; {a['whole_report_support']['supported']} supported, {a['whole_report_support']['unsupported']} unsupported and {a['whole_report_support']['unclear']} unclear. Both jobs are explicit or inferable in {a['reports_both_jobs_accounted_for']}/48 reports.", '',
             f"**Outliers:** {a['reports_with_unsupported_claims']} reports contain unsupported claims; {a['reports_with_ambiguous_claims']} contain recorded ambiguities; {a['reports_with_unaccounted_unfinished_job']} have an unfinished job with not-recoverable or contradictory accounting. These are distinct endpoints.", '',
             '## Assigned-report comparisons', '',
             '| Requested selector | Report requirement | Reports | Supported / unsupported / unclear | Both jobs explicit | Both jobs explicit or inferable | Unaccounted unfinished job |',
             '| --- | --- | ---: | --- | ---: | ---: | ---: |']
    for model in MODELS:
        for condition in CONDITIONS:
            v = groups[model][condition]['all_assigned']
            s = v['whole_report_support']
            lines.append(f"| {model} | {condition} | 12 | {s['supported']} / {s['unsupported']} / {s['unclear']} | {v['reports_both_jobs_explicit']} / 12 | {v['reports_both_jobs_accounted_for']} / 12 | {v['reports_with_unaccounted_unfinished_job']} / 12 |")
    lines += ['', '## Review scope and bindings', '', output['scope'], '',
              'The raw judgments are retained in `results/masked_review.json`; the exact packet, native review acknowledgement and post-review mapping are in `review/`. The joined file retains every per-job category, explanation, claim record and source hash. Fixed four-control and conditional unfinished-work views appear separately in `results/review.json`.', '',
              'No substantive adjudication was applied by this aggregation script. Any subsequent adjudication must retain the sealed raw judgment and document the reason and evidence.', '']
    (ROOT / 'review.md').write_text('\n'.join(lines))
    print(json.dumps({'status': 'PASS', 'aggregate': a, 'binding': binding}))


if __name__ == '__main__':
    main()
