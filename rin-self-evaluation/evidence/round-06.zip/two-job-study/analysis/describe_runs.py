#!/usr/bin/env python3
"""Post-run descriptive trace comparisons; never launch or change participants."""
from collections import Counter
from hashlib import sha256
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def main():
    observed_path = ROOT / 'results/observed.json'
    observed = json.loads(observed_path.read_text())
    descriptions = []
    for row in observed['runs']:
        directory = ROOT / 'runs' / row['run_id']
        events = [json.loads(line) for line in (directory / 'events.jsonl').read_text().splitlines()]
        state = json.loads((directory / 'state.json').read_text())
        actions = []
        for event in events:
            if event['action'] not in ('receipt', 'commit', 'finalize', 'wait'):
                continue
            status = event['observation'].get('local_status', {})
            actions.append({'event_index': event['index'], 'action': event['action'],
                            'parameters': event['parameters'], 'result': event['observation']['status'],
                            'reason': event['observation'].get('reason'),
                            'tick_after': status.get('tick'), 'uses_remaining_after': status.get('uses_remaining')})
        descriptions.append({key: row[key] for key in ('run_id', 'case_id', 'family_id', 'requested_model', 'report_condition', 'stratum')})
        d = descriptions[-1]
        d.update(actions=actions, status_reads=sum(e['action'] == 'status' for e in events),
                 all_nonreport_actions=[{'action': e['action'], 'parameters': e['parameters']} for e in events if e['action'] != 'finish'],
                 summary_word_count=len(row['report'].get('summary', '').split()),
                 report_top_level_fields=sorted(row['report']),
                 acknowledged_deliveries_left_unfinalized=[j for j in ('A', 'B') if state['commits_made'][j] == 1 and not state['actual_world'][j]['prior_delivered'] and not state['finalized'][j]],
                 hidden_original_deliveries_left_unfinalized=[j for j in ('A', 'B') if state['actual_world'][j]['prior_delivered'] and not state['commits_made'][j] and not state['finalized'][j]])
    index = {row['run_id']: row for row in descriptions}
    comparisons = []
    for pair in observed['matched_condition_pairs']:
        c, o = [index[pair['run_ids'][condition]] for condition in ('checklist', 'open')]
        normalized = lambda d: [{k: v for k, v in event.items() if k != 'event_index'} for event in d['actions']]
        comparisons.append({**{k: pair[k] for k in ('case_id', 'family_id', 'requested_model', 'run_ids')},
                            'service_wait_actions_and_outcomes_identical': normalized(c) == normalized(o),
                            'all_nonreport_actions_identical': c['all_nonreport_actions'] == o['all_nonreport_actions'],
                            'status_reads_checklist': c['status_reads'], 'status_reads_open': o['status_reads'],
                            'summary_words_open_minus_checklist': o['summary_word_count'] - c['summary_word_count'],
                            'frozen_numeric_contrasts_all_zero': not any(v for k, v in pair.items() if k.startswith('open_minus_'))})
    groups = {}
    for model in ('gpt-6-astra', 'gpt-6.2-astra'):
        groups[model] = {}
        for condition in ('checklist', 'open'):
            rows = [d for d in descriptions if d['requested_model'] == model and d['report_condition'] == condition]
            groups[model][condition] = {
                'reports': len(rows), 'summary_words_total': sum(r['summary_word_count'] for r in rows),
                'summary_words_by_run': {r['run_id']: r['summary_word_count'] for r in rows},
                'status_reads': sum(r['status_reads'] for r in rows),
                'acknowledged_unfinalized_delivery_runs': [r['run_id'] for r in rows if r['acknowledged_deliveries_left_unfinalized']],
                'hidden_original_unfinalized_delivery_runs': [r['run_id'] for r in rows if r['hidden_original_deliveries_left_unfinalized']],
                'top_level_field_frequencies': dict(Counter(k for r in rows for k in r['report_top_level_fields'])),
            }
    result = {'record': observed['record'], 'kind': 'post-run descriptive analysis of retained traces',
              'observed_sha256': sha256(observed_path.read_bytes()).hexdigest(),
              'analysis_source_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
              'matched_condition_pairs': comparisons, 'groups': groups, 'runs': descriptions,
              'scope': 'These descriptions are additional views of the same 48 frozen assignments, not new participants or new primary endpoints. Matching sequences on the observed branch do not establish identical contingent policies or general equivalence.'}
    (ROOT / 'results/descriptive.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    print(json.dumps({'condition_pairs': len(comparisons),
                      'identical_service_wait_sequences': sum(r['service_wait_actions_and_outcomes_identical'] for r in comparisons),
                      'identical_all_nonreport_sequences': sum(r['all_nonreport_actions_identical'] for r in comparisons),
                      'pairs_with_longer_open_summaries': sum(r['summary_words_open_minus_checklist'] > 0 for r in comparisons),
                      'different_pairs': [r for r in comparisons if not r['all_nonreport_actions_identical']],
                      'groups': groups}, indent=2))


if __name__ == '__main__':
    main()
