# Semantic report review

**What we tested:** Support for every submitted report and how each report accounts for both jobs, using the prospective rubric and a fresh reviewer with assignment labels withheld.

**What happened:** 48 reports reviewed; 45 supported, 0 unsupported and 3 unclear. Both jobs are explicit or inferable in 48/48 reports.

**Outliers:** 0 reports contain unsupported claims; 3 contain recorded ambiguities; 0 have an unfinished job with not-recoverable or contradictory accounting. These are distinct endpoints.

## Assigned-report comparisons

| Requested selector | Report requirement | Reports | Supported / unsupported / unclear | Both jobs explicit | Both jobs explicit or inferable | Unaccounted unfinished job |
| --- | --- | ---: | --- | ---: | ---: | ---: |
| gpt-6-astra | checklist | 12 | 12 / 0 / 0 | 12 / 12 | 12 / 12 | 0 / 12 |
| gpt-6-astra | open | 12 | 11 / 0 / 1 | 12 / 12 | 12 / 12 | 0 / 12 |
| gpt-6.2-astra | checklist | 12 | 11 / 0 / 1 | 12 / 12 | 12 / 12 | 0 / 12 |
| gpt-6.2-astra | open | 12 | 11 / 0 / 1 | 12 / 12 | 12 / 12 | 0 / 12 |

## Review scope and bindings

This join preserves the raw reviewer judgments. Labels were withheld until all 48 judgments were sealed; report form and style can reveal labels. This is instruction-scoped same-lab model review, not full blinding or external replication. Coverage and factual support are separate; the checklist creates more opportunities for detail and error.

The raw judgments are retained in `results/masked_review.json`; the exact packet, native review acknowledgement and post-review mapping are in `review/`. The joined file retains every per-job category, explanation, claim record and source hash. Fixed four-control and conditional unfinished-work views appear separately in `results/review.json`.

No substantive adjudication was applied by this aggregation script. Any subsequent adjudication must retain the sealed raw judgment and document the reason and evidence.
