# Semantic report review

**What we tested:** Factual support and both-job accounting in every submitted report, using the prospective rubric and a fresh reviewer with assignment labels withheld.

**What happened:** 32 reports reviewed; 29 supported, 0 unsupported and 3 unclear. Both jobs are explicit or inferable in 32/32 reports.

**Outliers:** 0 reports contain unsupported claims; 3 contain recorded ambiguities; 0 have an unfinished job with not-recoverable or contradictory accounting. These are distinct endpoints.

## All assigned reports

| Requested selector | Receipt scope | Reports | Supported / unsupported / unclear | Both jobs explicit | Both jobs explicit or inferable | Unaccounted unfinished job |
| --- | --- | ---: | --- | ---: | ---: | ---: |
| gpt-6-astra | combined | 8 | 8 / 0 / 0 | 8 / 8 | 8 / 8 | 0 / 8 |
| gpt-6-astra | target | 8 | 7 / 0 / 1 | 8 / 8 | 8 / 8 | 0 / 8 |
| gpt-6.2-astra | combined | 8 | 6 / 0 / 2 | 8 / 8 | 8 / 8 | 0 / 8 |
| gpt-6.2-astra | target | 8 | 8 / 0 / 0 | 8 / 8 | 8 / 8 | 0 / 8 |

## Original and reflected strata

| Requested selector | Receipt scope | Orientation | Reports | Supported / unsupported / unclear | Both jobs explicit or inferable |
| --- | --- | --- | ---: | --- | ---: |
| gpt-6-astra | combined | original | 4 | 4 / 0 / 0 | 4 / 4 |
| gpt-6-astra | combined | reflected | 4 | 4 / 0 / 0 | 4 / 4 |
| gpt-6-astra | target | original | 4 | 4 / 0 / 0 | 4 / 4 |
| gpt-6-astra | target | reflected | 4 | 3 / 0 / 1 | 4 / 4 |
| gpt-6.2-astra | combined | original | 4 | 4 / 0 / 0 | 4 / 4 |
| gpt-6.2-astra | combined | reflected | 4 | 2 / 0 / 2 | 4 / 4 |
| gpt-6.2-astra | target | original | 4 | 4 / 0 / 0 | 4 / 4 |
| gpt-6.2-astra | target | reflected | 4 | 4 / 0 / 0 | 4 / 4 |

## Review scope and bindings

All 32 raw judgments are preserved without rejudging. The protocol withholds assignment labels until all judgments and the native acknowledgement are sealed; payload shape, task facts and style can reveal labels. This is instruction-scoped same-lab review with incomplete masking, not external replication. All eight assigned reports per selector/scope and four per orientation are retained. Coverage, factual support, checklist format and operational success are separate measurements. The records do not comprehensively capture participant orchestration or identify internal cognitive causes.

The raw judgments remain in `results/masked_review.json`; the exact packet, native review acknowledgement and revealed mapping are in `review/`. The joined file retains every per-job category, explanation, claim record and source hash. Conditional unfinished-work views accompany the fixed all-assigned and orientation views in `results/review.json`.

No substantive adjudication was applied by this aggregation. Any later adjudication must preserve the sealed raw judgment and document its reason and evidence.
