import json, sys, hashlib
from pathlib import Path
packet_path = Path("delivery-study/review/input_packet.json")
p = json.loads(packet_path.read_text())

def delta(old, new):
    if not isinstance(old, dict) or not isinstance(new, dict):
        return new if old != new else {}
    d = {}
    for k in old.keys() - new.keys():
        d[k] = {"REMOVED_FROM_SHOWN_PAYLOAD": True}
    for k, v in new.items():
        if k not in old:
            d[k] = v
        elif old[k] != v:
            d[k] = delta(old[k], v) if isinstance(v, dict) and isinstance(old[k], dict) else v
    return d

start, end = map(int, sys.argv[1:3])
for i, r in enumerate(p["runs"][start-1:end], start):
    print("\n===", i, r["review_id"], "===")
    print("EXACT REPORT OBJECT", json.dumps(r["exact_final_report"], ensure_ascii=False))
    assert json.loads(r["sealed_report_text"]) == r["exact_final_report"]
    assert hashlib.sha256(r["sealed_report_text"].encode()).hexdigest() == r["input_sha256"]["final_report.json"]
    print("PUBLIC INITIAL DIAGNOSTIC", json.dumps(r["public_initial_status"], ensure_ascii=False))
    last = {}
    for e in r["public_observations"]:
        shown = json.loads(e["shown_stdout"])
        assert shown == e["observation"]
        assert hashlib.sha256(e["shown_stdout"].encode()).hexdigest() == e["stdout_sha256"]
        status = shown.get("local_status", {})
        print("EVENT", e["event_index"], e["action"], "parameters", json.dumps(e["parameters"], ensure_ascii=False))
        print("EXACT RESPONSE excluding local_status", json.dumps({k: v for k, v in shown.items() if k != "local_status"}, ensure_ascii=False))
        print("EXACT local_status" if not last else "LOSSLESS local_status DELTA from previous shown payload", json.dumps(status if not last else delta(last, status), ensure_ascii=False))
        last = status
    print("FINAL DIAGNOSTIC DELTA FROM INITIAL", json.dumps(delta(r["public_initial_status"], r["final_public_status"]), ensure_ascii=False))
    print("MASKING NOTE", json.dumps(r["residual_identity_risk"], ensure_ascii=False))
    print("DIAGNOSTIC QUALIFICATION", r["status_diagnostic_scope"])
