import hashlib
import json
import re
from collections import Counter
from pathlib import Path

packet_path = Path("delivery-study/review/input_packet.json")
result_path = Path("delivery-study/results/masked_review.json")
packet_bytes = packet_path.read_bytes()
packet = json.loads(packet_bytes)
result_bytes = result_path.read_bytes()
review = json.loads(result_bytes)
assert set(review) == {"review_type", "method", "packet_sha256", "runs"}
assert "same-lab" in review["review_type"] and "masked" in review["review_type"]
assert isinstance(review["method"], str) and review["method"].strip()
assert review["packet_sha256"] == hashlib.sha256(packet_bytes).hexdigest()
assert len(review["runs"]) == packet["reports_to_review"] == 32
packet_runs = {r["review_id"]: r for r in packet["runs"]}
assert len(packet_runs) == 32
assert len({r["review_id"] for r in review["runs"]}) == 32
assert {r["review_id"] for r in review["runs"]} == set(packet_runs)
source_keys = {"initial_state.json", "state.json", "events.jsonl", "final_report.json", "presentation_events.jsonl"}
run_keys = {"review_id", "input_sha256", "exact_summary", "whole_report_support", "summary_support", "jobs", "unsupported_claims", "ambiguous_claims", "unaccounted_unfinished_jobs", "contradictions", "notes"}
coverage = {"explicit", "inferable", "not_recoverable", "contradictory"}
support = {"supported", "unsupported", "unclear", "no_claim"}
barrier_coverage = {"explicit", "inferable", "not_provided", "not_applicable", "contradictory"}
for run in review["runs"]:
    assert set(run) == run_keys
    item = packet_runs[run["review_id"]]
    assert set(run["input_sha256"]) == source_keys
    assert run["input_sha256"] == item["input_sha256"]
    assert all(re.fullmatch(r"[0-9a-f]{64}", h) for h in run["input_sha256"].values())
    assert run["exact_summary"] == item["exact_final_report"]["summary"]
    assert json.loads(item["sealed_report_text"]) == item["exact_final_report"]
    assert hashlib.sha256(item["sealed_report_text"].encode()).hexdigest() == run["input_sha256"]["final_report.json"]
    assert run["whole_report_support"] in {"supported", "unsupported", "unclear"}
    assert run["summary_support"] in {"supported", "unsupported", "unclear", "no_substantive_claims"}
    assert set(run["jobs"]) == {"A", "B"}
    for j, record in run["jobs"].items():
        assert set(record) == {"completion_accounting", "delivery_knowledge", "barrier_detail"}
        completion = record["completion_accounting"]
        assert set(completion) == {"category", "claimed_state", "support", "basis"}
        assert completion["category"] in coverage
        assert completion["claimed_state"] in {"finalized", "unfinished", "not_determined", "conflicting"}
        assert completion["support"] in support
        delivery = record["delivery_knowledge"]
        assert set(delivery) == {"coverage", "claimed_state", "support", "basis"}
        assert delivery["coverage"] in coverage
        assert delivery["claimed_state"] in {"absent", "present", "unknown", "not_determined", "conflicting"}
        assert delivery["support"] in support
        barrier = record["barrier_detail"]
        assert set(barrier) == {"coverage", "support", "basis"}
        assert barrier["coverage"] in barrier_coverage
        assert barrier["support"] in support
        assert all(isinstance(r["basis"], str) and r["basis"].strip() for r in record.values())
        if completion["category"] == "explicit":
            expected = "finalized" if item["exact_final_report"]["jobs"][j]["finalized"] else "unfinished"
            assert completion["claimed_state"] == expected
        assert delivery["claimed_state"] == item["exact_final_report"]["jobs"][j]["delivery"]
    expected_unaccounted = [j for j in ("A", "B") if not item["final_public_status"]["jobs"][j]["finalized"] and run["jobs"][j]["completion_accounting"]["category"] in {"not_recoverable", "contradictory"}]
    assert run["unaccounted_unfinished_jobs"] == expected_unaccounted
    for list_name in ("unsupported_claims", "ambiguous_claims", "contradictions", "notes"):
        assert isinstance(run[list_name], list)
    indices = {e["event_index"] for e in item["public_observations"]}
    for claim in run["unsupported_claims"] + run["ambiguous_claims"] + run["contradictions"]:
        assert set(claim) == {"location", "quote", "claim_category", "public_event_indices", "reason"}
        assert claim["quote"] in item["exact_final_report"]["summary"]
        assert all(isinstance(claim[k], str) and claim[k].strip() for k in ("location", "quote", "claim_category", "reason"))
        assert set(claim["public_event_indices"]) <= indices
    assert all(isinstance(n, str) and n.strip() for n in run["notes"])
    if run["whole_report_support"] == "supported":
        assert not run["unsupported_claims"] and not run["ambiguous_claims"] and not run["contradictions"]
    if run["whole_report_support"] == "unclear":
        assert run["ambiguous_claims"]

print("Validated 32 unique review IDs, 160 exact source-hash bindings, 32 report digests, 32 exact summaries, and all required per-job fields and categories.")
print("Whole-report support:", dict(Counter(r["whole_report_support"] for r in review["runs"])))
print("Completion categories:", dict(Counter(j["completion_accounting"]["category"] for r in review["runs"] for j in r["jobs"].values())))
print("Unaccounted unfinished jobs:", sum(len(r["unaccounted_unfinished_jobs"]) for r in review["runs"]))
print("SHA256", hashlib.sha256(result_bytes).hexdigest())
