# Round 09 release reproduction

**PASS.** The supplied archive opened, and the reproduction card led to the release [README](extracted/continuation-repair/README.md). With Python 3.12.14 and Node v24.22.3, both documented scientific commands ran through the supplied wrapper and exited 0. No source or retained result was edited.

## Fresh execution evidence

- [main-verification.json](main-verification.json): **237 fresh scripted executions**, 237 retained runs replayed, **2,308 events**, 40 frozen inputs checked, and `normalized_reproduction_exact: true`.
- [exploratory-verification.json](exploratory-verification.json): **six separate diagnostic executions reproduced** and six canonical recounts; explicitly excluded from the primary 237.
- [commands.jsonl](commands.jsonl) preserves actual arguments, timestamps, exit codes, complete stdout/stderr and their hashes. Human-readable copies are [main-terminal.txt](main-terminal.txt) and [exploratory-terminal.txt](exploratory-terminal.txt).

The commands were `python3 verify.py --reproduce --output ../../main-verification.json` and `python3 -B verify_posthoc.py --output ../../exploratory-verification.json`, executed in the extracted study through `record_command.py`. Bytecode writing was disabled. The verifiers used fresh temporary run directories; their receipts and terminal outputs are preserved here. Cross-run normalization omits timestamps, dependent event hashes and runtime versions while validating original event chains. The summary's 2,252 events concern 221 new-controller/baseline records; 56 legacy events make the 2,308 total.

## Main comparison

| Challenge endpoint | Candidate | Deadline-first | Wait-for-all |
|---|---:|---:|---:|
| Positive guarantees attained | 64/64 | 64/64 | 50/64 |
| Joint completion when initially guaranteed | 43/43 | 43/43 | 31/43 |
| Unsafe-attempt worlds | 0/71 | 0/71 | 0/71 |
| Risky-selection / realized guarantee-loss worlds | 0/71 | 0/71 | 14/71 |
| Physical safe joint completions, all worlds | 49/71 | 52/71 | 40/71 |

These are 24 prospectively frozen configurations expanded into 71 worlds per policy: 43 joint-guaranteed, 21 one-job-guaranteed and seven zero-guarantee controls. **Candidate and deadline-first tie on the primary guarantee endpoints.** The suite provides no evidence that exact search is necessary or superior to deadline-first on those endpoints. The separate historical comparison gives candidate 8/8 safe joint completions versus 3/8 for each saved guard, all with zero unsafe attempts. The 213 challenge and 24 historical executions total 237. See [summary](extracted/continuation-repair/results/summary.json), [protocol](extracted/continuation-repair/protocol/PROTOCOL.md) and [result audit](extracted/continuation-repair/provenance/RESULT_AUDIT.md).

Deadline-first's three additional physical joint completions are **C07-W02, C08-W03 and C14-W03**. All begin with guarantee `(1,1)`: one completion including the priority job. The candidate secures that guarantee and stops when further guaranteed improvement is unavailable. Deadline-first spends spare resources querying the other job; in these favorable worlds it sees COMMITTED and safely finalizes it. The difference concerns safe opportunistic extra work, not primary guarantee attainment. Each candidate run uses three uses/four ticks; deadline-first uses five uses/seven ticks. The result audit and matching records under [results/runs](extracted/continuation-repair/results/runs/) document this distinction.

## Separate exploratory diagnostics

Two configurations selected after the primary tie were frozen before six runs: three worlds per policy. Candidate attains 3/3 initial guarantees; deadline-first 1/3, with risky selections in all three worlds. Neither makes an unsafe write. D01 exposes spending the only use on the earlier deadline instead of the declared priority. D02 exposes wasting a receipt waiting interval instead of finishing the other job first. In one D02 world deadline-first physically completes both despite losing the public joint guarantee at its initial wait. These selected counterexamples establish limits to general equivalence; they do not change the primary tie, provide a population rate or enter the 237 denominator. See the [diagnostic summary](extracted/continuation-repair/posthoc-diagnostics/summary.json) and [freeze](extracted/continuation-repair/posthoc-diagnostics/freeze.json).

## Trust and interpretation

The result relies on authentic fresh local status, immutable receipts, stable authorization, authoritative write acknowledgements, two independent original outcomes, fixed synthetic costs, inclusive deadlines and finite action caps. Wrong-job recovery specifically uses genuine local status after rejecting the displayed header. Candidate and historical-helper observations also differ because their query schedules differ. A separate process supplies an information interface, not an OS security boundary.

The retained parser witnesses accept a well-formed same-job forgery, a repeated matching reply, contradictory finalized facts and a boolean wait acknowledgement equal to integer one. Structural checks therefore do not supply authentication, complete schema validation or replay defense. Independent arithmetic checks reconstruct evidence/resources/effects, while guarantee-risk judgments still use the retained reference oracle. The planner's local proof is not an independent formal certificate; synthetic ticks and uses do not measure compute or financial costs. See [controller design](extracted/continuation-repair/CONTROLLER_DESIGN.md), [source audit](extracted/continuation-repair/protocol/SOURCE_AUDIT.md) and [boundary witnesses](extracted/continuation-repair/protocol/candidate_validation_results.json).

This attempt establishes that the release and supplied card were usable in this environment and that its finite scripted findings reproduced. It is a same-lab artifact-usability check with published findings visible. The reproduced study contains **zero fresh model participants and no provider API experiment**. It establishes no model-weight improvement, learned persistence, native-model superiority, population failure rate, production integration or external independent replication. Revocation, arbitrary corruption, concurrency, durable restart and real workload reliability remain outside scope. The documented fresh traces were temporary; new receipts and complete terminal output are retained.

There were no execution blockers. Broad summary displays were truncated during reading; focused fields and complete on-disk evidence resolved that presentation issue. [answer.json](answer.json) contains the structured findings.
