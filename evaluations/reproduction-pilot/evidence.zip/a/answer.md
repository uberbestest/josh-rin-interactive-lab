# Release reproduction: completed

The supplied `round-09.zip` opened successfully. I followed the [release README](extracted/continuation-repair/README.md) using Python 3.12.14 and Node.js v24.22.3. Both verification commands ran through the supplied wrapper and exited 0 with empty stderr.

The newly generated [main receipt](main_verification.json) reports **237 fresh scripted executions**, **237 replayed runs**, **2,308 replayed events**, **40 frozen files checked**, and **`normalized_reproduction_exact: true`**. The separate [exploratory receipt](exploratory_verification.json) reports **six freshly reproduced diagnostics**. Actual arguments, timings, outputs and output hashes are in [commands.jsonl](commands.jsonl); readable terminal copies are [main_terminal.txt](main_terminal.txt) and [exploratory_terminal.txt](exploratory_terminal.txt).

## Main findings

| Challenge endpoint | Candidate | Deadline-first | Wait-for-all |
|---|---:|---:|---:|
| Positive guarantees attained | 64/64 | 64/64 | 50/64 |
| Joint completion where initially guaranteed | 43/43 | 43/43 | 31/43 |
| Unsafe-attempt runs | 0/71 | 0/71 | 0/71 |
| Risky-selection runs | 0/71 | 0/71 | 14/71 |
| Realized guarantee-loss runs | 0/71 | 0/71 | 14/71 |
| Physical safe joint completions across all worlds | 49/71 | 52/71 | 40/71 |

The candidate and deadline-first policy **tie on the primary guarantee endpoints**. The main suite does not show that exact search is necessary. There are 71 challenge worlds per policy: 43 joint-guaranteed, 21 one-job-guaranteed and seven zero-guarantee controls, which are excluded from the positive denominator. Guarantees optimize safe finalized count and then priority completion across public-consistent possibilities. See the [protocol](extracted/continuation-repair/protocol/PROTOCOL.md) and [retained summary](extracted/continuation-repair/results/summary.json).

Deadline-first's three extra physical joint completions occur in **C07-W02, C08-W03 and C14-W03**. After securing the priority job, the candidate stops because no further completion is guaranteed. The heuristic uses spare resources, discovers a favorable committed receipt and safely finishes the other job. Thus realized extra work and guaranteed work are distinct endpoints. The [result audit](extracted/continuation-repair/provenance/RESULT_AUDIT.md) identifies these traces. Separately, historical regression completion is 8/8 for the candidate and 3/8 for each unchanged saved guard, with no unsafe attempts.

## Exploratory diagnostics remain separate

Two configurations selected after the main tie cover three worlds per policy, totaling six runs. Candidate guarantee attainment is 3/3; deadline-first is 1/3, with risky selections in all three worlds. Neither policy makes an unsafe attempt. D01 exposes spending the only use on an earlier-deadline job instead of the declared priority; D02 exposes failing to use a receipt waiting interval to finish the other job. Favorable physical completion in one D02 world still follows a guarantee-losing choice. These frozen-before-execution, post-hoc counterexamples are **not held out and do not alter the primary 237 or their tie**. See the [diagnostic summary](extracted/continuation-repair/posthoc-diagnostics/summary.json) and [freeze](extracted/continuation-repair/posthoc-diagnostics/freeze.json).

## Trust and limits

The result depends on genuine local status, authoritative acknowledgements, stable authorization, immutable receipts, two independent original-write outcomes, fixed synthetic costs and inclusive logical deadlines. Wrong-job recovery specifically requires fresh authentic status. Candidate and old-helper observation trajectories differ because their schedules differ. Structural receipt checks do not authenticate same-job receipts or prevent replay; retained witnesses also show contradictory finalized-status and boolean wait-tick acceptance. The process boundary is not an operating-system sandbox. See the [source audit](extracted/continuation-repair/protocol/SOURCE_AUDIT.md) and [controller design](extracted/continuation-repair/CONTROLLER_DESIGN.md).

The arithmetic checker is separate code, but guarantee-risk fields still depend on the reference oracle. Normalized reproduction excludes timestamps, dependent event hashes and runtime-version-only metadata while validating original chains. Fresh temporary raw runs are removed by the release verifier; the new receipts/logs and complete retained archive records remain available.

This establishes successful same-lab package reproduction of deterministic scripted outcomes. The underlying study has zero fresh model participants and no provider API experiment. It establishes no model-weight improvement, native model ranking, production readiness, general corruption defense, concurrency or restart behavior, real operating cost, or independent external replication. The 237 main executions and six exploratory executions remain distinct evidence groups.

No execution blocker occurred. One oversized summary display was truncated by the terminal; focused reads resolved that inspection issue without changing evidence. The complete structured findings are in [answer.json](answer.json).
